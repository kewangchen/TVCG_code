"""Compile the supplied opaque-handle adapter against an installed CHOLMOD."""
from pathlib import Path
import argparse,os,subprocess,sys
from .src.chol_update import _NATIVE_SOURCE

def build(include_dir,library_dir,output,compiler='cc'):
 include_dir=Path(include_dir).resolve();library_dir=Path(library_dir).resolve();output=Path(output).resolve()
 if not (include_dir/'cholmod.h').exists():raise FileNotFoundError('The include directory must contain matching CHOLMOD/SuiteSparse headers.')
 output.parent.mkdir(parents=True,exist_ok=True);source=output.with_suffix('.c');source.write_text(_NATIVE_SOURCE)
 args=[compiler,'-O3','-std=c99','-dynamiclib' if sys.platform=='darwin' else '-shared']
 if sys.platform!='darwin':args+=['-fPIC']
 args+=['-I'+str(include_dir),str(source),'-L'+str(library_dir),'-lcholmod','-Wl,-rpath,'+str(library_dir),'-o',str(output)]
 subprocess.run(args,check=True)
 print('Set CAGD_CHOLMOD_ROWMOD_LIB to',output)
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--include-dir',required=True);p.add_argument('--library-dir',required=True);p.add_argument('--output',required=True);p.add_argument('--compiler',default=os.getenv('CC','cc'));a=p.parse_args();build(a.include_dir,a.library_dir,a.output,a.compiler)
