"""Python publication figures drawn only from recorded source data."""
from pathlib import Path
import json,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import Patch
from .cases import MAIN,LABELS
from .src.render import camera_coordinates,paired_bounds,rasterize,color_rgb
ROOT=Path(__file__).resolve().parent;R=ROOT/'results';OUT=ROOT/'figures';OUT.mkdir(exist_ok=True)
SHORT=['Strip','Annulus','Torus','CTC-01','CTC-02','CTC-03']
COL={'response':'#00857A','warm_update':'#7A8D9A','condensed':'#345B7A','osqp':'#BF8B48','proxqp':'#9B7185'}
NAMES={'response':'Bounded response + row updates','warm_update':'Warm row updates','condensed':'Compressed cached Schur','osqp':'OSQP','proxqp':'ProxQP'}
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial','DejaVu Sans'],'font.size':8,'axes.labelsize':8,'axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.65,'xtick.labelsize':7,'ytick.labelsize':7,'legend.frameon':False,'legend.fontsize':7,'pdf.fonttype':42,'svg.fonttype':'none','savefig.facecolor':'white'})
inputs=set();outputs=[]
def read(p):inputs.add(p);return json.loads(p.read_text())
def load(p):inputs.add(p);return np.load(p)
def save(fig,name):
 for ext in ['pdf','svg','png']:
  p=OUT/f'{name}.{ext}';fig.savefig(p,dpi=600,bbox_inches='tight',pad_inches=.04);outputs.append(p)
 plt.close(fig)
def panel(ax,label,title):
 ax.text(-.13,1.04,label,transform=ax.transAxes,fontweight='bold',fontsize=11);ax.set_title(title,loc='left',pad=10,fontsize=9)
def orient(V,F,name,normals=None):
 # An orthogonal display rotation; coordinates in numerical records are untouched.
 if name.startswith('nist'):
  mid=.5*(V[:len(V)//2]+V[len(V)//2:]) if len(V)%2==0 and len(F)%2==0 else V
  _,_,axes=np.linalg.svd(mid-mid.mean(0),full_matrices=False)
  if np.linalg.det(axes)<0:axes[-1]*=-1
  if normals is not None and axes[2]@np.mean(normals,axis=0)<0:axes[1:]*=-1
  V=(V-mid.mean(0))@axes.T
  return camera_coordinates(V,name,65,-75)
 return camera_coordinates(V,name,*{'strip':(25,-65),'annulus':(55,-65),'torus':(25,-60)}[name])
def gallery():
 records=read(R/'geometry_audit.json');fig=plt.figure(figsize=(7.1,5.1))
 for k,name in enumerate(MAIN):
  rec=next(x for x in records if x['case']==name);z=load(R/'geometry'/name/'states.npz');F=z['faces'];row,col=divmod(k,3);left=.005+col*.334;top=.98-row*.46
  fig.text(left,top,chr(97+k),fontsize=11,fontweight='bold',va='top');fig.text(left+.027,top,LABELS[k],fontsize=8.5,va='top')
  fig.text(left+.027,top-.032,f'{len(z["solved"]):,} vertices · {rec["free_dofs"]:,} gap variables',fontsize=6.8,color='#59666E',va='top')
  ps=[orient(z[key],F,name,z['normals']) for key in ['initial','solved']];bounds=paired_bounds(ps,670,570)
  colors=np.tile(color_rgb('#A5B4BD'),(len(F),1));colors[len(F)//2:]=color_rgb('#15958C')
  fixed=z['fixed'][::max(1,len(z['fixed'])//140)]
  for j,pr in enumerate(ps):
   cc=colors.copy()
   if j==0 and 'initial_crossing_faces' in rec:
    hit=np.unique(np.asarray(rec['initial_crossing_faces'],int));cc[hit]=color_rgb('#C96669')
   im,_=rasterize(pr,F,fixed,bounds,670,570,cc,600)
   ax=fig.add_axes([left+j*.163,top-.365,.163,.30]);ax.imshow(im);ax.axis('off');ax.text(.5,1.0,'Input' if j==0 else 'Computed',ha='center',va='bottom',transform=ax.transAxes,fontsize=7.5)
  text=f'Input overlap witnesses: {rec.get("initial_crossings",rec.get("initial_detected_pair_count",""))}'
  fig.text(left+.163,top-.392,text,ha='center',fontsize=6.9,color='#59666E')
 fig.text(.01,.02,'Layer identity: slate / teal     • Fixed controls (subset shown)',fontsize=7.2,color='#59666E');fig.text(.99,.02,'Matched camera and scale within every pair',ha='right',fontsize=7.2,color='#59666E');save(fig,'geometry')
def cad_context():
 fig=plt.figure(figsize=(7.1,2.75))
 for j,name in enumerate(MAIN[3:]):
  z=load(ROOT/'assets'/name/'full_part.npz');X,F=z['X'],z['faces'];meta=read(ROOT/'assets'/name/'metadata.json');selected=meta['selected_gmsh_face_ids']
  # Use selected-face principal directions for a consistent part/patch context.
  selected_mesh=load(ROOT/'assets'/name/'selected_face_coarse.npz');ss=selected_mesh['X'];_,_,axes=np.linalg.svd(ss-ss.mean(0),full_matrices=False)
  if np.linalg.det(axes)<0:axes[-1]*=-1
  if axes[2]@np.mean(selected_mesh['normals'],axis=0)<0:axes[1:]*=-1
  pr=camera_coordinates((X-X.mean(0))@axes.T,name,50 if name=='nist_ctc_03' else 35,-65);bounds=paired_bounds([pr],1050,920)
  colors=np.tile(color_rgb('#BCC6CC'),(len(F),1));colors[np.isin(z['cad_face_ids'],selected)]=color_rgb('#098C83')
  im,_=rasterize(pr,F,[],bounds,1050,920,colors,600)
  ax=fig.add_axes([j/3,.14,.333,.75]);ax.imshow(im);ax.axis('off');ax.set_title(f'{chr(97+j)}  NIST CTC-{j+1:02d}',loc='left',fontsize=9)
  fig.text((j+.5)/3,.07,{'nist_ctc_01':'Trimmed plate · 11 inner wires','nist_ctc_02':'Authored B-spline blend','nist_ctc_03':'Sheet, bend and flange'}[name],ha='center',fontsize=7.3)
 fig.text(.01,.005,'Public NIST STEP BReps. Teal: exact selected faces; gray: part context. Paired-layer edits are derived from these faces.',fontsize=6.8,color='#59666E');save(fig,'cad_context')
def performance():
 a=read(R/'statistics.json');rows=a['rows'];fig,axes=plt.subplots(1,2,figsize=(7.1,2.85),gridspec_kw={'width_ratios':[1.35,1]});fig.subplots_adjust(wspace=.43,bottom=.23,top=.78)
 ax,bx=axes;x=np.arange(6)
 for j,m in enumerate(['response','warm_update','condensed','osqp']):
  rr=[next(r for r in rows if r['case']==c and r['level']=='fine' and r['rank']==1 and r['method']==m)for c in MAIN]
  y=np.array([r['median'] for r in rr]);lo=np.array([r['minimum'] for r in rr]);hi=np.array([r['maximum'] for r in rr])
  ax.errorbar(x+(j-1.5)*.14,y,yerr=[y-lo,hi-y],fmt='o',color=COL[m],ms=3.5,capsize=1.3,lw=.8,label=NAMES[m])
 ax.set_yscale('log');ax.set_xticks(x,SHORT,rotation=35,ha='right');ax.set_ylabel('Total for 41 edits (s)');ax.grid(axis='y',alpha=.15);panel(ax,'a','Fine-mesh sequence costs');ax.legend(ncol=2,loc='lower left',bbox_to_anchor=(-.05,1.13),fontsize=6.4,columnspacing=.65)
 mat=np.array([[next(r for r in a['speedups'] if r['case']==c and r['level']==lev and r['rank']==1)['condensed'] for lev in ['base','fine']]for c in MAIN]);bx.imshow(np.log2(mat),cmap='PuBuGn',vmin=-.6,vmax=3.7,aspect='auto')
 for i in range(6):
  for j in range(2):bx.text(j,i,f'{mat[i,j]:.2f}×',ha='center',va='center',fontsize=8,color='white' if mat[i,j]>3 else '#25414B')
 bx.set_xticks([0,1],['Base','Fine']);bx.set_yticks(range(6),SHORT);bx.tick_params(length=0);[s.set_visible(False)for s in bx.spines.values()];panel(bx,'b','Cached Schur / proposed time');save(fig,'performance')
def memory():
 a=read(R/'statistics.json');rows=a['rows'];fig,(ax,bx,cx)=plt.subplots(1,3,figsize=(7.1,2.6));fig.subplots_adjust(wspace=.65,bottom=.27,top=.77);x=np.arange(6)
 for j,m in enumerate(['response','condensed']):
  rr=[next(r for r in rows if r['case']==c and r['level']=='fine' and r['rank']==1 and r['method']==m)for c in MAIN];ax.plot(x,[r['process_rss_max']/2**20 for r in rr],'o-',color=COL[m],ms=3,lw=1,label=NAMES[m])
 ax.set_ylabel('Process peak RSS (MiB)');panel(ax,'a','Process memory')
 rr=[next(r for r in rows if r['case']==c and r['level']=='fine' and r['rank']==1 and r['method']=='response')for c in MAIN]
 cache=[r['memory']['response_bytes']/2**20 for r in rr];native=[r['memory']['native_factor']['native_tracked_bytes']/2**20 for r in rr]
 bx.bar(x,native,color='#7A8D9A');bx.bar(x,cache,bottom=native,color=COL['response']);bx.set_ylabel('Retained payload (MiB)');panel(bx,'b','Native factor + cache')
 for j,m in enumerate(['response','warm_update']):
  val=[next(r for r in a['speedups'] if r['case']==c and r['level']=='fine' and r['rank']==1)['warm_update'] for c in MAIN]
  if j==0:cx.bar(x,val,color=COL['response'])
 cx.axhline(1,c='#697881',lw=.7,ls='--');cx.set_ylabel('Warm native / proposed time');panel(cx,'c','Response ablation')
 fig.legend([Line2D([],[],color=COL['response'],marker='o',lw=1),Line2D([],[],color=COL['condensed'],marker='o',lw=1),Patch(color='#7A8D9A'),Patch(color=COL['response'])],['Proposed','Cached Schur','Native CHOLMOD','Affine responses'],ncol=4,loc='upper center',bbox_to_anchor=(.5,1.04),fontsize=6.8,columnspacing=1.4)
 for aa in [ax,bx,cx]:aa.set_xticks(x,SHORT,rotation=55,ha='right');aa.grid(axis='y',alpha=.13)
 save(fig,'memory')
def quality():
 g=read(R/'geometry_audit.json');fig,axes=plt.subplots(1,3,figsize=(7.1,2.4));fig.subplots_adjust(wspace=.55,bottom=.29,top=.84);x=np.arange(6)
 qkeys=[('clamp_energy_ratio','Common correction energy'),('sigma_max','Maximum local stretch'),('isometry_energy','Intrinsic strain')]
 for j,ax in enumerate(axes):
  if j==0:
   vals=[r['clamp_energy_ratio'] for r in g];ax.bar(x,vals,color=COL['response']);ax.axhline(1,c='#687780',ls='--',lw=.7);ax.set_ylabel('Clamp / metric optimum')
  else:
   key=qkeys[j][0];v=np.array([r['quality'][key] for r in g]);b=np.array([r['clamp_quality'][key] for r in g]);ax.plot(x,v,'o-',c=COL['response'],lw=1,ms=3,label='Metric projection');ax.plot(x,b,'s--',c=COL['osqp'],lw=1,ms=3,label='Nodal clamp');ax.set_ylabel('Singular value' if j==1 else 'Area-weighted strain measure')
  panel(ax,chr(97+j),qkeys[j][1]);ax.set_xticks(x,SHORT,rotation=45,ha='right');ax.grid(axis='y',alpha=.15)
 axes[2].legend(fontsize=6.7);save(fig,'quality')
def directions():
 a=read(R/'directions.json');fig,(ax,bx)=plt.subplots(1,2,figsize=(7.1,2.55));fig.subplots_adjust(wspace=.43,bottom=.25,top=.83)
 for name,key,ls,c in [('Cone','opening_relative_error','-','#00857A'),('Frozen equality','frozen_relative_error','--','#9B7185'),('Central difference','central_relative_error',':','#BF8B48')]:
  vals=np.array([[r['errors'][i][key] for r in a]for i in range(4)]);ax.plot([1e-3,1e-4,1e-5,1e-6],np.median(vals,axis=1),'o'+ls,lw=1.2,ms=3,label=name,color=c)
 ax.set_xscale('log');ax.set_yscale('log');ax.set_xlabel('One-sided finite-difference step');ax.set_ylabel('Median relative response error');ax.legend(fontsize=7);ax.grid(alpha=.15);panel(ax,'a','Six first-contact transitions')
 for key,label,c in [('opening_slope','Opening cone','#00857A'),('central_slope','Central difference','#BF8B48'),('frozen_slope','Frozen equality','#9B7185')]:
  v=[r[key]/r['opening_slope'] for r in a];bx.plot(range(6),v,'o-',c=c,lw=1,ms=3,label=label)
 bx.set_xticks(range(6),SHORT,rotation=35,ha='right');bx.set_ylabel('Slope / exact opening slope');bx.legend(fontsize=6.6);bx.grid(alpha=.15);panel(bx,'b','Opening a zero-force contact');save(fig,'directions')
def main():
 gallery();cad_context();performance();memory();quality();directions();dump=dict(backend='Python matplotlib',inputs={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in inputs},outputs={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in outputs})
 (OUT/'provenance.json').write_text(json.dumps(dump,indent=2)+'\n')
if __name__=='__main__':main()
