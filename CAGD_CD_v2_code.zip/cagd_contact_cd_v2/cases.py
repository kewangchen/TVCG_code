"""Frozen procedural and public STEP-derived paired-layer test problems."""
from pathlib import Path
import json
import numpy as np
from scipy import sparse
from scipy.sparse.csgraph import dijkstra
from .src.procedural_cases import build as procedural,stiffness,surfaces
ROOT=Path(__file__).resolve().parent
MAIN=['strip','annulus','torus','nist_ctc_01','nist_ctc_02','nist_ctc_03']
LABELS=['Corrugated strip','Graded annulus','Toroidal layers','NIST plate with holes','NIST B-spline blend','NIST bent sheet']

def build(name,level='base',rank=1):
 if name.startswith('nist'):
  level_file={'base':'coarse','medium':'medium','fine':'fine'}[level]
  z=np.load(ROOT/'assets'/name/f'selected_face_{level_file}.npz')
  raw=z['X'];center=raw.mean(0);scale=3./np.linalg.norm(np.ptp(raw,axis=0));X=(raw-center)*scale
  faces=z['faces'];normals=z['normals'];normals=normals/np.linalg.norm(normals,axis=1)[:,None]
  fixed=np.unique(z['boundary_node_ids']);free=np.setdiff1d(np.arange(len(X)),fixed)
  edges=np.vstack((faces[:,[0,1]],faces[:,[1,2]],faces[:,[2,0]]));edges=np.unique(np.sort(edges,axis=1),axis=0)
  length=np.linalg.norm(X[edges[:,0]]-X[edges[:,1]],axis=1)
  graph=sparse.coo_matrix((np.r_[length,length],(np.r_[edges[:,0],edges[:,1]],np.r_[edges[:,1],edges[:,0]])),shape=(len(X),len(X))).tocsr()
  dist=dijkstra(graph,indices=fixed,min_only=True);env=np.sin(.5*np.pi*np.minimum(dist/(.65*dist.max()),1))**2
  _,_,axes=np.linalg.svd(X,full_matrices=False);uv=X@axes[:2].T;uv=(uv-uv.min(0))/np.maximum(np.ptp(uv,axis=0),1e-12);u,v=uv.T
  env*=1+.18*np.cos(4*np.pi*u)+.12*np.sin(3*np.pi*v);env[fixed]=0;env/=env.max()
  radius={'nist_ctc_01':np.inf,'nist_ctc_02':9.9984,'nist_ctc_03':6.35}[name]*scale
  gap0=min(.08,.2*radius);clearance=.225*gap0
  C,m=stiffness(X,faces);mass=m/m.mean();bih=C@sparse.diags(1/m)@C
  H=(sparse.diags(mass)+12*C/C.diagonal().mean()+18*bih/bih.diagonal().mean()).tocsc()[free][:,free].tocsc()
  c=dict(id=name,label=LABELS[MAIN.index(name)],X=X,normals=normals,faces=faces,fixed=fixed,free=free,H=H,b=np.full(len(free),clearance-gap0),gap0=gap0,clearance=clearance,mass_lower_bound=float(mass[free].min()),area_mass=m,wave=env,chart_kind='CAD normal',transform=dict(center_mm=center.tolist(),scale_per_mm=scale,sampled_radius_mm=None if np.isinf(radius) else radius/scale))
 else:
  dims={'strip':(40,18),'annulus':(48,16),'torus':(40,20)};nu,nv=dims[name];factor={'base':1,'medium':2,'fine':3}[level]
  c=procedural(dict(id=name,label=LABELS[MAIN.index(name)],nu=nu*factor,nv=nv*factor));env=c['wave'];X=c['X'];_,_,axes=np.linalg.svd(X-X.mean(0),full_matrices=False);uv=X@axes[:2].T;uv=(uv-uv.min(0))/np.maximum(np.ptp(uv,axis=0),1e-12);u,v=uv.T
 c['Y']=np.column_stack([-1.875*c['gap0']*c['wave'][c['free']]])
 if rank==3:
  a=c['Y'][:,0];c['Y']=np.column_stack((a,.55*a*np.cos(2*np.pi*u[c['free']]),.55*a*np.sin(2*np.pi*v[c['free']])))
 if rank not in [1,3]:raise ValueError('Frozen protocol uses rank1 or rank3.')
 c['rank']=rank;c['level']=level
 return c

def path(count=41,rank=1,kind='smooth'):
 t=np.linspace(0,1,count);a=.25+1.05*np.sin(np.pi*t)**2+.07*np.sin(4*np.pi*t)
 out=a[:,None] if rank==1 else np.column_stack((a,.23*np.sin(2*np.pi*t),.19*np.sin(4*np.pi*t)))
 if kind=='abrupt':
  order=np.random.default_rng(20261017).permutation(count);out=out[order]
 return out
