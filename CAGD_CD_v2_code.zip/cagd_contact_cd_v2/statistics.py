from pathlib import Path
import json,numpy as np
from .cases import MAIN
from .benchmark import dump
ROOT=Path(__file__).resolve().parent

def aggregate(phase='formal_03',precision_phase=None):
 out=ROOT/'results'/phase
 if precision_phase is None and phase=='formal_03':precision_phase='prox_precision_01'
 assert (out/'completed.json').exists(),'Incomplete phase'
 rows=[];equiv=[]
 for folder in sorted(out.iterdir()):
  if not folder.is_dir() or folder.name=='executed_source':continue
  ref=np.load(folder/'response_0.npz')['states'];H=None
  for method in ['response','warm_update','condensed','osqp','proxqp']:
   files=sorted(folder.glob(method+'_*.json'))
   if precision_phase is not None:
    refined=ROOT/'results'/precision_phase/folder.name
    if method=='proxqp' and (ROOT/'results'/precision_phase/'completed.json').exists():files=sorted(refined.glob(method+'_*.json'))
   if not files:continue
   runs=[json.loads(p.read_text()) for p in files];times=np.array([r['total_seconds'] for r in runs])
   diffs=[float(np.max(abs(np.load(p.with_suffix('.npz'))['states']-ref))) for p in files]
   row=dict(case=runs[0]['case'],level=runs[0]['level'],rank=runs[0]['rank'],dofs=runs[0]['dofs'],method=method,median=float(np.median(times)),minimum=float(times.min()),maximum=float(times.max()),all_qualified=all(r['all_qualified'] for r in runs),kkt_max=max(r['kkt_max'] for r in runs),coordinate_difference_max=max(diffs),process_rss_max=max(r['peak_process_rss_bytes'] for r in runs),memory=runs[0]['memory'],stats=runs[0]['stats'],setup_median=float(np.median([r['setup_seconds'] for r in runs])))
   rows.append(row)
 ratios=[]
 for r in rows:
  if r['method']!='response':continue
  base={x['method']:x for x in rows if x['case']==r['case'] and x['level']==r['level'] and x['rank']==r['rank']}
  ratios.append(dict(case=r['case'],level=r['level'],rank=r['rank'],dofs=r['dofs'],**{m:base[m]['median']/r['median'] for m in base if m!='response' and base[m]['all_qualified'] and r['all_qualified']}))
 sums={}
 for group,pred in [('all',lambda x:True),('base_r1',lambda x:x['level']=='base'),('fine_r1',lambda x:x['level']=='fine' and x['rank']==1),('fine_r3',lambda x:x['rank']==3)]:
  items=[r for r in ratios if pred(r)]
  sums[group]={m:dict(geometric_mean=float(np.exp(np.mean(np.log([r[m] for r in items if m in r])))),minimum=min(r[m] for r in items if m in r),maximum=max(r[m] for r in items if m in r),wins=sum(r[m]>1 for r in items if m in r),count=sum(m in r for r in items)) for m in ['warm_update','condensed','osqp','proxqp'] if any(m in r for r in items)}
 result=dict(rows=rows,speedups=ratios,summary=sums,all_qualified=all(r['all_qualified'] for r in rows),completed=json.loads((out/'completed.json').read_text()))
 dump(ROOT/'results/statistics.json',result);print(json.dumps(sums,indent=2));return result
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('--phase',default='formal_03');p.add_argument('--precision-phase');a=p.parse_args();aggregate(a.phase,a.precision_phase)
