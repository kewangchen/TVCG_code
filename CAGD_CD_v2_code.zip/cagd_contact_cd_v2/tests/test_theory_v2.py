"""Independent algebra checks of the error localization hypotheses."""
import numpy as np
from scipy import sparse
from cagd_contact_cd_v2.src.response import residual_gap_bound
from cagd_contact_cd_v2.tests.test_response import enumerated

def test_zero_stationarity_does_not_imply_zero_feasible_gap():
    z=residual_gap_bound(sparse.eye(1,format='csc'),np.zeros(1),np.zeros(1),np.ones(1),np.ones(1),1)
    assert z['gap_upper']==1
    assert z['h_error_bound']==np.sqrt(2)

def test_inexact_rank_three_response_radius_bounds_both_optimizer_errors():
    rng=np.random.default_rng(608);accepted=0
    for _ in range(12):
        n=5;D=rng.normal(size=(n,n));H=D.T@D+3*np.eye(n);b=np.zeros(n)
        A=np.array([0,2]);F=np.array([1,3,4]);u=np.array([0.,.8,0.,1.1,.7]);lam=np.array([1.3,0,1.7,0,0])
        y=u-np.linalg.solve(H,lam);Y=.05*rng.normal(size=(n,3));V=np.zeros_like(Y)
        V[F]=np.linalg.solve(H[np.ix_(F,F)],(H@Y)[F])+.0001*rng.normal(size=(3,3))
        L=H@(V-Y);L[F]=0;R=H@(V-Y)-L
        for theta in .2*rng.normal(size=(12,3)):
            uh=u+V@theta;lh=lam+L@theta;rho=np.linalg.norm(R,axis=0)@abs(theta)/np.sqrt(3)
            if min(uh[F])<=rho/np.sqrt(3) or np.any(lh[A]<=rho*np.sqrt(H.diagonal()[A])):continue
            exact=enumerated(H,b,y+Y@theta);lexact=H@(exact-y-Y@theta)
            du=uh-exact;dl=lh-lexact
            joint=du@H@du+dl@np.linalg.solve(H,dl)
            assert joint<=rho*rho+1e-20
            np.testing.assert_array_equal(np.flatnonzero(lexact>1e-8),A)
            accepted+=1
    assert accepted>=100
