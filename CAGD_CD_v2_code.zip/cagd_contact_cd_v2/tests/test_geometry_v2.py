"""Tiny synthetic geometry checks; deliberately no formal benchmark execution."""
import tempfile
import unittest
from pathlib import Path

import numpy as np
from scipy import sparse

from cagd_contact_cd_v2.geometry_audit import audit_endpoint, load_endpoint, paired_surfaces
from cagd_contact_cd_v2.src.geometry_checks import (initial_matching_lp, lp_mesh,
                                                   summarize, triangle_metrics,
                                                   triangle_overlap_lp)
from cagd_contact_cd_v2.src.closed_distance import closed_mesh_check, distance


def tiny_case():
    X = np.array([[0., 0., 0.], [1., 0., 0.], [0., 1., 0.]])
    return dict(id='tiny', label='Tiny synthetic triangle', level='base', rank=1,
                X=X, normals=np.tile([0., 0., 1.], (3, 1)), faces=np.array([[0, 1, 2]]),
                fixed=np.array([0]), free=np.array([1, 2]), H=sparse.eye(2, format='csc'),
                b=np.full(2, -.08), gap0=.1, clearance=.02, mass_lower_bound=1.,
                area_mass=np.ones(3), Y=np.full((2, 1), -.2), chart_kind='vertical')


class GeometryV2Tests(unittest.TestCase):
    def test_uniform_scaling_has_expected_area_stretch_and_angles(self):
        X = tiny_case()['X']; faces = np.array([[0, 1, 2]])
        q = summarize(triangle_metrics(X, 2*X, faces))
        self.assertAlmostEqual(q['sigma_min'], 2.)
        self.assertAlmostEqual(q['sigma_max'], 2.)
        self.assertAlmostEqual(q['area_ratio_min'], 4.)
        self.assertAlmostEqual(q['conformal_max'], 1.)
        self.assertAlmostEqual(q['angle_max_deg'], 0.)
        self.assertAlmostEqual(q['isometry_energy'], 1.)

    def test_lp_distinguishes_interior_overlap_and_expected_shared_edge(self):
        a = tiny_case()['X']
        overlap = triangle_overlap_lp(a, a.copy())
        self.assertTrue(overlap['strict_overlap'])
        self.assertAlmostEqual(overlap['margin'], 1/3)
        self.assertLess(overlap['witness_residual'], 1e-12)
        neighbor = np.array([[1., 0., 0.], [1., 1., 0.], [0., 1., 0.]])
        self.assertFalse(triangle_overlap_lp(a, neighbor)['strict_overlap'])
        V = np.vstack((a, [[1., 1., 0.]])); F = np.array([[0, 1, 2], [1, 3, 2]])
        self.assertEqual(lp_mesh(V, F)['tested_pairs'], 1)
        self.assertFalse(lp_mesh(V, F)['strict_overlaps'])

    def test_closed_distance_catches_touch_without_positive_lp_margin(self):
        a = tiny_case()['X']; touching = a+np.array([1., 0., 0.])
        self.assertFalse(triangle_overlap_lp(a, touching)['strict_overlap'])
        self.assertLess(distance(a[None], touching[None])[0], 1e-12)
        V = np.vstack((a, touching)); F = np.array([[0, 1, 2], [3, 4, 5]])
        self.assertEqual(closed_mesh_check(V, F)['touch_or_crossing_pairs'], [[0, 1]])
        self.assertAlmostEqual(distance(a[None], (a+[0., 0., .3])[None])[0], .3)

    def test_matching_face_lp_produces_actual_crossing_witness(self):
        c = tiny_case(); y = np.array([-.2, 0.])
        V, F = paired_surfaces(c, y)
        result = initial_matching_lp(c, V, F, y)
        self.assertEqual(result['tested_pairs'], 1)
        self.assertEqual(len(result['strict_overlaps']), 1)
        witness = result['strict_overlaps'][0]
        self.assertEqual(witness['faces'], [0, 1])
        self.assertLess(witness['witness_residual'], 1e-12)

    def test_endpoint_reports_fixed_nodes_identical_clamp_constraints_and_energies(self):
        c = tiny_case(); y = np.array([-.2, 0.]); u = np.maximum(y, c['b'])
        rec, arrays = audit_endpoint(c, u, y, lam=u-y)
        self.assertTrue(rec['endpoint_checks_pass'])
        self.assertTrue(rec['clamp_endpoint_checks_pass'])
        self.assertEqual(rec['initial_crossings'], 1)
        self.assertEqual(rec['hard_error'], 0.)
        self.assertAlmostEqual(rec['chart_gap_min'], .02)
        self.assertAlmostEqual(rec['energy'], .5*.12**2)
        self.assertAlmostEqual(rec['clamp_energy_ratio'], 1.)
        np.testing.assert_allclose(arrays['solved'], arrays['clamp'])
        self.assertEqual(rec['independent_kkt']['stationarity_linf'], 0.)
        rec, _ = audit_endpoint(c, u, y, full_checks=False)
        self.assertIsNone(rec['endpoint_checks_pass'])

    def test_saved_endpoint_uses_peak_theta_and_rejects_model_drift(self):
        c = tiny_case()
        with tempfile.TemporaryDirectory() as temp:
            folder = Path(temp); sparse.save_npz(folder/'H.npz', c['H'])
            np.savez(folder/'model.npz', **{k: c[k] for k in ['X', 'normals', 'faces', 'fixed', 'free', 'b', 'Y', 'area_mass', 'gap0', 'clearance', 'mass_lower_bound']})
            theta = np.array([[.25], [1.], [.5]]); states = np.maximum(theta@c['Y'].T, c['b'])
            np.savez(folder/'response_0.npz', theta=theta, states=states, duals=states-theta@c['Y'].T)
            (folder/'response_0.json').write_text('{}')
            result = load_endpoint(folder, c)
            self.assertEqual(result['peak_index'], 1)
            np.testing.assert_allclose(result['y'], [-.2, -.2])
            c['X'] = c['X'].copy(); c['X'][1, 0] += 1e-3
            with self.assertRaisesRegex(ValueError, 'X'):
                load_endpoint(folder, c)


if __name__ == '__main__':
    unittest.main()
