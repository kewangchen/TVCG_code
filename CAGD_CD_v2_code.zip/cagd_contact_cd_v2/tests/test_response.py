import itertools
import numpy as np
import pytest
from scipy import sparse
from cagd_contact_cd_v2.src.response import BranchResponseSolver,residual_gap_bound

def enumerated(H,b,y):
    n=len(b);best=None
    for bits in itertools.product([False,True],repeat=n):
        A=np.flatnonzero(bits);F=np.flatnonzero(~np.array(bits));u=b.copy()
        if len(F):u[F]=np.linalg.solve(H[np.ix_(F,F)],(H@y)[F]-H[np.ix_(F,A)]@b[A])
        lam=H@(u-y)
        if np.min(u-b)>=-1e-9 and np.min(lam[A],initial=0)>=-1e-9 and np.max(abs(lam[F]),initial=0)<1e-9:
            if best is None:best=u.copy()
            else:np.testing.assert_allclose(best,u,atol=1e-9)
    assert best is not None
    return best

def test_residual_gap_bound_and_feasible_pair_are_the_same():
    H=np.array([[3.,.4],[.4,2.]]);b=np.zeros(2);y=np.array([-1.,.5]);u=np.array([.01,.7]);lam=np.array([3.,.1])
    mu=np.linalg.eigvalsh(H).min()
    r=residual_gap_bound(sparse.csc_matrix(H),b,y,u,lam,mu)
    exact=.5*(u-y-np.linalg.solve(H,lam))@H@(u-y-np.linalg.solve(H,lam))+lam@(u-b)
    assert r['gap_upper']>=exact-1e-14
    with pytest.raises(ValueError):residual_gap_bound(sparse.csc_matrix(H),b,y,-np.ones(2),lam,mu)
    with pytest.raises(ValueError):residual_gap_bound(sparse.csc_matrix(H),b,y,u,lam,0)

def test_rank_three_branches_match_independent_enumeration():
    rng=np.random.default_rng(77);B=rng.normal(size=(5,5));H=B.T@B+2*np.eye(5);Y=rng.normal(size=(5,3))*.2
    b=np.full(5,-.03);s=BranchResponseSolver(sparse.csc_matrix(H),b,Y,m=2,max_regions=2)
    for theta in rng.normal(size=(18,3)):
        z=s.solve(theta)
        np.testing.assert_allclose(z['u'],enumerated(H,b,Y@theta),atol=1e-8,rtol=1e-8)
        assert z['kkt']<1e-7
        assert s.memory()['region_count']<=2
        assert s.memory()['inverse_column_bytes']==0

def test_cached_response_hit_preserves_error_and_skips_forward_solve():
    H=sparse.csc_matrix([[3.,.5],[.5,2.]]);b=np.zeros(2);Y=np.array([[-1.],[.2]])
    s=BranchResponseSolver(H,b,Y,m=1.5,max_regions=2)
    a=s.solve([1.]);count=s.stats['qp_solves'];z=s.solve([1.001])
    assert z['cache_hit'] and s.stats['qp_solves']==count
    assert np.min(z['u']-b)>=0 and np.min(z['lam'])>=0
    assert z['h_error_bound']<1e-8
    np.testing.assert_allclose(z['u'],enumerated(H.toarray(),b,Y[:,0]*1.001),atol=1e-10)

def test_weak_contact_and_reversal_are_resolved_by_new_solves():
    H=sparse.eye(2,format='csc');b=np.zeros(2);Y=np.array([[1.],[-1.]])
    s=BranchResponseSolver(H,b,Y,m=1,max_regions=1)
    for t in [0.,.01,.02,-.01,-.02,0.,.015]:
        z=s.solve([t]);np.testing.assert_allclose(z['u'],np.maximum(Y[:,0]*t,0),atol=1e-12)
        assert z['kkt']<1e-9

def test_fixed_model_is_owned_and_invalid_basis_rejected():
    H=sparse.eye(3,format='csc');b=np.zeros(3);Y=np.ones((3,1))
    s=BranchResponseSolver(H,b,Y,m=1,max_regions=1);Y[:]=99;b[:]=99;H.data[:]=99
    np.testing.assert_allclose(s.solve([.2])['u'],.2)
    with pytest.raises(ValueError):s.solve([1.,2.])

def test_updated_factor_backend_matches_refactor_through_contact_switches():
    rng=np.random.default_rng(19);B=rng.normal(size=(7,7));H=B.T@B+np.eye(7);Y=rng.normal(size=(7,3))*.1;b=np.full(7,-.02)
    up=BranchResponseSolver(sparse.csc_matrix(H),b,Y,m=1,backend='updated')
    direct=BranchResponseSolver(sparse.csc_matrix(H),b,Y,m=1,backend='refactor')
    for x in rng.normal(size=(12,3)):
        a=up.solve(x);c=direct.solve(x)
        np.testing.assert_allclose(a['u'],c['u'],atol=1e-8,rtol=1e-8)

def test_unique_memory_report_counts_duplicate_models_and_native_capacity():
    H=sparse.diags([[-1.]*8,[4.]*9,[-1.]*8],[-1,0,1],format='csc')
    s=BranchResponseSolver(H,np.full(9,-.1),np.linspace(-1,1,9),m=1,max_regions=2)
    s.solve([.5]);m=s.memory()
    assert m['current_retained_numeric_bytes']==m['current_python_numeric_bytes']+m['native_factor']['native_tracked_bytes']
    assert m['current_python_numeric_bytes']>=2*(s.H.data.nbytes+s.H.indices.nbytes+s.H.indptr.nbytes)
    assert m['current_retained_numeric_bytes']>=m['native_factor']['retained_numeric_payload_bytes']+m['response_bytes']
    assert m['active_factor_bytes']==m['native_factor']['native_tracked_bytes']
    assert 'peak_owned_array_bytes' not in m
