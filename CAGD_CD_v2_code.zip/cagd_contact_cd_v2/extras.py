"""Reproduce the separately frozen precision, abrupt-order and memory studies."""
from pathlib import Path
import argparse,hashlib,json,subprocess,sys
import numpy as np
from .cases import MAIN,build,path
from .src.response import BranchResponseSolver
from .benchmark import dump
ROOT=Path(__file__).resolve().parent

def run(task,phase,reference_phase='formal_03'):
 out=ROOT/'results'/phase
 if task=='memory':
  dest=out.with_suffix('.json')
  if dest.exists():raise RuntimeError('Choose a new phase name; existing records are preserved.')
  rows=[]
  for name in MAIN:
   c=build(name,'fine');solver=BranchResponseSolver(c['H'],c['b'],c['Y'],c['mass_lower_bound']);states=[]
   for theta in path():states.append(solver.solve(theta)['u'])
   ref=np.load(ROOT/'results'/reference_phase/f'{name}_fine_r1/response_0.npz')['states'];difference=float(np.max(abs(np.array(states)-ref)))
   if difference>1e-11:raise RuntimeError('Memory replay and timed states differ.')
   rows.append(dict(case=name,memory=solver.memory(),maximum_difference_from_timed_states=difference))
  dump(dest,rows);return
 if out.exists():raise RuntimeError('Choose a new phase name; existing records are preserved.')
 out.mkdir(parents=True);isprox=task=='prox';cases=MAIN if isprox else ['strip','torus','nist_ctc_02'];methods=['proxqp']if isprox else ['response','warm_update','condensed'];rank=1 if isprox else 3;level='base'if isprox else'fine';count=41 if isprox else 31;repeats=3 if isprox else 2
 dump(out/'protocol.json',dict(task=task,cases=cases,methods=methods,rank=rank,level=level,count=count,repeats=repeats,kind='smooth'if isprox else'abrupt',prox_eps=1e-11 if isprox else None,source_sha256={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()for p in [Path(__file__),ROOT/'benchmark.py',ROOT/'cases.py',ROOT/'src/response.py',ROOT/'src/chol_update.py']}))
 for name in cases:
  for rep in range(repeats):
   for method in methods[rep%len(methods):]+methods[:rep%len(methods)]:
    cmd=[sys.executable,'-m','cagd_contact_cd_v2.benchmark','--worker','--folder',str(out/f'{name}_{level}_r{rank}'),'--case',name,'--level',level,'--rank',str(rank),'--method',method,'--repeat',str(rep),'--count',str(count),'--kind','smooth'if isprox else'abrupt','--prox-eps','1e-11']
    subprocess.run(cmd,check=True,timeout=300)
 dump(out/'completed.json',dict(runs=len(cases)*len(methods)*repeats,query_solves=len(cases)*len(methods)*repeats*count))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--task',choices=['memory','prox','abrupt'],required=True);p.add_argument('--phase',required=True);p.add_argument('--reference-phase',default='formal_03');a=p.parse_args();run(a.task,a.phase,a.reference_phase)
