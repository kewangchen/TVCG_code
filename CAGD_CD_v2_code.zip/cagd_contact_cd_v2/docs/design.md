# Bounded branch response for repeated ordered-chart correction

User-authorized continuation of the fixed-metric C+D study. Preserve all old
sources/results and submission packages. Goal: reduce checking and retained
inverse-column work, eliminate fine-grid reversal on measured regimes, and
verify CAD-derived editing on actual public STEP/BRep sources.

## Alternatives and chosen design
1. Optimize existing Schur column assembly and skip redundant gap inverses.
   Necessary strong baseline, but dense inverse actions still scale with n|A|.
2. Matrix-free Schur Krylov with sparse-factor preconditioner. Less storage,
   but many H inverse actions near dense contact; defer unless profiling favors.
3. Bounded affine-region response with sparse reduced-space fallback (chosen).
   For an application-supplied low-rank reference y=y0+Y theta, store only a
   center primal/dual pair, its n-by-r response, and conservative region margins.
   Reuse avoids both QP and directional solves. A fixed number of regions keeps
   response storage O(nrB); sparse factorization replaces unbounded inverse
   columns at region construction. Residual-based feasible gap upper bounds
   avoid H^{-1} during decisions. Full terminal KKT checks remain paid.

Classical mpQP/explicit-MPC precedents must be attributed. No first parametric
QP/caching claim. Existing shape-error and directional results remain in scope.
Numerical formulas are ordinary floating point, not outward-rounded guarantees.

## Evaluation
All methods use the identical problem, input basis, query stream and attained
KKT criterion. Include original Schur, streamlined Schur, warm reduced-space,
real OSQP and an explicit-region ablation without error margins. Count setup,
all lazy responses, misses/rejections, checker work, total factors and actual
retained/peak-owned-array payload. RSS is reported separately with its scope.
Prespecify base and fine-grid, rank-1 and rank-3 edit sequences and repeated
contact opening/closing. Preserve losses. Performance claims follow results.

## CAD
Import public authored STEP/BRep data with a geometry kernel, preserve source
hashes/licenses and exact selected face IDs. Derive paired clearance layers
from actual tessellated CAD faces; state that these are CAD-derived paired-layer
edits, not industrial assembly collision simulation or control-net optimization.
Include full-part context and selected-face geometry, endpoint intersection and
area/stretch metrics. Retain six representative main geometries with CAD cases;
full procedural suite remains supplementary.
