# Strong Schur comparators and the old fine-grid bottleneck

The condensed Schur comparator reduces both runtime and retained contact-cache
payload in the two exploratory fine-grid runs below. It uses a standard
organization of the same Schur equations. The active-set rule, objective,
stopping tolerance, fallback and warm-start policy are inherited without changes
from `src/frozen_baseline.py`; this comparator supplies no new optimization or
parametric-QP result.

## Implementation and accounting

`CondensedSchurSolver(H,b,indices=None,batch_size=8)` retains the inverse
principal block `G = H^{-1}[C,C]`, where `C` contains only indices encountered in
current or previous branch calls. A new index requires one unit-column solve.
The implementation solves at most eight such columns together, samples them at
`C`, fills the old-new block by symmetry and discards the full inverse columns.
For the ordered active set `A`, it factors `G[A,A]` and reuses that factor while
`A` is unchanged. It reconstructs `u = y + H^{-1} lambda` with the common sparse
LU factor. The public `inverse_columns(A)` compatibility helper also uses bounded
batches and returns transient columns without changing retained storage.

`StreamlinedSchurSolver(H,b,indices=None)` retains the full inverse-column
dictionary and the assembled `W` for the current ordered `A`. An unchanged `A`
therefore reuses both `W` and its Cholesky factor. It provides a full-column
comparison without the frozen code's redundant `column_stack` on such repeats.
Its `W` adds a retained copy, so its memory is not the frozen code's memory.

Both classes expose the inherited `solve(y,warm=True)`, `branch(y,A,target=None)`,
`active`, `factor`, `H`, `b`, `n` and `stats`. `memory_payload()` reports direct
array-byte counts for retained contact storage and an allocation-site estimate
for peak owned numerical arrays. The fields explicitly identify their scope.
They exclude Python objects, allocator capacity, uninstrumented short-lived
indexing/expression work, BLAS workspaces and hidden SuperLU work storage. Sparse
factor bytes count only the exposed `L`, `U` and permutation numerical payload;
they do not measure RSS or the complete native factor allocation.

With `n` unknowns, `m = |C|` encountered contacts and `a = |A|`, the condensed
floating-point cache has `8m^2 + 8a^2` bytes, plus index arrays. The frozen
full-column cache has `8nm + 8a^2` bytes; its transient assembled `W` has another
`8na` bytes. Streamlined Schur retains this `W`. Condensed lookup storage adds
`8n` bytes and is reported separately from contact-cache bytes. Condensed storage
still grows quadratically in the encountered contact count; it is not a bounded
memory algorithm.

Matrix copies remain paid. Growing `G` temporarily holds its old and new dense
blocks. Selecting a principal block allocates a dense matrix, and conversion to
Fortran order can temporarily hold another copy alongside the previous active
factor. Cholesky receives that Fortran-order array with `overwrite_a=True`.
The full-column method creates dense unit RHS and solution blocks for all new
contacts and then copies their columns into the dictionary. The condensed
method bounds those RHS and solution blocks by `n x batch_size`, but it pays a
sparse reconstruction solve for every nonempty branch. The allocation-site
peak estimates include these identified copy/solve sites; formal RSS must be
measured separately in fresh processes.

## Independent correctness tests

`tests/test_strong_baseline.py` contains 13 passing tests. The first test failed
before the implementation existed. Subsequent tests compare both organizations
with independent exhaustive primal-face enumeration on small coupled SPD
problems and with the actual OSQP implementation on 19-variable problems. They
also compare frozen active sets and iteration counts; exercise increasing,
overlapping and reordered active sets; change the target; verify same-set
factor reuse and unit-column counts; test an empty initial active set and invalid
batch size; and check direct inverse-column calls cannot populate the condensed
solver's inherited full-column cache. The latter regression failed before its
fix. The fresh test output is saved in `results/profile_tests.log`.

## Exploratory fine-grid profile

`results/profile_finegrid.py` uses the copied procedural model with refinement
factor three: strip has 6,136 unknowns and torus has 7,195. It evaluates the same
11 values of the old edit path for each method, with one cProfile run per method
in the fixed order frozen, streamlined, condensed. Timings include sparse-factor
setup, all queries and independent terminal KKT checks. Geometry construction
is excluded. BLAS thread environment variables are one. These fixed-order,
single-repeat instrumented runs identify costs; they are not a formal speedup
estimate. Formal comparisons require rotated repeated runs.

| Case | Frozen Schur (s) | Streamlined full columns (s) | Condensed Schur (s) |
|---|---:|---:|---:|
| Strip, n=6136 | 4.950 | 4.777 | 2.753 |
| Torus, n=7195 | 14.596 | 15.343 | 9.487 |

All six paths meet the common `2e-9` terminal KKT threshold. The largest residual
is `4.47e-15`. Each method encounters 1,604 inverse columns and performs 34 active
factorizations on strip; torus encounters 2,407 columns and performs 42 active
factorizations. Both cases have eight active-factor reuses and no fallback.
Thus these runtime differences do not arise from skipping active-set iterations.
Streamlined full columns is slower than frozen Schur on the torus pass; that
outcome is retained. An earlier exploratory pass was slower overall despite
the same normal branch path. It is preserved as
`results/profile_finegrid_pre_compatibility.json`, with its exact baseline source
snapshot `results/profile_strong_baseline_pre_compatibility.py` and recorded
SHA256. This timing variation is another reason to defer precise gains to the
formal protocol.

| Case | Frozen retained contact cache (MB) | Streamlined retained contact cache (MB) | Condensed retained contact cache (MB) | Streamlined own-array peak estimate (MB) | Condensed own-array peak estimate (MB) |
|---|---:|---:|---:|---:|---:|
| Strip | 78.739 | 79.426 | 20.597 | 305.520 | 93.303 |
| Torus | 138.550 | 139.701 | 46.372 | 574.808 | 211.943 |

MB denotes decimal megabytes. Contact-cache columns exclude the common model,
sparse LU, vectors and lookup. Peak-estimate columns include those numerical
payloads with the scope qualifications above. Condensed retained own-array
payload is 34.951 MB on strip and 81.073 MB on torus; its exposed sparse-factor
payload is 12.769 MB and 32.801 MB, respectively. Frozen peak memory was not
measured, so it is not inferred from its retained-column count.

The frozen profiles show repeated matrix assembly is material. On strip,
`inverse_columns` consumes 3.295 s cumulative, including 1.687 s in 42
`column_stack` calls and 1.517 s in five sparse multiple-RHS solves. On torus,
the corresponding costs are 9.336 s, 3.964 s in 50 `column_stack` calls and
5.174 s in five sparse solves. These cumulative costs overlap and must not be
summed again. Active Cholesky consumes another 0.614 s on strip and 2.576 s on
torus. Condensed reconstruction itself consumes 0.083 s and 0.213 s, respectively.

We separately replay the old `certified_horizon` checker on ten transitions
between existing, saved Schur states at indices `0,4,...,40`. Replay starts with
an empty checker cache and includes its lazy branch construction. It costs
2.512 s on strip and 6.610 s on torus. Its direction `branch` calls account for
2.392 s and 6.392 s; `gap_certificate` accounts for only 0.025 s and 0.049 s.
The old fine-grid checker bottleneck in this replay is chiefly the direction
branch and its inverse-column work. This result does not support attributing
the reversal chiefly to the extra scalar gap inverse.

Raw per-query outcomes, counts, payloads, environment, source hashes and the top
50 cProfile function records are in `results/profile_finegrid.json`; each profile
also has a `results/profile_<case>_<method>.prof` file. Saved old-state hashes
are in `results/profile_checker_inputs.json`. The executed source hashes were
unchanged during the runs. No prior study source or result was modified.

Reproduce from the workspace root:

```sh
PYTHONPATH=.:/private/tmp/cagd_cd_dependencies OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 .venv/bin/python -m pytest cagd_contact_cd_v2/tests/test_strong_baseline.py -q
PYTHONPATH=.:/private/tmp/cagd_cd_dependencies OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 .venv/bin/python cagd_contact_cd_v2/results/profile_finegrid.py
```
