# CHOLMOD contact row modifications

`src/chol_update.py` provides `UpdateFactor(H,initial_active=None,backend=...)`,
`update(active)`, `solve(rhs)`, `stats` and `memory_payload()`. The selected
production backend is `backend='rowmod'`. The default remains `rank2` so the
spectral rank-two organization can be selected explicitly as an ablation. Both
use real SuiteSparse CHOLMOD operations, with one initial AMD-ordered simplicial
factorization and a fixed permutation. Neither stores inverse columns.

This is established sparse linear algebra. Davis and Hager developed sparse
row/column modifications of LDL factorizations in [Row Modifications of a Sparse
Cholesky Factorization (2005)](https://doi.org/10.1137/S089547980343641X).
Changing Dirichlet conditions with sparse factor updates also has direct graphics
precedent in Herholz and Sorkine-Hornung's [Sparse Cholesky Updates for Interactive
Mesh Parameterization (2020)](https://doi.org/10.1145/3414685.3417828). This study
uses the library algorithms; it does not claim a new Cholesky update.

## Exact face system and right-hand side

For active coordinates A, free coordinates F and diagonal projectors P, factor

```
K_A = P_F H P_F + I_A.
```

The solution of `K_A u = rhs` gives the exact constrained primal face solution
when `rhs_F = q_F - H_FA b_A` and `rhs_A = b_A`. There is no penalty parameter.
The multiplier is zero on F and `(H u-q)_A` on A. For derivative solves with
fixed bound values, set the active derivative RHS to zero. The wrapper accepts
either a vector or multiple dense right-hand sides.

Activation deletes the corresponding row/column through native
`cholmod_rowdel`, replacing it by the identity row/column. Release calls native
`cholmod_rowadd` with the original H column restricted to the current free
coordinates and its own diagonal. Original indices and sparse column supports
are mapped through the factor's inverse permutation inside C. All released
coordinates are restored before newly active coordinates are deleted. Every
intermediate matrix is another SPD face matrix. The [matching public CHOLMOD
Modify header](https://github.com/DrTimothyAldenDavis/SuiteSparse/blob/v5.10.1/CHOLMOD/Include/cholmod_modify.h)
specifies these row-add/delete semantics.

For comparison, the rank-two backend uses
`delta = -e_i w^T-w e_i^T+(1-H_ii)e_i e_i^T` on activation, with w containing
currently free off-diagonal neighbors. Release reverses this change with the
appropriate current free neighbors. In the orthonormal basis
`[e_i,w/||w||]`, the change is a symmetric 2-by-2 matrix. Its positive eigenvalue
parts form sparse update columns, and its negative parts form downdate columns.
All positive parts are applied first; each subsequent downdate stays above the
final SPD matrix in exact arithmetic. Actual calls are
`sksparse.cholmod.Factor.update_inplace(C,subtract=...)`, as specified by the
[scikit-sparse documentation](https://scikit-sparse.readthedocs.io/en/stable/cholmod.html).
This generic split can introduce and then numerically cancel fill. Native row
modifications avoid that split.

## Native binding and memory scope

The rowmod adapter is embedded as C source in `chol_update.py`. Its C compilation
includes the real, version-matched CHOLMOD headers. Python ctypes passes opaque
handles, scalar sizes and contiguous array pointers; it declares no guessed
CHOLMOD structure layouts. C owns the common object, factor and inverse
permutation, frees temporary sparse RHS columns and solve arrays, and releases
the factor on wrapper destruction. The adapter uses the 32-bit CHOLMOD API and
real double values. It is tested at the dimensions used by this study.

`memory_payload()` on rowmod reads CHOLMOD's `Common.memory_inuse` and
`Common.memory_usage`, adding the adapter handle and inverse permutation. These
are native tracked retained and peak allocations, including factor capacity and
CHOLMOD workspaces. They are not RSS: BLAS allocations, Python objects and
allocator overhead are outside that scope. `retained_numeric_payload_bytes`
adds the Python-owned sparse H and numerical index/vector arrays to current
native tracked bytes. `native_peak_bytes` is reported separately because it
does not track simultaneous Python temporaries. No factor is exported to compute
this report. `factor_numeric_bytes` counts the used LDL/permutation sparse
representation and is smaller than allocated native storage.

Rank2's report extracts its exposed LDL representation and labels its scope
accordingly; scikit-sparse 0.4.7 does not expose the native allocator statistics.
That LDL extraction can allocate a copy and is only used on demand. Its
`max_update_payload_bytes` counts the explicit positive/negative sparse update
matrices. Rowmod does not construct these matrices, so that field remains zero;
its temporary native sparse columns are covered by native allocation statistics.

For rowmod, statistics `updates`/`updated_columns` count releases/native rowadd
calls; `downdates`/`downdated_columns` count activations/native rowdel calls.
For rank2 those fields count signed batch calls and their column counts.
`toggles`, `numeric_factorizations`, `solves` and timing fields retain their
literal meanings across backends. `active_reuses` counts unchanged active sets.

## Tests and exploratory replay

Fresh verification: `11 passed in 0.64s`. Both backends match independently
assembled dense systems across mixed activation/release sequences, all-active
and fully free states, isolated diagonal entries, multi-RHS solves and the
nonzero-bound primal RHS above. A sparse tridiagonal stress case performs 100
random contact-set changes and then restores the original fully free solve.
Both the missing implementation and missing rowmod backend failed their tests
before implementation. The root's separate response-kernel integration also
passed its six tests before formal benchmarking.

The following single-run microbenchmark replays 41 existing face sets from the
unchanged old `results/scaling/{strip,torus}_3/schur_0.npz` dual arrays. It uses
`flatnonzero(dual>1e-9)` only to construct this external kernel replay. It does
not supply future active sets to a QP solver or establish end-to-end QP speed.
Each face solves a unit RHS on F and zero RHS on A and checks `K_A x-rhs`.
The update totals include Python planning, updates, solves and these residual
checks; initialization is separate. The SuperLU comparator freshly factors
`H_FF` with `MMD_AT_PLUS_A` and solves on every one of the 41 faces, including
repeated faces, so it is a refactor microbenchmark rather than a warm-PDAS
comparison. BLAS environment variables were set to one.

| Case | n | Toggles | Rank2 setup / 41 faces (s) | Rowmod setup / 41 faces (s) | Fresh SuperLU 41 faces (s) |
|---|---:|---:|---:|---:|---:|
| Strip | 6136 | 3072 | 0.032 / 3.408 | 0.036 / 0.309 | 2.096 |
| Torus | 7195 | 4596 | 0.132 / 16.865 | 0.126 / 1.610 | 25.445 |

Rowmod's largest residual is `1.39e-13`; rank2's is `4.75e-13`. Both perform one
numeric factorization and 41 solves. Strip has ten unchanged-set reuses; torus
has eleven. Rank2's native update time is 3.015/16.188 s, planning time
0.293/0.466 s and solve time 0.081/0.190 s. Rowmod's update time is
0.260/1.518 s and solve time 0.036/0.077 s. These are exploratory kernel costs,
not repeated formal timing estimates.

| Case | Initial used factor nnz | Final rank2 used nnz | Final rowmod used nnz | Final rowmod capacity nnz | Rowmod tracked native retained / peak (MB) |
|---|---:|---:|---:|---:|---:|
| Strip | 436012 | 1116471 | 436012 | 628106 | 8.007 / 8.417 |
| Torus | 967307 | 2966743 | 967307 | 1393522 | 17.272 / 17.618 |

MB is decimal. Rowmod retains the original used factor pattern in these replays
while native allocation capacity grows. Its final total retained numerical
payload, including H and Python arrays, is 9.469 MB on strip and 19.029 MB on
torus. Rank2's exposed LDL payload grows from 5.281 to 13.447 MB and from
11.665 to 35.658 MB. The distinction between used entries and native capacity
must remain visible in formal results.

## Tested dependency and build recipe

The machine already contains Julia 1.8.5 with SuiteSparse 5.10.1 / CHOLMOD
3.0.14 under `/usr/local/Cellar/julia/1.8.5/lib/julia`. Xcode 14's existing
compiler and SDK are usable with explicit paths; no developer tools were
installed. The system-selected command-line developer path is broken, so the
build uses the installed Xcode paths below. Rowmod needs no Julia process,
startup, IPC, scikit-sparse Python import or runtime compilation. Its shared
library is loaded once by ctypes. Initialization and loading are included in
the factor-setup timing.

1. Install matching public SuiteSparse headers/libraries outside the study
   package, using a system or conda-forge SuiteSparse distribution. For this
   tested environment, download the public headers from the exact Git tag
   `v5.10.1`, retaining the upstream notices. The directory
   `/private/tmp/cagd_v2_chol_deps/include` contains `cholmod.h`,
   `cholmod_config.h`, `cholmod_core.h`, `cholmod_check.h`,
   `cholmod_cholesky.h`, `cholmod_matrixops.h`, `cholmod_modify.h`,
   `cholmod_supernodal.h`, `cholmod_partition.h`, `cholmod_camd.h`,
   `cholmod_io64.h` from `CHOLMOD/Include`, and `SuiteSparse_config.h` from
   `SuiteSparse_config`. The source URL prefix is
   [SuiteSparse v5.10.1](https://github.com/DrTimothyAldenDavis/SuiteSparse/tree/v5.10.1).
2. Compile the embedded adapter explicitly. It is never compiled during a solve:

```sh
DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer SDKROOT=/Applications/Xcode.app/Contents/Developer/Platforms/MacOSX.platform/Developer/SDKs/MacOSX.sdk .venv/bin/python - <<'PY'
from cagd_contact_cd_v2.src.chol_update import build_rowmod_library
build_rowmod_library(
    '/private/tmp/cagd_v2_chol_deps/include',
    '/usr/local/Cellar/julia/1.8.5/lib/julia',
    '/private/tmp/cagd_v2_chol_deps/libcagd_rowmod.dylib',
    compiler='/Applications/Xcode.app/Contents/Developer/Toolchains/XcodeDefault.xctoolchain/usr/bin/clang')
PY
```

The helper writes the C source and binary only to the external prefix. This
tested helper uses macOS `-dynamiclib`; on Linux, extract `_NATIVE_SOURCE` and
compile with `cc -O3 -std=c99 -shared -fPIC -I<include> -L<lib> -lcholmod
-Wl,-rpath,<lib>`, then set `CAGD_CHOLMOD_ROWMOD_LIB` to that `.so`. Linux has not
been tested here. Use headers matching the installed native ABI. No binary or
downloaded header is part of the research source package.

3. For the optional rank2 ablation, the tested public prebuilt wrapper is
   [conda-forge scikit-sparse 0.4.7, CPython 3.9, macOS x86_64](https://conda.anaconda.org/conda-forge/osx-64/scikit-sparse-0.4.7-py39ha5703b5_0.tar.bz2).
   Extract it into `/private/tmp/cagd_v2_chol_deps`, with SHA256
   `f4848022bd40eba57b6d89b2594913ed6e523d0d3fea8799313457f3230a0e90`.
   The binary requires SuiteSparse 5.x and NumPy `<2`; this run uses NumPy
   1.26.2, SciPy 1.13.1 and Python 3.9.7. The proposed `cmeel-suitesparse`
   package was unavailable from both configured and public PyPI indexes.

```sh
PYTHONPATH=.:/private/tmp/cagd_v2_chol_deps/lib/python3.9/site-packages DYLD_FALLBACK_LIBRARY_PATH=/usr/local/Cellar/julia/1.8.5/lib/julia OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 .venv/bin/python -m pytest cagd_contact_cd_v2/tests/test_chol_update.py -q
```

Rowmod alone runs with plain `.venv/bin/python` because its compiled rpath
locates the native libraries. Override `CAGD_CHOLMOD_ROWMOD_LIB` when the adapter
is installed elsewhere. The rank2 backend additionally needs the Python package
and native-library search paths above.

The scikit-sparse wrapper carries its [BSD 2-clause license](https://github.com/scikit-sparse/scikit-sparse/blob/v0.4.7/LICENSE.txt).
SuiteSparse modules are licensed separately. The exact dependency's
[CHOLMOD license collection](https://github.com/DrTimothyAldenDavis/SuiteSparse/blob/v5.10.1/CHOLMOD/Doc/License.txt)
contains the Modify-module copyright and GNU GPL terms, and separate LGPL
terms for Core/Cholesky. The Modify source credits Timothy A. Davis and
William W. Hager. The study adapter dynamically calls these external modules;
it vendors neither their implementation sources nor native binaries.

Observed native binary SHA256 values:

```
libcagd_rowmod.dylib: e919703c97de44bd629b5488b44b5c76c474171a33c5bdc8931af62f19b905e6
libcholmod.3.0.14.dylib: 6a4e002ff7e404573cc767ac1d82cade10a78dfc60d7894ae62b9536c5dcc874
```

Key matching-header SHA256 values:

```
cholmod.h: c2f989c34da479f923b0e731daa77b37122c2586e85faea34e4f1c1766a63820
cholmod_core.h: fbe6ae08bd57106a0a92d6d3bda3f2656d7d7fe6769b5910af8965e0b71eee84
cholmod_modify.h: 3142938471a939aa55aaae1b4edccab136b85be45aafdab508e153138f700ef6
SuiteSparse_config.h: 7e5ef3ed845f6d8b13d0a3c8735629f1c6c8eb04985e99232c9dbba60c464fdf
```
