# Independent final scientific review

Reviewed the assembled author manuscript and supplement, final statistics,
corrected memory replay, six endpoint geometry audits, directional records,
abrupt stress records, numerical source and reproduction instructions. This
was read-only except for this report. No QP, geometry audit, full test suite or
timing workload was rerun; checks used the saved JSON/NPZ arrays, light numerical
reductions and source inspection. The root reports 44 passing tests. A clean
extracted release archive was not yet available for this review.

**Verdict: no P1 scientific, theoretical or numerical reporting blocker found.**
The principal claims match the supplied records, the central error statements
are valid under their stated exact-arithmetic assumptions, and the manuscript
attributes the dominant performance gain to established native row updates.
The remaining material completion item is the executable reproduction coverage
of the supplementary experiment phases, described below.

## Remaining material item

**[P2] Supply exact supplementary reproduction commands/drivers before freezing
the source archive.** The current `REPRODUCE.md` covers the main smooth suite,
geometry, directions, statistics and figures. It does not yet give a complete
executable recipe for generating `memory_replay.json`, the 18-worker
`abrupt_01` phase and the 18-worker `prox_precision_01` phase. The benchmark
worker exposes the required `--kind abrupt --count 31` and `--prox-eps 1e-11`
options, so this can be closed with documented loops or small drivers without
changing any numerical algorithm. The memory replay also needs its saved driver,
including comparison against the corresponding frozen timed states and the
source hash written into each row.

The rerun example creates a phase called `rerun`, whereas the following
`python -m cagd_contact_cd_v2.statistics` command always summarizes frozen
`formal_03`. The README explains that default, but should also give the explicit
`aggregate('rerun')` call when users intend to analyze their new run. Keep the
ProxQP precision-phase selection explicit so a new main phase cannot silently
mix with an older precision folder. Finally, test an extracted archive using
only its documented dependencies and native adapter build path. Workspace test
success does not establish archive completeness. This is a packaging/reproduction
completion item, not evidence of an invalid numerical result.

## Claim-to-record checks

- Refined rank-one Schur ratios are 4.409323--15.147643, geometric mean
  6.963617, matching 4.41--15.15 and 6.96. OSQP ratios are
  2.821322--8.527386, geometric mean 5.429364. The rank-three Schur geometric
  mean is 6.927002. Main timing table medians agree with `statistics.json`.
- The native-only ablation has refined rank-one warm/proposed ratios
  0.930593--1.062060, geometric mean 0.998202. The paper accurately states
  that native row modifications dominate the gain, retains small-grid Schur
  wins and response-layer losses, and does not claim a universal cache speedup.
- Abrupt-path ratios recomputed from the two-repeat medians are 2.201987,
  1.321633 and 4.346245 for strip, torus and CTC-02. They match the stated
  1.32--4.35 range and the supplemental timings. These are separate 31-query
  stress tests, not additional main smooth repetitions.
- The main phase contains 198 workers and 8,118 query requests. Its four
  common methods account for 7,380 qualified requests. The additional ProxQP
  precision phase is separately identified. The base-torus residual failure
  is retained, and qualified ProxQP summaries count five cases rather than
  treating its package status as sufficient. ProxQP is not portrayed as
  covering the refined meshes.
- The six memory replay rows all record zero maximum difference from the
  frozen timed states. Their unique Python/native/combined MiB values agree
  with the supplementary table. Main figures use worker RSS and current
  nested native/response payloads, rather than the deprecated historical
  aggregate peak estimate. Current retained payload is not mislabeled as a
  simultaneous process or Python/native peak.
- Saved rank-three bases have numerical rank three, and their centered saved
  coefficient trajectories have rank three. This supports the stated
  multidimensional trajectory experiment; it remains a prescribed curve,
  rather than exhaustive exploration of a three-dimensional parameter box.
- The largest saved opening-response relative error at step `1e-6` is
  `7.610686e-10`. All 24 feasible perturbation tests satisfy their recorded
  H-error bounds. The first-contact construction identifies weak coordinates
  analytically; the derivative comparison is accurately called a local
  mechanism test rather than a dQP/dXPP implementation benchmark.

## Theory and interpretation

The feasible gap identity and combined primal/dual error inequality have the
correct signs and factors. Coordinate radii follow from dual-metric
Cauchy--Schwarz. The pointwise stored-response theorem preserves the support
identities, derives feasibility and complementarity from its own query margins,
and bounds the residual by the center term plus response residual gains. It can
accept a later query without assuming a strictly classified center. The
supplement correctly distinguishes that result from segment propagation from
a general feasible, completely classified center. Constant actual gap is only
asserted with the additional complementary-center condition.

The fixed-size Dirichlet system has the correct active and free blocks and is
uniformly SPD by `min(m,1)`. Native row modifications are an implementation of
established algebra. The signed rank-two alternative and positive-update-first
argument are valid, with temporary fill explicitly separated from the response
storage bound. The analytic mass lower bound follows from a positive diagonal
mass term plus PSD stiffness and biharmonic terms after principal restriction.
It does not require treating a rounded smallest eigenvalue as a rigorous bound.

The critical-cone directional proof is valid for an independently identified
exact forward partition. Its cone-dual signs and slope enclosure are correct,
including the extra terms for approximate slope coefficients. The paper does
not use a small cone residual to certify an unknown forward partition.

The manuscript explicitly limits theorem guarantees to exact arithmetic and
describes the `64*eps` terms as numerical cushions. Ordinary terminal KKT audits
are not represented as interval certificates. The optional H-error threshold
is correctly described as a hit filter, unset in this protocol, rather than an
end-to-end fallback error-budget contract. Fixed-model/new-solver requirements
must remain a caller contract; they should not imply automatic detection of
arbitrary mutation of public solver arrays.

Attribution is proportionate. Multiparametric affine regions, partial
enumeration, bounded factor caches, low-rank mpQP storage, Gap Safe localization,
Davis--Hager/CHOLMOD row modifications and the changing-Dirichlet graphics
precedent are all identified. The claimed contribution is the inexact-response
acceptance/error accounting and concrete editing workflow, not first discovery
of affine QP maps, finite caches or sparse factor updates. Local Schur and
frozen-equality programs are not misrepresented as complete external packages.
All citation keys used by both assembled manuscripts resolve in the bibliography;
this review did not independently repeat the separate full metadata search.

## Geometry and reference checks

The optimization reference and shape-measurement reference are distinct and
consistently used. Correction energy is measured against the supplied edited
field y. Area, local singular values, conformal ratios, angle changes and
intrinsic strain are measured against the nominal layers `u=0`. The audit source
explicitly constructs both references and stores target/reference energies
separately. The nodal clamp uses identical hard coordinates and lower bounds,
so its objective and geometric comparisons are meaningful.

Each displayed input has actual strict matching-face LP overlap witnesses;
the detected input counts are correctly not called exhaustive intersection
counts. All six saved base peak-edit outputs have passing interior-overlap and
nonadjacent closed-distance audits, zero saved hard-coordinate error and the
required corresponding nodal gap. Quality table entries agree with the saved
audit, including global output singular-value extrema 0.913002 and 1.185689.
These are endpoint and sampled-triangle measurements. The text does not turn
them into continuous collision-free trajectories, a global Euclidean minimum
distance guarantee, industrial assembly contact, or optimization of original
CAD control nets. The STEP origins, normalized coordinate transforms, selected
trimmed faces and synthetic paired-layer construction remain explicit.

## Minor corrections identified during review

Two P2 text/numeric issues were reported to the root and are now verified in
the regenerated standalone sources: the unsupported automatic
model-hash/array-immutability claim is replaced by the owned-copy/new-solver
contract, and first-repeat checking counters use their own first-repeat totals.
The latter gives 0.710296--3.882279%, reported as 0.71--3.88%, rather than the
earlier first-counter/median-total mix. These corrections do not change any
headline performance number or numerical kernel. Optional rank-two tests now
have an explicit missing-scikit-sparse skip fixture while retaining the native
rowmod tests. The root plans a final full test and PDF pass before packaging.

## Integration completion note after the independent review

The supplementary drivers are now executable through `extras.py` (precision, abrupt order and memory replay). `statistics.py` accepts explicit phase and precision-phase arguments and does not mix the original precision records into a differently named rerun. Optional scikit-sparse rank-two tests skip when that wrapper is absent; the primary native-rowmod tests remain active.

The release was extracted into a separate directory with the existing documented dependency environment. All44tests passed there. Complete statistics reconstructed from the extracted raw arrays exactly match the published JSON; rank-three procedural and CAD solves and an independent figure redraw succeed. The memory-only extra driver was also executed from the extraction and all six fine-grid state sequences agree with their timed states. These checks establish directory independence, not a new-machine installation or an executed Linux build.
