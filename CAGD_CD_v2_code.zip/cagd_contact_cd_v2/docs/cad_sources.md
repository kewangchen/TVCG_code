# Public authored CAD sources and import audit

The three models are original public **STEP BReps authored for the NIST MBE PMI
Validation and Conformance Testing Project**. The import script constructs no
replacement CAD surfaces. It imports trimmed faces through the OpenCASCADE
kernel in Gmsh, then exports kernel tessellations of the full parts and selected
faces. These are CAD benchmark models, not evidence of validation on a supplied
industrial assembly.

## Source, permission, and integrity

- [Official NIST model download and usage page](https://www.nist.gov/ctl/smart-connected-systems-division/smart-connected-manufacturing-systems-group/mbe-pmi-0).
- [Official NIST CTC definition archive](https://www.nist.gov/document/nist-ctc-test-case-definitions), downloaded on 2026-10-17.
- Original archive: `assets/raw/nist_ctc_definitions.zip`, retained byte for byte.
- Archive SHA-256: `79ebc74d99eb05c0d23de1c1d8730651fa2a24def56f647bac21dd439ec40690`.
- Original archive member `NIST_MBE_PMI_CTC_Definitions/README.txt` is also
  extracted as `assets/raw/README.txt`. It states that the test system was made
  by federal employees in their official duties, is public domain under
  17 USC 105, and may be used without restriction. It requests acknowledgment
  and disallows use of the NIST logo. Use does not imply NIST endorsement.
- No kernel binary is redistributed with this study. Gmsh is separately
  available under its own GPL license; OpenCASCADE's licensing is separate
  from the public-domain CAD source data.

The STEP geometry is supplied without PMI in this archive. The original PDFs,
source STEP files, and documentation remain available inside the retained ZIP.
The source file headers identify the geometry as CTC-01, CTC-02, or CTC-03 from
the NIST project. The files are not the procedural comparison geometries used
elsewhere in the study.

| Model | Exact archive STEP filename | STEP SHA-256 |
|---|---|---|
| NIST CTC-01 | `nist_ctc_01_asme1_rd.stp` | `bd5a73c58880ba9093f8dc653c87f4224d6a795459e7fb64f6fdc22ba76a02d3` |
| NIST CTC-02 | `nist_ctc_02_asme1_rc.stp` | `cd669778fbf9f11fa386a7fe8afe5a70513e3e17a5000e645d237dd4525d2775` |
| NIST CTC-03 | `nist_ctc_03_asme1_rc.stp` | `d4158ed46a3fb1d83c85cfec2e640bbaff8c28b2b39e1e66cb87fba9b7985af3` |

## Kernel and exact selected faces

Pinned importer: **Gmsh 4.15.2, OpenCASCADE 7.8.1**. The actual build string,
face inventory, units, triangulation settings, source hashes, and NPZ hashes
are recorded in each model's `metadata.json`. Each original STEP imports as
one solid. CTC-01 and CTC-03 have 139 kernel faces each; CTC-02 has 663.

Face IDs below are the Gmsh dimension-2 entity tags after importing the exact
source file with this pinned version. The corresponding source STEP
`ADVANCED_FACE` entity and underlying surface are recorded from traversal of
the source file's single `CLOSED_SHELL`; the complete traversal and kernel
inventory are retained in `face_inventory.json`. The kernel tags are scoped
to this importer/version and should not be treated as persistent names across
other CAD software or import settings.

| Model | Selected Gmsh faces | Source STEP ADVANCED_FACE entities | Geometry and trim |
|---|---|---|---|
| CTC-01 | 4 | #300 | Planar plate face; 12 boundary loops, including 11 inner wires |
| CTC-02 | 144 | #11742 | Authored bicubic B-spline blend face, source surface #11734 |
| CTC-03 | 8, 39, 15 | #238, #269, #245 | Connected planar sheet, radius-0.25-inch cylindrical bend, planar upright flange |

All exported coordinates are **millimetres**. No centering, rescaling,
projection, flattening, or normalization is applied. CTC-01 and CTC-02 use
millimetres in STEP. CTC-03 uses inch units; setting
`Geometry.OCCTargetUnit=MM` explicitly converts its source coordinates by
25.4. For example, the 0.25-inch bend radius becomes 6.35 mm.

## Exported data and resolution

Each `assets/nist_ctc_0*/` directory contains `full_part.npz`,
`selected_face_coarse.npz`, `selected_face_medium.npz`,
`selected_face_fine.npz`, `metadata.json`, and `face_inventory.json`.

| Model | Coarse nodes / triangles | Medium nodes / triangles | Fine nodes / triangles | Full-part nodes / triangles |
|---|---:|---:|---:|---:|
| CTC-01 | 807 / 1374 | 1904 / 3437 | 4560 / 8549 | 9607 / 19250 |
| CTC-02 | 635 / 1051 | 1946 / 3504 | 4622 / 8632 | 64044 / 128128 |
| CTC-03 | 878 / 1563 | 2097 / 3893 | 5113 / 9742 | 12648 / 25360 |

NPZ arrays use zero-based local node IDs:

- `X`: `(n,3)` coordinates in mm; `faces`: `(m,3)` triangle connectivity.
- `cad_face_ids`: one original Gmsh CAD face ID per triangle.
- `boundary_node_ids`, `boundary_edges`: actual selected-mesh boundary.
- `gmsh_node_tags`: original mesh-node tags before local reindexing.
- Selected meshes also contain `normals`, `uv`, `uv_face_ids`, and
  `node_face_uv`. The latter has rows `(local node ID, CAD face ID, u, v)`;
  it retains both parameter charts at shared CAD-face seams. `uv` selects the
  first incident face and `uv_face_ids` identifies that chart.

The CTC-03 CAD seams share vertex IDs. Normal directions come from kernel
derivatives, are aligned to a common triangle winding, and are averaged at
smooth shared seams. This is a consistent orientation for paired-layer edits;
no physical outward orientation is assumed. Coincident mesh seam nodes are
welded only at the documented relative rounding tolerance of 1e-12.

The selected meshes use first-order triangular Gmsh algorithm 6 with one
thread, a fixed size per level, no point sizing, and no extension of boundary
sizes into faces. Full-part context permits curvature refinement down to
0.1 mm. A large minimum size on context would collapse some small paired
semicircular CAD edges to identical diameters and create nonmanifold mesh
edges; the lower floor avoids that observed failure. All source faces remain
in the context exports.

Fine-mesh sampled minimum principal radii are approximately 9.99845 mm for
CTC-02 and 6.35 mm for CTC-03; CTC-01 is planar. These are reciprocal absolute
principal curvatures sampled at kernel mesh nodes, **not certified global
curvature bounds**. Fine minimum mesh edges are 5.12255, 0.735832, and
0.93218 mm respectively. Deriving paired layers requires an explicit offset
choice and independent endpoint checks; the importer supplies no claim that
an arbitrary offset remains embedded.

## Verification and scope

All nine selected meshes have one connected component, positive triangle
areas, no duplicate vertices or triangles, no nonmanifold edges, finite UVs,
unit normals, and consistent triangle/normal directions. All three full-part
meshes are closed, connected, and manifold. CTC-01 retains 12 boundary loops;
CTC-03 retains its shared CAD seam vertices. `assets/cad_preview.png` shows
full-part context and each selected face set and was visually inspected.

The selected meshes are independent remeshings, not nested subdivisions.
Their geometric approximation error changes with resolution. They preserve
the actual CAD trim loops and use the exact BRep for UV and normal evaluation.

Any paired clearance layers constructed from these faces are **synthetic
CAD-derived normal-offset edits**. They are not an original mechanical
assembly, physical contact experiment, or NURBS control-net optimization.

## Rebuild and offline audit

Install `gmsh==4.15.2` in a suitable Python environment, together with NumPy.
The supplied experiment Python is 3.9.7 with NumPy 1.26.2; SciPy is not needed
by this importer. A normal Gmsh wheel installation must include its platform
shared library. For this run Gmsh was installed in
`/private/tmp/cagd_v2_dependencies`; on macOS, pip's `--target` did not retain
the wheel's external shared-library layout, so `libgmsh.4.15.dylib` was
extracted from the same unmodified wheel into that temporary directory.

```sh
.venv/bin/python cagd_contact_cd_v2/cad_import.py build --gmsh-path /private/tmp/cagd_v2_dependencies
.venv/bin/python cagd_contact_cd_v2/cad_import.py verify
.venv/bin/python -m unittest discover -s cagd_contact_cd_v2/tests -p 'cad_*test.py'
```

Without `--gmsh-path`, the importer uses the environment's normal Gmsh
installation. Rebuilding took approximately 7.4, 28.3, and 5.3 seconds for
CTC-01, CTC-02, and CTC-03 on this run, including full-part context and all
three selected resolutions. Offline verification and five tests passed.
The temporary macOS kernel emitted a PETSc `getdomainname()` sandbox warning
at initialization; importing, meshing, normal evaluation, and validation all
completed successfully. Consuming or verifying the bundled NPZ files requires
only NumPy and does not initialize Gmsh.
