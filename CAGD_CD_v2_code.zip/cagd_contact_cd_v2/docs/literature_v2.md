# Prior-art and external-solver audit

Checked 2026-10-17 using primary publisher pages, author-hosted papers,
arXiv records and official solver documentation. The academic-search MCP
server named in the search skill is not available in this session; primary
web sources supply the evidence below. This is a focused related-work audit,
not an exhaustive systematic review.

## Direct precedents and the precise distinction

| Work and checked metadata | Established mechanism | Relation to the present design |
|---|---|---|
| Bemporad, Morari, Dua and Pistikopoulos (2002), *Automatica* 38(1), 3–20, [publisher/DOI](https://doi.org/10.1016/S0005-1098(01)00174-1), key `Bemporad2002Explicit` | Explicit constrained LQR/MPC via multiparametric QPs and piecewise affine optimizer maps. | Attribute affine optimizer branches and primal–dual critical regions here. The proposed cache is populated online for a supplied small edit map and tests conservative regions derived from an inexact center. |
| Pannocchia, Rawlings and Wright (2007), *Automatica* 43(5), 852–860, [publisher/DOI](https://doi.org/10.1016/j.automatica.2006.10.019), [author PDF](https://pages.cs.wisc.edu/~swright/papers/MPC-PEshort.pdf), key `Pannocchia2007PartialEnumeration` | Partial enumeration combines a small table of active-set solutions with online optimization and adapts the table during operation. | This is a direct predecessor for bounded online solution tables. Their controller includes a suboptimal current-step strategy; the present protocol accepts each query only after its own error/KKT conditions pass. The bounded cache itself is not new. |
| Ferreau, Bock and Diehl (2008), *International Journal of Robust and Nonlinear Control* 18(8), 816–830, [publisher/DOI](https://doi.org/10.1002/rnc.1251), key `Ferreau2008Online` | Online active-set QP continuation reuses the preceding solution and tracks changes along a parameter homotopy. | Attribute sequential reuse and primal/dual blocking to this line of work. A stored `r`-direction map reuses a response on a parameter neighborhood, with the stated residual error radius. |
| Ferreau, Kirches, Potschka, Bock and Diehl (2014), *Mathematical Programming Computation* 6(4), 327–363, [author PDF](https://publications.syscop.de/Ferreau2014.pdf), [official citation](https://www.coin-or.org/qpOASES/doc/3.2/doxygen/index.html), key `Ferreau2014qpOASES` | Mature parametric active-set implementation, homotopy steps, blocking tests, and factor updates. | The local Schur/PDAS programs are mechanism baselines. They are not implementations of the complete qpOASES algorithm or software. |
| Johnson, Kirches and Wächter (2015), *SIAM Journal on Optimization* 25(2), 967–994, [publisher/DOI](https://doi.org/10.1137/130940384), key `Johnson2015HotStarts` | Sequential hot-start QPs retain first-problem active-set information and reuse it within an iterative refinement/preconditioning scheme. | Reusing first-problem linear algebra for sequences is established. This paper's method is broader than a fixed `H` affine-reference branch cache; it does not provide the proposed margin/radius formula. |
| Bartlett and Biegler (2006), *Optimization and Engineering* 7(1), 5–32, [publisher/DOI](https://doi.org/10.1007/s11081-006-6588-z), [author PDF](https://bartlettroscoe.github.io/publications/QPSchurJournalPaper2006.pdf), key `Bartlett2006QPSchur` | A fixed base KKT system and dense Schur updates for active constraints, with a dual-feasible active-set algorithm. | The old inverse-column organization has a clear Schur precedent. The new implementation uses a sparse principal system during record construction and stores only the requested parameter responses. |
| Nielsen and Axehill (2016), [arXiv:1603.05034](https://arxiv.org/abs/1603.05034), [full paper](https://arxiv.org/pdf/1603.05034), key `Nielsen2016LowRank` | Low-rank modifications between neighboring critical regions compress a stored mpQP solution and region descriptions in a tree. | Their low rank comes from small changes to the active set across regions. Here the supplied edit matrix has few columns and each retained record stores its complete `n × r` response; the algorithm does not implement their inter-region tree compression. Attribute low-rank mpQP memory reduction explicitly. |
| Fedorová, Kohút and Kvasnica (2021), *IFAC-PapersOnLine* 54(6), 185–191, [publisher/DOI](https://doi.org/10.1016/j.ifacol.2021.08.543), [author publication list](https://www.uiam.sk/~kohut/?lang=en&show_id=3&show_pub=all), key `Fedorova2021Cache` | Stores recurring active-set KKT factors in a finite cache and studies replacement policies as a function of cache size. | This is a direct prior bounded-cache/replacement-policy result. Our records store affine primal–dual responses and conservative acceptance margins; cached factors and bounded replacement are not a first claim. |
| Ndiaye, Fercoq, Gramfort and Salmon (2017), *JMLR* 18(128), 1–33, [journal record](https://jmlr.org/papers/v18/16-577.html), key `Ndiaye2017GapSafe` | A duality gap supplies a safe region for an optimizer, enabling certified removal of irrelevant variables in sparse learning. | Attribute gap-derived localization and safe screening. The present contact tests localize both a primal shape and a multiplier and validate branch reuse. They do not introduce the general idea of gap-based safe decisions. |

The Nielsen–Axehill bibliography deliberately cites the verified arXiv
version, rather than guessing its conference DOI. The arXiv submission is
dated 16 March 2016. The served PDF has a later typesetting date while its
identifier remains `1603.05034v1`; the bibliographic year follows the
submission record.

## Sparse factor updates and changing Dirichlet conditions

| Work and checked metadata | Established mechanism | Consequence for this method |
|---|---|---|
| Davis and Hager (1999), *SIAM Journal on Matrix Analysis and Applications* 20(3), 606–627, [primary publisher](https://doi.org/10.1137/S0895479897321076), key `Davis1999Modifying` | Sparse Cholesky modification after adding or removing an outer-product column; work follows factor entries that change. | Attribute sparse rank-one update/downdate machinery. Rank one does not imply a dimension-only linear-work bound. |
| Davis and Hager (2001), *SIAM Journal on Matrix Analysis and Applications* 22(4), 997–1013, [primary publisher](https://doi.org/10.1137/S0895479899357346), [author paper](https://people.engr.tamu.edu/davis/publications_files/MultipleRank_Modifications_of_a_Sparse_Cholesky_Factorization.pdf), key `Davis2001MultipleRank` | A multiple-rank sparse update handles several update columns together and improves memory traffic relative to repeated passes. | Batch modification is prior art. Its speed and fill on contact changes require measurement. |
| Davis and Hager (2005), *SIAM Journal on Matrix Analysis and Applications* 26(3), 621–639, [author paper](https://people.engr.tamu.edu/davis/publications_files/Row_modifications_of_a_sparse_Cholesky_factorization.pdf), DOI `10.1137/S089547980343641X`, key `Davis2005Row` | Specialized symmetric row/column addition and deletion, including changes from an isolated diagonal coordinate. The paper explains how a general rank-two route can create factor entries that subsequently cancel. | This is a direct precedent for toggling a coordinate in the Dirichlet embedding. The signed rank-two expression is an algebraic implementation option; native row modification can be more efficient. Neither is a new sparse factor-update algorithm here. |
| Chen, Davis, Hager and Rajamanickam (2008), *ACM Transactions on Mathematical Software* 35(3), Article 22, 14 pp., [author paper](https://people.clas.ufl.edu/hager/files/cholmod_alg.pdf), DOI `10.1145/1391989.1391995`, key `Chen2008CHOLMOD` | CHOLMOD provides sparse Cholesky factorization, factor modification and solves, with dynamic data structures supporting changed factor patterns. | Attribute the actual library's update and downdate machinery. Record the installed version, public API, factor mode and permutation handling; native factor/workspace memory belongs in accounting. |
| Herholz and Sorkine-Hornung (2020), *ACM Transactions on Graphics* 39(6), Article 202, 14 pp., [primary project](https://igl.ethz.ch/projects/sparse-cholesky-update/), [author paper](https://igl.ethz.ch/projects/sparse-cholesky-update/sparse-cholesky-update-paper.pdf), DOI `10.1145/3414685.3417828`, key `Herholz2020SparseUpdates` | Sparse factor reuse for interactive mesh parameterization with changing Dirichlet boundary conditions. Their method selectively recomputes affected factor columns, and its performance depends on the size and pattern of edits. | This is a direct graphics precedent for changing fixed-coordinate sets. The present analysis couples bound-QP working sets and affine-response caching to residual/error acceptance; it does not introduce sparse updates for geometric editing. |

The fixed-size embedding `K_A = P_I H P_I + P_A` changes by a signed
rank-two matrix when one free variable becomes fixed. Its two-dimensional
eigendecomposition supports a positive update followed by a negative
downdate; both endpoints and the intermediate matrices remain SPD in exact
arithmetic. This proof does not control fill, numerical downdate stability,
or wall-clock time. In particular, the positive component may temporarily
couple neighbors that were not adjacent in the endpoint matrix. Profile
both general update/downdate and specialized row operations when available,
and retain a paid refactor fallback.

Zarebavani, Kaufman, Levin and Mehri Dehnavi (2025), *Adaptive Algebraic
Reuse of Reordering in Cholesky Factorizations with Dynamic Sparsity
Patterns*, *ACM Transactions on Graphics* 44(4), Article 119, 17 pp.,
[publisher](https://doi.org/10.1145/3731179),
[author paper](https://dannykaufman.io/projects/PARTH/doc/parth.pdf), key
`Zarebavani2025Parth`, is a further close graphics precedent. Parth reuses
and locally adapts fill-reducing orderings for changing sparse graphs.
The present fixed-SPD-metric backend retains a factor ordering and modifies
its numerical rows when bounds enter or leave. It does not implement
Parth's adaptive ordering algorithm. Attribute both symbolic and numerical
reuse precedents; the response-error budget remains the specific issue
analyzed here.

## Additional context references used in the manuscript draft

- Hu et al. (2001), *Modifying the shape of NURBS surfaces with geometric
  constraints*, *Computer-Aided Design* 33(12), 903–912, DOI
  `10.1016/S0010-4485(00)00115-9`, is verified against the
  [coauthor's institutional publication record](https://profiles.wustl.edu/en/publications/modifying-the-shape-of-nurbs-surfaces-with-geometric-constraints/).
  It supplies context for constrained geometric editing, not a solver claim.
- Sassen et al. (2020), *Geometric optimization using nonlinear
  rotation-invariant coordinates*, *CAGD* 77, 101829, DOI
  `10.1016/j.cagd.2020.101829`, is verified against the
  [publisher](https://www.sciencedirect.com/science/article/pii/S0167839620300169)
  and [author paper](https://graphics.tudelft.nl/Publications-new/2020/SHHR20/GeometricOptimization.pdf).
- Shapiro (2005), *Sensitivity Analysis of Parameterized Variational
  Inequalities*, *Mathematics of Operations Research* 30(1), 109–126,
  DOI `10.1287/moor.1040.0115`, and Shapiro (2016), *Differentiability
  Properties of Metric Projections onto Convex Sets*, *JOTA* 169,
  953–964, DOI `10.1007/s10957-016-0871-8`, are checked against their
  [INFORMS](https://doi.org/10.1287/moor.1040.0115) and
  [Springer](https://doi.org/10.1007/s10957-016-0871-8) records.
  The manuscript gives its own orthant-specific critical-cone proof.
- Boyd and Vandenberghe (2004), *Convex Optimization*, Cambridge
  University Press, is checked against the
  [authors' book site](https://web.stanford.edu/~boyd/cvxbook/).
- The [official NIST download page](https://www.nist.gov/ctl/smart-connected-systems-division/smart-connected-manufacturing-systems-group/mbe-pmi-0)
  identifies the CTC definitions as geometry-only STEP models with
  accompanying PMI explanations. The retained archive README and
  `cad_sources.md` provide source hashes, reuse terms and the exact
  distinction between source geometry and the derived paired layers.

## Suggested manuscript language

“Multiparametric QP methods represent stable optimizer branches by affine
maps and test their primal–dual validity regions. Partial enumeration and
finite KKT-factor caches combine stored solutions with online optimization,
and low-rank relations between neighboring regions reduce explicit-MPC
memory. We use these ideas for repeated ordered-chart correction with a
supplied low-dimensional edit map. Our analysis combines a feasible
residual gap bound with conservative primal and dual margins, including
response-solve error, so that each accepted affine evaluation retains a
specified shape-error budget. A bounded online cache limits retained
response arrays, and a sparse reduced-space construction avoids retaining
contact inverse columns. A fixed-dimension Dirichlet embedding permits
established sparse factor modification routines to maintain the changing
equality branch.”

Use the references in the table at the corresponding clauses. The claim is
a specific error-controlled editing workflow and evaluation. Avoid “first
parametric method,” “first bounded cache,” “first low-rank QP method,” and
unqualified “novel affine-region algorithm.” Novelty relative to every
related error-controlled explicit-MPC scheme remains unproved by this
focused search.

## Actual external sparse solvers

These are implementation candidates, not measured outcomes. None was
installed by this audit. Match objective, bounds, stopping acceptance,
setup/update accounting and terminal KKT computation across methods.

| Actual package | Primary evidence and suitability | Comparison condition |
|---|---|---|
| OSQP | [Official docs](https://osqp.org/docs/) document sparse linear algebra, warm starts and factorization reuse. [Official BibTeX](https://osqp.org/docs/citing/index.html) verifies Stellato et al., *MPC* 12(4), 637–672 (2020), DOI `10.1007/s12532-020-00179-2`, key `Stellato2020OSQP`. | Use one setup with linear-cost updates; report polishing, adaptive-rho refactorizations and accepted residuals. This is an actual mature external implementation. |
| ProxSuite sparse ProxQP | [Official repository](https://github.com/Simple-Robotics/proxsuite) offers dense, sparse and matrix-free backends and Python bindings. [Official API](https://simple-robotics.github.io/proxsuite/md_doc_22-ProxQP__api.html) documents warm-start workspace preservation for linear-cost updates. [Author publication](https://scaron.info/publications/tro-2025.html) and [HAL author record](https://cv.hal.science/justin-carpentier) verify *IEEE Transactions on Robotics* (2025) and DOI `10.1109/TRO.2025.3577107`, key `Bambade2025ProxQP`; unverified volume/page fields are omitted. | A strong additional sparse comparator. Use the actual sparse backend and documented update/warm-start API. Separate initial setup and all subsequent updates; do not infer performance from its publication. |
| PIQP | [Primary paper record](https://arxiv.org/abs/2304.00290) verifies Roland Schwan, Yuning Jiang, Daniel Kuhn and Colin N. Jones (2023), describing a generic sparse proximal interior-point solver with C++ and Python interfaces, key `Schwan2023PIQP`. | Another useful external sparse comparator. Check the installed version's update and warm-start semantics rather than assuming active-set-style hot starts. |
| qpOASES Schur variant | [Official manual](https://www.coin-or.org/qpOASES/doc/3.2/manual.pdf), section 4.7, and [SQProblemSchur API](https://www.coin-or.org/qpOASES/doc/3.2/doxygen/classSQProblemSchur.html) distinguish sparse Schur linear algebra from merely passing sparse matrices to the ordinary classes. The manual's variant uses an external sparse solver, MA57. | Actual `SQProblemSchur` is relevant if its dependencies are available. Ordinary `QProblem`/`SQProblem` factorization remains dense even with sparse input; label that version accurately. |
| HiGHS QP active-set | [Official current solver docs](https://ergo-code.github.io/HiGHS/dev/solvers/) state that the active-set QP solver uses a dense reduced-Hessian Cholesky and a `qp_nullspace_limit`. | A possible actual active-set comparator, with this dense reduced-factor limitation stated. The development docs also describe a QP interior-point option; record the installed release and exact selected algorithm. |

Use direct solver calls when practical, since a common wrapper may omit
solver-specific warm-start/update features. Independent acceptance audits
make different package stopping conventions comparable; they do not make
all internal tolerances identical.

## Consequences for experimental claims

The supplied `Y` is a restriction of the editing model. Demonstrate rank-one
and genuine rank-three edit streams, and report the rank of the trajectory
as well as the matrix. A single curve contained in an affine line evaluates
scalar continuation even if the array has three columns. Include changing
parameter directions, out-of-order region revisits, weak transitions, cache
evictions and refinement regimes. No theorem here predicts a persistent
speed advantage over optimized Schur or these external sparse packages.

Additional primary-source check,17October2026: Wu etal., HIRM,CAGD35–36(2015)56–68, DOI10.1016/j.cagd.2015.03.001, publisher abstract and authorPDF https://wuyirui.github.io/papers/CAGD.pdf. Geometry-derived reduced deformation space; our application-supplied edit parameters instead drive full-dimensional convex clearance projection. Hintermüller,Ito,Kunisch,SIAMJOptim13(3)865–888,DOI10.1137/S1052623401383558: primary publisher labels volume-year2002 (copyright2003); use2002 consistently. The working-set complementarity indicator is attributed to this established primal-dual active-set family.
