# Bounded branch-response implementation plan

> Execute with subagent-driven-development: isolated CAD and theoretical audits,
> root implementation, then an independent source/results review.

Goal: repeatable speed and storage improvements against strong cached Schur.
Architecture: immutable old baselines plus a new bounded region-response engine;
fixed geometry model and supplied low-rank edit map; no future active-set input.
Stack: Python/NumPy/SciPy/OSQP; Python scientific plots; LaTeX journal package.

- [ ] Profile unchanged fine-grid Schur/checking and reduced-space operations.
      Save function costs, n/active/column bytes and all source hashes.
- [ ] Write failing tests: multidimensional branch invariance, feasible residual
      gap upper bound, positive/weak/contact transitions, LRU memory bound,
      changing model/basis invalidation and independent QP agreement.
- [ ] Implement sparse branch construction and cheap gap/margin decisions;
      validate against exhaustive small SPD problems and actual OSQP.
- [ ] Implement optimized Schur baseline, test equivalence with frozen original.
- [ ] Pilot prespecified regimes and preserve every outcome; fix correctness
      errors before freezing formal source and protocol.
- [ ] Acquire/import three public CAD models and validate tessellations/metadata.
      Agents own assets/CAD importer and theoretical-literature notes separately.
- [ ] Freeze and execute all methods with rotated repeats, common tolerances,
      rank-1/rank-3 edits, six representative geometries and refinement tests.
- [ ] Independent audits: forward response, budget containment, intersections,
      shape metrics, timings/memory and claimed external implementation scope.
- [ ] Derive new theory statements and rewrite abstract/introduction/results
      with checked references and all performance limits.
- [ ] Produce main geometry/context figures and comparison plots with Python;
      compile monolithic author/anonymous LaTeX, inspect every page.
- [ ] Package review/editorial/supplement files and two reproducibility archives;
      test extracted release and retain original versions unchanged.
