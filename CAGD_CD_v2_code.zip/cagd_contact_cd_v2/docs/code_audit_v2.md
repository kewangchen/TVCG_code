# Read-only implementation audit during formal_03

Scope: `cases.py` (the current name of the requested new case builder),
`src/response.py`, `benchmark.py`, their frozen formal_03 copies, and the native
factor integration required to assess storage. No production source or result
was changed. No solver, eigenvalue or timing benchmark was run during this
audit. Small JSON reads and source hashes supplied the numerical examples below.
All 16 source hashes recorded by formal_03 still matched at the audit check.
The formal run was incomplete, so this report does not certify its final outcomes.

## Material findings and required interpretation

**[P1] The aggregate response memory fields undercount current owned storage and
cannot serve as total-memory or peak-memory results.**
`UpdatedFaceQP.factor_bytes` is initialized once from native retained memory
(`response.py:95-96`) and is never refreshed when native capacity grows.
`_observe_memory` continues to use that initial value (`response.py:216-219`).
It also omits these separately allocated arrays:

- `UpdateFactor.H`, a second solver-owned CSC copy made in `chol_update.py:41`;
  it is distinct from the outer `BranchResponseSolver.H` copy.
- `UpdateFactor.diagonal`, `mask`, `active` and `permutation`.
- `UpdatedFaceQP.HbA` and `_mask`, in addition to the inherited arrays already
  included by the outer estimator.

The native C handle and its inverse permutation are already counted by current
`native_tracked_bytes`; they must not be added again. `kernel.H` and `kernel.b`
alias the outer H and b, so they must likewise not be counted twice. Native
factor capacity/workspaces and the Python H copy are different allocations.

The completed strip-fine rank-1 repeat-zero JSON gives a concrete contradiction:
`active_factor_bytes=5,652,312`, while nested current native tracked storage is
`8,004,536`. The reported aggregate peak is `8,949,244`, yet the nested current
UpdateFactor payload alone is `9,466,724`, before the outer H, basis and regions.
Reconstructing the final unique retained numerical payload from the two matched
response/warm-update records gives `12,327,984` bytes for response. This is a
current-retained calculation, not a peak measurement. The recorded response
payload itself, `981,824` bytes, is internally consistent.

There is also a peak-estimator overcount: before inserting a new region,
`size` already includes its V and L arrays, and line 178 adds `V.nbytes` and
`L.nbytes` again even though those are the same arrays. Other temporaries are
not fully observed. This mixture cannot be repaired by a single constant offset
or interpreted as either a rigorous upper or lower peak bound.

After formal_03, repair the reporting API and perform a memory-only replay.
Keep the timed numerical kernels and historical timings unchanged. A reliable
current-retained report should traverse the following numerical roots, deduping
the underlying owner/buffer allocations rather than summing object references:

- Outer H, b, Y, y0, HY, Hy0 and diagroot; each region's ndarray values.
- Kernel H, b, scale, A, F, coupling, HbA and `_mask`.
- UpdateFactor H, diagonal, mask, active and permutation.
- Current native tracked allocations, once per opaque native factor handle.

Traverse CSC data/indices/indptr separately, follow ndarray bases to their owned
storage, and dedupe aliases/views by their live buffer allocation. A whitelist
is preferable to blindly traversing ctypes/native internals. Report current
native tracked bytes, native lifetime peak, current unique Python numerical
payload and current combined payload as separate fields. A whole-process RSS
peak is already available and correctly labeled. Do not manufacture a combined
Python/native peak from end-of-run snapshots. The root has confirmed that the
main memory figure uses RSS, current native tracked bytes and retained response
bytes, so this defect need not invalidate that figure or the timed formal run.

**[P2] Stress/ablation coverage in the design is broader than formal_03.**
`cases.path(kind='abrupt')` exists, but the main `run()` always launches workers
without `--kind`; parsing `--kind` at the CLI only affects direct worker calls
(`benchmark.py:74-86`). Formal_03 therefore contains the smooth out-and-back
rank-1/rank-3 paths only. The root plans a separate abrupt-path stress run after
formal completion. Label it separately and preserve the current protocol scope.
The design also requests an explicit-region ablation without error margins;
there is no such method in the five formal methods. A full refactor or generic
rank-two-update ablation is likewise not part of this formal run. Add any claimed
ablation as a separately frozen supplemental experiment instead of inferring
it from these records.

**[P2] Separate the factor-update gain from the affine-region contribution.**
`warm_update` uses the same native row-modification kernel with regions and
region prediction disabled. Thus response versus condensed combines native
factor updates, region prediction and affine response reuse. It does not isolate
the benefit of bounded regions. Response versus warm_update is the relevant
end-to-end comparison, including the cost of preparing affine responses. In
the already completed strip-fine repeat zero, response costs `0.842527` s and
warm_update `0.820466` s; the loss must remain visible. Region-hit and QP counts
should accompany any claim about solve avoidance. Also, the high-level
`active_factorizations` counter increments on face changes in the update
backend (`response.py:107`); it does not count fresh sparse factorizations.
Use nested native `numeric_factorizations` and native row-add/delete counters
when discussing factorization work.

**[P2] Freeze dependency/input identities as well as Python sources.**
The benchmark snapshots Python sources, but workers import the live package,
and `run()` does not recheck hashes at completion. Add a final source hash audit
without changing the measured kernels. The protocol's Python hashes alone do
not identify the actually loaded external native adapter/library or the CAD
NPZ inputs. The separate CAD provenance and `docs/chol_update.md` provide these
dependency details; the final release manifest should connect them to the run,
including adapter SHA256, CHOLMOD library/version and selected mesh hashes.
No source mismatch was found in the audit's current check.

## Correctness and scope checks

The fixed-size native embedding is correct. `HbA` starts at zero and changes by
`H[:,changes] * b_changes * (new_mask-old_mask)` (`response.py:101-105`). Hence,
in exact arithmetic, it equals `H[:,A] b_A`. The free RHS in `branch` is then
`q_F-H_FA b_A`, the active RHS is b_A, and forcing the returned active values
to b leaves the desired face solution. Derivative RHS values on A are zero.
Cached region hits need not update the working factor: the next miss computes
changes from the kernel's actual mask. No sign or stale-mask error was found.

Long-history floating-point drift in the incremental HbA vector and repeated
factor modifications is not periodically reset. The paid KKT checks expose
such drift before accepting a result; a sufficiently long adverse history can
still cause iteration failure instead of automatic recovery. A future robustness
extension should test long toggle histories and rebuild/rebase on an explicit
residual trigger. No such failure was observed in the records inspected here,
and adding this numerical recovery is separate from the memory-only repair.

The supplied mass lower bound is valid in exact arithmetic. The stiffness
construction is `C=B^T B`; the biharmonic term is `C diag(1/mass_area) C`.
With positive triangle masses and positive normalization coefficients, both
terms are PSD. Therefore full H dominates `diag(mass)`, and restriction to free
coordinates preserves `H >= min(mass_free) I` (`cases.py:27-29`, and the copied
procedural builder). A new eigensolver is not needed to justify this analytic
lower bound. Degenerate/nonpositive masses would violate its premise and must
remain excluded by the separate mesh/import audit.

The affine residual radius and margin tests are consistent in exact arithmetic.
Stored candidates have u_A=b_A and lambda_F=0, so a feasible candidate is
complementary. Its gap is `e^T H^-1 e/2`; the residual-based bound supplies
`||e||/sqrt(mu)` as an H-error radius. The center residual plus weighted response
residual norms gives the stored affine radius. The free-slack and active-dual
tests use the corresponding coordinate bounds. The `64*eps` cushions in lines
169-174 are numerical cushions, not outward-rounded enclosures. The source
explicitly states this limitation and pays terminal KKT checks. Manuscript
claims must preserve that distinction. Formal_03 does not set
`h_error_budget`; that option screens cache hits and does not currently provide
a separate certified budget on a fallback QP return, whose `h_error_bound` is
None. Do not describe this run as testing arbitrary user-supplied error budgets.

The rank-three cases use three spatial basis fields and all methods receive the
same Y and three-component path. The parameter path is one prescribed smooth
curve in three-dimensional coefficient space; it is not a Cartesian parameter
grid or arbitrary three-parameter exploration. The common frozen H, bounds and
clearance model are unchanged along each path. CAD cases remain normalized,
selected-face paired normal layers. Their hard-coded sampled curvature radii
and coordinatewise clearance bounds are not proofs of global 3D separation;
endpoint mesh audits are a separately required geometric check.

The main protocol has 15 configurations: six base rank-1, six fine rank-1 and
three fine rank-3. With three repeats, four methods cover all configurations
(45 workers each), and actual ProxQP covers only the six base meshes (18 workers).
The expected total is 198 workers and 8,118 query requests. The completed-file
label `query_solves` counts requests, including cached returns; it is not the
number of QP iterations or fresh QP solves. Methods rotate by repeat but three
repeats do not form a fully balanced five-position Latin schedule.

ProxQP is a real external sparse solver here, with its native sparse Cholesky
backend and previous-result warm start. OSQP is also actual external library
code. Both are independently assessed by the same terminal `2e-9` KKT
criterion. The explicit protocol text correctly limits ProxQP to the six base
meshes. The preserved formal_01 strip-fine ProxQP pilot costs `73.795697` s and
qualifies at maximum KKT `1.11e-11`. It supports the stated pilot observation,
not a ProxQP comparison on every fine mesh. Keep the missing fine-grid ProxQP
coverage visible in tables and conclusions.

Total timing includes setup, online work, terminal checks and state-history
copies; it stops before compression and final memory inspection. Per-step
timings stop before state-history copies, so their sum need not equal total
minus setup. Geometry construction and both external-library imports occur
before the timer for every method. Native adapter loading is paid in setup.
RSS is a worker-lifetime peak including imports, common geometry/model assembly
and output histories; it is correctly not called a solver-only memory delta.
These timing/RSS scopes are suitable if retained verbatim. The low-rank gradient
assembly could also be offered to external solvers (`HY @ theta` instead of
`H @ (Y @ theta)`); no timing claim about that optional optimization was measured
during this audit.
