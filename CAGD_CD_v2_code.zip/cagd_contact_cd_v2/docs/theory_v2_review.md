# Independent mathematical audit

The new region result extends the earlier scalar continuation result to a
supplied parameter vector. The formula does not require rank one. Its
correctness is conditional on fixed `H, b, y0, Y`, a justified positive lower
bound `m`, a feasible center pair, complete strict partition tests, and the
response support identities `V[A] = 0`, `L[I] = 0`.
The pointwise corollary also supports records built at weak/unresolved
centers: it checks each evaluated complementary pair directly, and needs
no strict partition at the center.

## Results established in `theory_v2.tex`

1. A feasible pair has exact gap
   `G = 0.5 e.T H^-1 e + lambda.T (u-b)`, with
   `e = H(u-y)-lambda`. The computable upper bound replaces the first term
   by `||e||²/(2m)`. No inverse action is needed. Both primal and dual
   errors are bounded in their natural metrics by the feasible gap.
2. A sparse principal factor `H[I,I]` constructs the center and all supplied
   response directions using `r+1` right-hand sides. It need not construct
   or retain columns of `H^-1`. Sparse factors and their fill still count.
3. The conservative region subtracts the center and response error radius
   from every inactive slack and active multiplier margin. The proof first
   builds an algebraic equality branch, then establishes its KKT feasibility;
   it does not assume the desired branch invariance.
4. Approximate response residual `R = H(V-Y)-L` contributes
   `||R delta||/sqrt(m)` to the radius, or its valid columnwise bound
   `sum_j abs(delta[j]) ||R[:,j]||/sqrt(m)`. Its role follows from the exact
   identity `||p||_H² + ||z||_Hinv² = ||R delta||_Hinv²`, because primal
   response error is supported on `I` and multiplier response error on `A`.
5. Exact responses preserve the center error pair. Approximate responses
   preserve a requested error budget only when the enlarged radius is
   checked against that budget. Complementary branch centers also yield a
   propagated gap bound `rho(delta)²/2`; generic feasible centers require
   a fresh complementarity term if a gap bound is wanted.
6. An eviction decision changes hit rate. Per-query acceptance remains
   justified by the remaining records and the checked fallback. The result
   assumes successful fallback verification; it is not a proof that the
   local PDAS implementation terminates from every working set.

## Fixed-dimension sparse factor backend

The added Dirichlet-embedding proposition establishes
`K_A = P_I H P_I + P_A >= min(m,1) I`. The center right-hand side is
`P_I(q - H P_A b) + P_A b`, with `q=H y`; the response right-hand side
is `P_I H Y`. Solving either system reproduces the corresponding reduced
principal equations exactly. The fixed matrix dimension permits a sparse
factor to survive working-set changes.

Activating free coordinate `i` changes only its symmetric row/column:
`Delta = -e_i w.T - w e_i.T + (1-H_ii) e_i e_i.T`, where `w` contains
`H[j,i]` for coordinates free in both sets and is zero at `i` and the
other active coordinates. Release reverses this exact modification. In
the orthonormal basis `[e_i,w/||w||]`, its `2 × 2` matrix is
`[[1-H_ii,-||w||],[-||w||,0]]`. Its two eigenvalues have opposite signs
when `w != 0`; `w=0` is a signed diagonal rank-one case.

Applying the positive eigencomponent first and then its negative component
keeps both endpoint matrices and the complete subtraction path positive
definite in exact arithmetic. This proof supports a generic backend; it
does not establish floating-point success of a native downdate routine.

Additional implementation obligations are:

- Form each toggle from the current free mask, and update the right-hand
  side as well as the factor. A batch must account for coordinates already
  toggled when forming its constituent modifications.
- Apply the factor's coordinate permutation consistently to update vectors,
  right-hand sides and returned states. Verify the public backend API's
  permutation convention with a nonidentity-ordering test.
- Use a symmetric eigensolver or scaled eigenvalue formulas. Direct
  evaluation of `a + sqrt(a*a+4*t*t)` can lose the small positive root when
  `a < 0`; division by `||w||` needs a separate zero case.
- Treat rejected downdates, factor conversion, reordering and rebuilding as
  paid work. Rebuild from the exact current `K_A` and recheck residuals
  after numerical failure or accumulated error.
- Measure native allocated factor capacity and update workspace. Extracted
  numerical `L` nonzeros do not necessarily equal native retained capacity,
  and Python-owned array counts do not cover native memory.

Davis–Hager (2005) is particularly relevant: its specialized row
addition/deletion algorithm avoids some fill introduced then canceled by
a general rank-two decomposition. The signed eigencomponents can each
temporarily connect neighbors of `i`; positive-first ordering proves SPD,
not sparse fill containment. CHOLMOD row modification routines and its
general update/downdate routines are established alternative backends.
Herholz–Sorkine-Hornung (2020) supplies a direct geometry-editing precedent
for factor reuse when Dirichlet boundary conditions change.

The response proofs use only the resulting center, response supports and
measured residuals. They apply to fresh sparse factors, signed low-rank
updates and specialized row modification backends alike. No universal
linear-in-`n` update bound or performance advantage is asserted.

## Implementation obligations

| Obligation | Reason and audit |
|---|---|
| Use an analytic/enclosed `m > 0` | `m` must be a lower bound, not a nominal smallest eigenvalue. An excessively small valid bound is safe but conservative. |
| Check center feasibility before the gap | Negative multipliers or negative slack invalidate the gap error argument. After clipping, recompute the residual of the clipped pair. |
| Require full strict partition coverage at the query where a strict branch is asserted | The main theorem uses center coverage and its conservative region. The pointwise corollary checks the evaluated complementary pair directly, so its center can be weak. A small KKT residual alone does not identify weak contacts. |
| Assign `V[A]=0`, `L[I]=0` explicitly | The response error identity requires these supports. If assignments change the response, compute `R` afterwards. |
| Account for approximate response residual | Treating numerical `R` as exactly zero can violate the stated budget and contact classification. |
| Keep complementary branch centers when using the cheap propagated gap | Set `uhat[A]=b[A]`, `lamhat[I]=0`, verify the remaining signs, and compute `e_c` after the assignments. |
| Preserve an immutable model generation | Include `H,b,y0,Y`, free-coordinate identities and reconstruction map in invalidation. A changed parameter basis cannot reuse old responses. |
| Run the common terminal audit and charge its cost | A stored affine evaluation and margin scan do not replace terminal KKT validation in the stated numerical protocol. |
| Check the returned radius against any requested error budget | A terminal KKT tolerance is a separate criterion; a numerical radius is an enclosure estimate, not a user-error threshold unless it is compared with one. |
| Count all retained and peak arrays | Include response records, model arrays, sparse-factor arrays, transient dense right-hand sides, old/new records during insertion, and fallback state. Distinguish Python-owned payload from RSS. |
| Use deterministic tie handling at weak contacts | Boundary acceptance can validate a value. It does not prove a unique two-sided Jacobian across the boundary. |

The existing solver's `gap_certificate` performs a global inverse solve;
the new residual upper bound removes that solve from the decision. Its
reduced branch routine factors the sparse principal matrix and already
enforces the branch supports, but its cycle recovery uses L-BFGS-B. The
new documentation therefore asserts checked acceptance, not unconditional
finite convergence of that local implementation.

## Counterexamples that justify the conditions

With `H=1, b=0, y=0, u=1, lambda=1`, stationarity is exact but the gap is
one. Dropping the complementarity term would incorrectly report zero.

With `H=1, b=0, y(theta)=-1+theta`, center `(u,lambda)=(0,1)`, and supplied
`Y=1`, choose the inaccurate response `V=0, L=0`. Ignoring its residual
would accept `theta=2` with zero predicted error, although the true optimum
is `u*=1`. Here `R=-1`; the residual radius is two and correctly rejects
the active multiplier margin at that endpoint.

## Required empirical scope

Keep independent rank-three edits in every main benchmark class: at least
three linearly independent columns of `Y`, a parameter trajectory that
leaves any single affine line, and repeated contact opening/closing. Report
the numerical rank and the trajectory's affine rank. Calling a scalar path
with three redundant columns a multidimensional test would not evaluate
the stated region algorithm. Add out-of-order revisits to evaluate the LRU
reuse mechanism separately from a monotone continuation path.

Measure original Schur, a streamlined causal Schur baseline, warm reduced
space, actual OSQP and at least one further actual sparse solver when
feasible. Direct ProxSuite sparse ProxQP is a suitable candidate. Charge
setup, all lazy response construction, misses, rejected tests, terminal
audits and fallback recovery. Retain losses. Theorems do not establish a
speedup, a fixed miss rate, reduced sparse-factor fill, or superiority at
every resolution.

The precise defensible contribution is an application-specific combination
of residual error enclosures, conservative multidimensional response reuse,
bounded retained response storage, and ordered-chart/CAD-derived evaluation.
Affine branches, critical regions, bounded caches, and low-rank mpQP memory
compression all have direct precedents documented in `literature_v2.md`.

## Numerical scope

All mathematical inequalities are exact-arithmetic statements. A floating
implementation with ordinary norms and margins supplies tolerance-level
audits. It supplies a formal numerical certificate only if residual and
roundoff enclosures are included. This distinction belongs next to the
first certificate claim and in the limitations.

## Verification performed for this audit

A standalone temporary wrapper containing the complete theory fragment,
the theorem environments and inline reference placeholders compiled
successfully with the desktop LaTeX compiler after the sparse-update
extension. After adding the manuscript context sources, static checks
found 24 bibliography entries and 11 keys cited by the theory fragment,
30 labels, no missing keys, no duplicate labels
and no unresolved equation/theorem labels. The wrapper checks the fragment;
the final manuscript and its complete bibliography still require their own
compilation.

A deterministic algebra sanity check (NumPy RNG seed `104729`) generated
40 dense `6 × 6` SPD problems with three independent parameter directions,
20 complementary and 20 general feasible centers, and perturbed responses
with the required supports. It tested 25 random parameter displacements
per center against the conservative region. All 839 accepted points
(415 complementary and 424 general-center cases) agreed with an exhaustive
64-working-set optimizer and respected the proved product-norm bound.
All complementary cases also respected the propagated gap bound. The
largest stationarity residual of the exhaustive comparison states was
`1.38e-14`. This check supports the algebra and sign conventions; it does
not validate the evolving production solver or establish performance.

A second deterministic algebra check (seed `15485863`) tested 1,800
activation/release toggles across 45 SPD matrices of order eight, including
368 zero-coupling cases. The signed-update identity had maximum relative
error `1.18e-15`; embedded and reduced center/three-column response solves
differed by at most `1.28e-14`. All sampled positive-first update/downdate
intermediates remained SPD, with minimum observed eigenvalue
`0.19999999999999726` for matrices constructed with lower bound `m=0.2`.
This is a dense algebra check of the formulas and degenerate cases, not a
test of a CHOLMOD binding, native sparse fill or update performance.

## Manuscript integration audit

The body-only draft is `manuscript/draft_body.tex`; its sole external
content input is `results_section.tex`, supplied by the experiment author.
It contains Introduction, grouped related work, the ordered-chart model,
residual/region analysis, native sparse branch construction, a formal
query algorithm, weak-contact directions, evaluation design, Discussion
and Conclusion. It is approximately 3,450 whitespace-delimited words before
the numerical results. The supplement is approximately 5,550 words after
expanding its input of the complete theory fragment.

The one-sentence argument is: for a fixed ordered-chart correction model
with a supplied low-dimensional edit map, primal–dual residual bounds
justify affine response reuse, while classical native row modifications
provide a distinct sparse miss kernel. The proofs support accuracy and
retained-response storage claims. Comparative speed, total memory and
geometric endpoint outcomes require the separately supplied numerical
results.

| Canonical term | Meaning used throughout |
|---|---|
| Ordered chart / paired layer | Known corresponding sampled layers with prescribed order and directions |
| Supplied edit map | `y(theta)=y0+Y theta`; `r` is its parameter count |
| Response record | Center, complementary primal/dual pair, `V,L`, partition and residual gains |
| Conservative margin region | Affine primal/dual margins reduced by the residual error radius |
| Native row modification | Classical CHOLMOD symmetric row/column addition or deletion for `K_A` |
| Terminal KKT audit | Independent stationarity, feasibility and complementarity residual check |
| Hit error filter | Optional hit-only `h_error_budget`; unset in the formal protocol |
| CAD-derived paired-layer edit | Derived layers of kernel-tessellated authored STEP faces |

The introductory argument uses the application-first pattern: clearance
editing, repeated-query cost, error-controlled affine reuse, and classical
sparse miss solving. The methods separate the mathematical acceptance
conditions from implementation and measured performance. Related work
attributes explicit regions, bounded caches, low-rank mpQP storage, native
row modifications, changing Dirichlet conditions, and adaptive ordering
reuse directly. There are no first-cache, first-update, general-untangling
or uniform-runtime claims.

Temporary standalone wrappers for both bodies compiled successfully using
the desktop compiler with the results input omitted and citation
placeholders supplied only for syntax checking. The main body has 24
resolved cited keys and 29 unique labels; the expanded supplement has 14
resolved cited keys and 49 unique labels. Neither has unresolved internal
references. Final numerical text, actual bibliography rendering, complete
figure layout and submission pagination remain with the experiment author.
