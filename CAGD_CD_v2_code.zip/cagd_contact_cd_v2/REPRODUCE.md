# Reproduction package

This revision implements residual-controlled affine response reuse and native sparse row modifications for a fixed-metric paired-chart clearance QP. It preserves the previous paper and its experiments in separate folders.

## Runtime

Tested: Python3.9.7, NumPy1.26.2, SciPy1.13.1, Matplotlib3.8.1, OSQP1.0.5, ProxSuite0.7.3, CHOLMOD3.0.14/SuiteSparse5.10.1 on macOS x86_64. Install the Python requirements into a virtual environment. Native row modifications require the small supplied C adapter and a compatible installed CHOLMOD library. The exact tested build command, upstream headers, hashes, licenses and a Linux adaptation are in `docs/chol_update.md`. No Julia process is used by a solve. No external binary is redistributed.

Set `CAGD_CHOLMOD_ROWMOD_LIB` to your built adapter, and make the external OSQP/ProxSuite packages importable in that environment. Optional rank-two tests additionally require scikit-sparse. Gmsh is needed only to rebuild CAD tessellations from STEP, not for the frozen numerical experiments.

Run commands from the parent directory that contains `cagd_contact_cd_v2`:

```sh
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python -m pytest cagd_contact_cd_v2/tests -q
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 VECLIB_MAXIMUM_THREADS=1 python -m cagd_contact_cd_v2.benchmark --phase rerun
python -m cagd_contact_cd_v2.statistics
python -m cagd_contact_cd_v2.geometry_audit --phase formal_03
python -m cagd_contact_cd_v2.directions
MPLCONFIGDIR=/tmp/cagd-matplotlib python -m cagd_contact_cd_v2.plot
```

Historical result folders are immutable. Choose a new benchmark phase name for a rerun; statistics defaults to the frozen `formal_03` phase. The formal suite contains six base and six fine rank-one geometries, and three fine rank-three tests (strip, torus, CTC-02). Every sequence has41queries andthree independent-process repetitions. OSQP covers all15configurations; ProxQP is executed on allsix base geometries. Compressed cached Schur and warm native updates are local mechanism baselines, not claimed reproductions of QPSchur or the TOG2020 implementation. Read the finalized results notes for any precision-refinement records.

## CAD and figures

`assets/raw` retains the official public NIST source archive and original STEP files; the NIST source terms are retained. `assets/<model>` contains kernel tessellations, exact selected-face IDs and hashes. `cad_import.py` rebuilds them with pinned Gmsh4.15.2/OpenCASCADE7.8.1. In `cases.py`, CAD coordinates are explicitly centered and scaled from millimetres; derived layer offsets and edits are separate from the imported BRep. The three inputs are genuine CAD-derived charts; the paired assembly configurations are synthetic.

`geometry_audit.py` computes independent intersection and local-distortion diagnostics from saved endpoints. Figure scripts draw exact saved triangles and interpolate lighting normals only. `figures/provenance.json` records inputs and exported PDF/SVG/PNG hashes. The paper distinguishes minimum correction to the supplied edit from intrinsic distortion relative to the nominal layers.

## Timing and memory

Timings include solver setup, native updates, all QP iterations/recoveries, lazy response construction, membership decisions and independent terminal KKT checks. Geometry assembly, file compression, memory inspection and endpoint intersection audits are outside solver timing. Error bars are the min/max ofthree repetitions around their median, not confidence intervals.

Whole-process peak RSS includes imports and model construction and is measured in isolated workers. Native tracked capacity, retained response arrays, current total numerical payload and process RSS have different scopes. Historical aggregate allocation estimates identified in `docs/code_audit_v2.md` are not used as total-memory results. The current memory-only replay provides corrected unique-buffer accounting.

## Record history

`pilot_response.json` preserves the unsuccessful full-refactor prototype; `pilot_rowmod.json` and the kernel replay records are exploratory. Partial `formal_01`/`formal_02` runs preserve early external-solver configurations and are excluded from final aggregate claims. `formal_03` freezes the timed numerical source and specified protocol. Final source/asset/dependency/result hashes accompany the release.

## Rebuild the separate studies and analyze a fresh phase

Use new names for immutable experiment phases. After running the main `rerun` phase:

```sh
python -m cagd_contact_cd_v2.extras --task prox --phase rerun_prox
python -m cagd_contact_cd_v2.extras --task abrupt --phase rerun_abrupt
python -m cagd_contact_cd_v2.extras --task memory --phase rerun_memory --reference-phase rerun
python -m cagd_contact_cd_v2.statistics --phase rerun --precision-phase rerun_prox
python -m cagd_contact_cd_v2.geometry_audit --phase rerun
```

The extra drivers include every case/repetition, terminal audit and source hash. The memory replay compares its states with the selected timed phase and reports current unique retained buffers, separately from RSS. The publication figures use the standardized aggregate JSON files; their numerical input paths and hashes are recorded in the figure provenance. All original phase records remain unchanged.

The original full test environment has44passing tests, including the optional scikit-sparse rank-two backend. A fresh environment without scikit-sparse skips only that optional ablation; native row-modification tests still require the compiled primary adapter. To build the adapter portably from matching installed headers/libraries, use:

```sh
python -m cagd_contact_cd_v2.build_native --include-dir /path/to/suitesparse/include --library-dir /path/to/suitesparse/lib --output /path/to/libcagd_rowmod.so
export CAGD_CHOLMOD_ROWMOD_LIB=/path/to/libcagd_rowmod.so
```

On macOS use a `.dylib` output and a working C compiler/SDK. The tested native version is SuiteSparse5.10.1/CHOLMOD3.0.14; the Linux build recipe is supplied but was not executed on this machine.

## Archive layout

The numerical code ZIP contains all computational source, tests, CAD inputs, publication figure inputs and summary/individual timing JSON records. Large frozen per-query arrays and sparse model snapshots are in the ordinary `records_01`, `records_02`, ... ZIPs. Extract these into the same parent as the code archive to audit the archived endpoints or recompute the original full statistics. They are independent ZIP files, not binary fragments. Each is below80MiB. A new full benchmark run generates those arrays directly from the code ZIP's included inputs, so they are optional for running new experiments.
