"""Bounded affine branch responses for a fixed-metric clearance QP.

The feasible-gap and region statements are exact-arithmetic results. This
implementation evaluates them with ordinary floating-point direct solves and
pays for terminal KKT checks. No interval-rounding guarantee is asserted.
"""
from collections import OrderedDict
from time import perf_counter
import numpy as np
from scipy import sparse
from scipy.sparse.linalg import splu
from scipy.optimize import minimize


def residual_gap_bound(H,b,y,u,lam,m):
    if not np.isfinite(m) or m<=0:raise ValueError('A finite positive model eigenvalue lower bound is required.')
    u=np.asarray(u);lam=np.asarray(lam);b=np.asarray(b)
    if np.any(u<b) or np.any(lam<0):raise ValueError('The bound applies to the supplied feasible pair.')
    e=H@(u-y)-lam
    G=.5*float(e@e)/m+float(lam@(u-b))
    return dict(gap_upper=G,h_error_bound=float(np.sqrt(max(2*G,0))),residual=e)


def residual_kkt(H,b,q,u,lam):
    e=H@u-q-lam
    value=max(float(np.max(abs(e),initial=0)),float(np.max(b-u,initial=0)),
        float(np.max(-lam,initial=0)),float(np.max(abs(np.minimum(u-b,lam)),initial=0)))
    return value,e


def sparse_bytes(a):return a.data.nbytes+a.indices.nbytes+a.indptr.nbytes


class SparseFaceQP:
    """Warm reduced-space PDAS with one retained sparse face factor."""
    def __init__(self,H,b,tol=2e-9,ordering='COLAMD'):
        self.H=H;self.b=b;self.n=len(b);self.tol=tol;self.ordering=ordering
        self.scale=np.maximum(H.diagonal(),1e-12);self.A=np.empty(0,int);self.key=None
        self.F=np.arange(self.n);self.factor=None;self.coupling=np.zeros(self.n)
        self.factor_bytes=0
        self.stats=dict(qp_solves=0,active_factorizations=0,active_reuses=0,fallbacks=0,
            face_seconds=0.,factor_seconds=0.,backsolve_seconds=0.,working_iterations=0)

    def face(self,A):
        A=np.asarray(A,int);key=tuple(A)
        if key==self.key:self.stats['active_reuses']+=1;return
        started=perf_counter();mask=np.ones(self.n,bool);mask[A]=False;F=np.flatnonzero(mask)
        self.F=F;self.A=A.copy();self.key=key
        self.coupling=self.H[F][:,A]@self.b[A] if len(A) else np.zeros(len(F))
        if len(F):
            h=self.H[F][:,F].tocsc();t=perf_counter()
            self.factor=splu(h,permc_spec=self.ordering)
            self.stats['factor_seconds']+=perf_counter()-t
            self.factor_bytes=int(sparse_bytes(self.factor.L)+sparse_bytes(self.factor.U)+self.factor.perm_r.nbytes+self.factor.perm_c.nbytes)
        else:self.factor=None;self.factor_bytes=0
        self.stats['active_factorizations']+=1;self.stats['face_seconds']+=perf_counter()-started

    def branch(self,q,A):
        self.face(A);u=self.b.copy();t=perf_counter()
        if len(self.F):u[self.F]=self.factor.solve(q[self.F]-self.coupling)
        self.stats['backsolve_seconds']+=perf_counter()-t
        lam=np.zeros(self.n);lam[self.A]=(self.H@u-q)[self.A]
        return u,lam

    def solve(self,y,q,A0=None):
        A=self.A.copy() if A0 is None else np.asarray(A0,int);seen=set()
        for iteration in range(100):
            u,lam=self.branch(q,A);res,e=residual_kkt(self.H,self.b,q,u,lam)
            if res<=self.tol:break
            new=np.flatnonzero(lam-self.scale*(u-self.b)>0)
            if tuple(new) in seen:
                self.stats['fallbacks']+=1
                def fun(x):
                    d=x-y;return .5*float(d@(self.H@d)),self.H@d
                out=minimize(fun,np.maximum(u,self.b),jac=True,bounds=[(float(x),None) for x in self.b],
                    method='L-BFGS-B',options=dict(ftol=1e-15,gtol=1e-11,maxiter=10000,maxls=60))
                grad=self.H@(out.x-y);new=np.flatnonzero((out.x-self.b<1e-7)&(grad>0));seen.clear()
            seen.add(tuple(A));A=new
        else:raise RuntimeError('Reduced QP did not meet its KKT criterion.')
        self.A=A.copy();self.stats['qp_solves']+=1;self.stats['working_iterations']+=iteration+1
        return dict(u=u,lam=lam,active=A.copy(),kkt=res,iterations=iteration+1,residual=e)


    def response(self,HY):
        V=np.zeros_like(HY)
        if len(self.F):V[self.F]=self.factor.solve(np.asfortranarray(HY[self.F]))
        return V


class UpdatedFaceQP(SparseFaceQP):
    """Fixed-dimension Dirichlet factor modified by native CHOLMOD updates."""
    def __init__(self,H,b,tol=2e-9,ordering='COLAMD'):
        from .chol_update import UpdateFactor
        super().__init__(H,b,tol,ordering)
        self.updated=UpdateFactor(H,backend='rowmod');self.HbA=np.zeros(self.n);self._mask=np.zeros(self.n,bool)
        self.factor_bytes=self.updated.memory_payload()['native_tracked_bytes']

    def face(self,A):
        A=np.asarray(A,int);key=tuple(A)
        if key==self.key:self.stats['active_reuses']+=1;return
        started=perf_counter();target=np.zeros(self.n,bool);target[A]=True
        changes=np.flatnonzero(target!=self._mask)
        if len(changes):
            values=self.b[changes]*(target[changes].astype(float)-self._mask[changes])
            self.HbA+=self.H[:,changes]@values
        self.updated.update(A);self._mask=target;self.A=A.copy();self.F=np.flatnonzero(~target);self.key=key
        self.stats['active_factorizations']+=1
        self.stats['face_seconds']+=perf_counter()-started

    def branch(self,q,A):
        self.face(A);rhs=q-self.HbA;rhs[self.A]=self.b[self.A];t=perf_counter()
        u=self.updated.solve(rhs);u[self.A]=self.b[self.A]
        self.stats['backsolve_seconds']+=perf_counter()-t
        lam=np.zeros(self.n);lam[self.A]=(self.H@u-q)[self.A]
        return u,lam

    def response(self,HY):
        rhs=HY.copy();rhs[self.A]=0
        V=self.updated.solve(rhs);V[self.A]=0
        return V


class BranchResponseSolver:
    """Bounded causal regions for y(theta)=y0+Y theta; no inverse columns.

    Sparse reduced factors are used only on a region miss. A region owns two
    n-by-r response arrays and two n-vectors. Its stored residual gains account
    for inexact response solves in the candidate accuracy radius.
    """
    def __init__(self,H,b,Y,m,y0=None,max_regions=4,use_regions=True,predict=True,
                 max_response_bytes=16*2**20,tol=2e-9,ordering='COLAMD',backend='updated',h_error_budget=None):
        self.H=sparse.csc_matrix(H,copy=True);self.b=np.asarray(b,float).copy();self.Y=np.asarray(Y,float).copy()
        self.n=len(self.b)
        if self.Y.ndim==1:self.Y=self.Y[:,None]
        if self.Y.shape[0]!=self.n or self.Y.shape[1]<1:raise ValueError('Reference basis dimensions do not match the model.')
        if not np.isfinite(m) or m<=0:raise ValueError('A finite positive model lower bound is required.')
        if max_regions<1:raise ValueError('The region count limit must be positive.')
        self.m=float(m);self.rank=self.Y.shape[1];self.y0=np.zeros(self.n) if y0 is None else np.asarray(y0,float).copy()
        if self.y0.shape!=(self.n,):raise ValueError('Invalid reference offset.')
        self.HY=np.asarray(self.H@self.Y);self.Hy0=self.H@self.y0
        self.a=1/np.sqrt(self.m);self.diagroot=np.sqrt(self.H.diagonal())
        self.hnorm=float(np.max(np.asarray(abs(self.H).sum(axis=1))))
        if backend not in ['updated','refactor']:raise ValueError('Unknown factor backend.')
        self.backend=backend;self.h_error_budget=h_error_budget
        self.kernel=(UpdatedFaceQP if backend=='updated' else SparseFaceQP)(self.H,self.b,tol,ordering)
        self.max_regions=int(max_regions);self.max_response_bytes=int(max_response_bytes)
        self.regions=OrderedDict();self.next_key=0;self.use_regions=use_regions;self.predict=predict
        self.last_region=None
        self.stats=dict(qp_solves=0,region_hits=0,region_misses=0,region_builds=0,evictions=0,
            rejected_candidates=0,region_build_seconds=0.,membership_seconds=0.,terminal_seconds=0.,
            peak_response_bytes=0,peak_owned_array_bytes=0)

    def _radius(self,region,delta):return float(region['radius0']+abs(delta)@region['gains'])

    def _evaluate(self,region,theta):
        delta=theta-region['theta'];u=region['u']+region['V']@delta;lam=region['lam']+region['L']@delta
        radius=self._radius(region,delta);A=region['active'];F=region['free']
        valid=bool(np.all(u[F]-self.b[F]>radius*self.a) and np.all(lam[A]>radius*self.diagroot[A]))
        if self.h_error_budget is not None:valid=valid and radius<=self.h_error_budget
        return valid,u,lam,radius

    def _build(self,theta,y,q,state):
        started=perf_counter();A=state['active'];self.kernel.face(A);F=self.kernel.F
        u=np.maximum(state['u'],self.b);u[A]=self.b[A];lam=np.maximum(state['lam'],0)
        lam[F]=0
        V=self.kernel.response(self.HY)
        L=self.H@V-self.HY;L[F]=0;R=self.H@V-self.HY-L
        _,e=residual_kkt(self.H,self.b,q,u,lam)
        # A numerical cushion, not an interval-enclosing rounding proof.
        eps=64*np.finfo(float).eps
        radius0=max(float(np.linalg.norm(e))*self.a,
            eps*(self.hnorm*np.linalg.norm(u)+np.linalg.norm(q)+np.linalg.norm(lam))*self.a)
        gains=np.maximum(np.linalg.norm(R,axis=0)*self.a,
            eps*(self.hnorm*np.linalg.norm(V,axis=0)+np.linalg.norm(self.HY,axis=0)+np.linalg.norm(L,axis=0))*self.a)
        region=dict(theta=theta.copy(),u=u.copy(),lam=lam.copy(),active=A.copy(),free=F.copy(),V=V,L=L,
            radius0=radius0,gains=gains)
        size=sum(x.nbytes for x in region.values() if isinstance(x,np.ndarray));region['bytes']=int(size)
        self._observe_memory(extra=size+R.nbytes+V.nbytes+L.nbytes+u.nbytes+lam.nbytes)
        if size<=self.max_response_bytes:
            while self.regions and (len(self.regions)>=self.max_regions or sum(r['bytes'] for r in self.regions.values())+size>self.max_response_bytes):
                self.regions.popitem(last=False);self.stats['evictions']+=1
            key=self.next_key;self.next_key+=1;self.regions[key]=region;self.last_region=key
            self.stats['region_builds']+=1
        self.stats['region_build_seconds']+=perf_counter()-started
        self._observe_memory()

    def solve(self,theta):
        theta=np.asarray(theta,float).reshape(-1)
        if theta.shape!=(self.rank,) or not np.isfinite(theta).all():raise ValueError('Invalid edit parameter dimension/value.')
        y=self.y0+self.Y@theta;q=self.Hy0+self.HY@theta
        prediction=None;t=perf_counter()
        if self.use_regions:
            for key in reversed(self.regions):
                r=self.regions[key];valid,u,lam,radius=self._evaluate(r,theta)
                if prediction is None and self.predict:prediction=np.flatnonzero(lam-self.kernel.scale*(u-self.b)>0)
                if valid:
                    self.stats['membership_seconds']+=perf_counter()-t;t=perf_counter()
                    residual,e=residual_kkt(self.H,self.b,q,u,lam);self.stats['terminal_seconds']+=perf_counter()-t
                    if residual<=self.kernel.tol:
                        self.stats['region_hits']+=1;self.regions.move_to_end(key);self.last_region=key
                        return dict(u=u,lam=lam,active=r['active'].copy(),kkt=residual,iterations=0,
                            cache_hit=True,h_error_bound=radius,stats=self.counters())
                    self.stats['rejected_candidates']+=1;t=perf_counter()
        self.stats['membership_seconds']+=perf_counter()-t;self.stats['region_misses']+=1
        state=self.kernel.solve(y,q,prediction if self.predict else None)
        self.stats['qp_solves']+=1
        if self.use_regions:self._build(theta,y,q,state)
        state.update(cache_hit=False,h_error_bound=None,stats=self.counters());self._observe_memory()
        return state

    def counters(self):
        out=dict(self.kernel.stats,**self.stats)
        if hasattr(self.kernel,'updated'):out['native_factor']=self.kernel.updated.stats.copy()
        return out

    def _observe_memory(self,extra=0):
        response=sum(r['bytes'] for r in self.regions.values());self.stats['peak_response_bytes']=max(self.stats['peak_response_bytes'],response)
        owned=response+self.kernel.factor_bytes+sum(x.nbytes for x in [self.b,self.Y,self.y0,self.HY,self.Hy0,self.diagroot,self.kernel.scale,self.kernel.A,self.kernel.F,self.kernel.coupling])+sparse_bytes(self.H)
        self.stats['peak_owned_array_bytes']=max(self.stats['peak_owned_array_bytes'],int(owned+extra))

    def memory(self):
        self._observe_memory()
        native=self.kernel.updated.memory_payload() if hasattr(self.kernel,'updated') else None
        # Count unique live numerical buffers. Sparse and array aliases share
        # their allocation owner; the update backend owns a second H copy.
        seen=set();python_bytes=0
        def count(x):
            nonlocal python_bytes
            if sparse.issparse(x):
                for a in [x.data,x.indices,x.indptr]:count(a)
            elif isinstance(x,np.ndarray):
                owner=x
                while isinstance(owner.base,np.ndarray):owner=owner.base
                address=int(owner.__array_interface__['data'][0]);key=(address,owner.nbytes)
                if key not in seen:seen.add(key);python_bytes+=owner.nbytes
        for obj,names in [(self,['H','b','Y','y0','HY','Hy0','diagroot']),
                          (self.kernel,['H','b','scale','A','F','coupling','HbA','_mask'])]:
            for name in names:
                if hasattr(obj,name):count(getattr(obj,name))
        if hasattr(self.kernel,'updated'):
            for name in ['H','diagonal','mask','active','permutation']:count(getattr(self.kernel.updated,name))
        for region in self.regions.values():
            for value in region.values():count(value)
        native_bytes=native['native_tracked_bytes'] if native else self.kernel.factor_bytes
        return dict(native_factor=native,region_count=len(self.regions),response_bytes=sum(r['bytes'] for r in self.regions.values()),
            inverse_column_bytes=0,active_factor_bytes=native_bytes,
            current_python_numeric_bytes=int(python_bytes),current_retained_numeric_bytes=int(python_bytes+native_bytes),
            peak_response_bytes=self.stats['peak_response_bytes'],
            scope='Current unique retained Python numerical buffers plus current native tracked allocation. Native lifetime peak is separate; no combined payload peak is inferred. Process peak RSS is measured independently. Historical stats.peak_owned_array_bytes is deprecated and not a total-memory result.')
