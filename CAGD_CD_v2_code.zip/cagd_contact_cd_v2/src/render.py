"""Orthographic renderer. Exact saved triangles; interpolated lighting only."""

import math
import hashlib

import numpy as np

HANDLE_COLOR="#C64E50"

def sha256_file(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def sha256_array(array):
    array = np.ascontiguousarray(array)
    digest = hashlib.sha256()
    digest.update(str(array.dtype).encode())
    digest.update(str(array.shape).encode())
    digest.update(array.tobytes())
    return digest.hexdigest()

def color_rgb(hex_color):
    return np.array([int(hex_color[i:i + 2], 16) / 255.0 for i in (1, 3, 5)])

def normalized(vector):
    return vector / max(float(np.linalg.norm(vector)), 1e-30)

def camera_coordinates(vertices, case, elevation, azimuth):
    """Rigid display transformation only; original arrays remain read-only."""
    vertices = np.asarray(vertices, dtype=float)
    if vertices.shape[1] == 2:
        xyz = np.column_stack((vertices, np.zeros(len(vertices))))
    else:
        xyz = vertices.copy()
    if case == "bunny":
        # Proper rigid rotation: original y becomes vertical, original z -> -y.
        xyz = xyz[:, [0, 2, 1]] * np.array([1.0, -1.0, 1.0])
    el, az = np.deg2rad([elevation, azimuth])
    right = np.array([-np.sin(az), np.cos(az), 0.0])
    up = np.array([-np.cos(az) * np.sin(el), -np.sin(az) * np.sin(el), np.cos(el)])
    toward = np.array([np.cos(az) * np.cos(el), np.sin(az) * np.cos(el), np.sin(el)])
    return xyz @ np.vstack((right, up, toward)).T

def paired_bounds(projected, width, height):
    """Identical orthographic scale and center for both members of one pair."""
    xy = np.vstack([p[:, :2] for p in projected])
    lo, hi = xy.min(axis=0), xy.max(axis=0)
    center = (lo + hi) / 2
    aspect = width / height
    span_x = 1.16 * max(float(hi[0] - lo[0]), float(hi[1] - lo[1]) * aspect, 1e-9)
    span = np.array([span_x, span_x / aspect])
    return center - span / 2, center + span / 2

def display_normals(projected, faces):
    """Area-weighted, two-sided vertex normals, for lighting only.

    Face normals are oriented toward the camera before accumulation. This avoids
    cancellation from the known inconsistent winding in the open Bunny scan.
    Faces, connectivity, vertices, silhouettes and depth are not changed.
    """
    tri = projected[faces]
    face_normals = np.cross(tri[:, 1] - tri[:, 0], tri[:, 2] - tri[:, 0])
    face_normals[face_normals[:, 2] < 0] *= -1
    normals = np.zeros_like(projected)
    for corner in range(3):
        np.add.at(normals, faces[:, corner], face_normals)
    lengths = np.linalg.norm(normals, axis=1)
    valid = lengths > 1e-30
    normals[valid] /= lengths[valid, None]
    normals[~valid] = np.array([0.0, 0.0, 1.0])
    return normals

def rasterize(projected, faces, fixed, bounds, width, height, base_color, dpi):
    """Render exact projected triangles using barycentric depth and lighting."""
    lo, hi = bounds
    screen = projected.copy()
    screen[:, 0] = (projected[:, 0] - lo[0]) / (hi[0] - lo[0]) * (width - 1)
    screen[:, 1] = (hi[1] - projected[:, 1]) / (hi[1] - lo[1]) * (height - 1)
    image = np.ones((height, width, 3), dtype=np.float32)
    depth = np.full((height, width), -np.inf, dtype=float)
    normals = display_normals(projected, faces)
    base = color_rgb(base_color) if isinstance(base_color,str) else np.asarray(base_color)
    key = normalized(np.array([-0.45, 0.65, 1.0]))
    fill = normalized(np.array([0.7, -0.2, 0.7]))
    half = normalized(key + np.array([0.0, 0.0, 1.0]))
    degenerate = 0
    for fi,face in enumerate(faces):
        tri = screen[face]
        x0, y0 = tri[0, :2]
        x1, y1 = tri[1, :2]
        x2, y2 = tri[2, :2]
        denominator = (x1 - x0) * (y2 - y0) - (y1 - y0) * (x2 - x0)
        if abs(denominator) < 1e-12:
            degenerate += 1
            continue
        xmin = max(0, int(math.floor(float(tri[:, 0].min()))))
        xmax = min(width - 1, int(math.ceil(float(tri[:, 0].max()))))
        ymin = max(0, int(math.floor(float(tri[:, 1].min()))))
        ymax = min(height - 1, int(math.ceil(float(tri[:, 1].max()))))
        if xmin > xmax or ymin > ymax:
            continue
        xx, yy = np.meshgrid(np.arange(xmin, xmax + 1), np.arange(ymin, ymax + 1))
        b1 = ((xx - x0) * (y2 - y0) - (yy - y0) * (x2 - x0)) / denominator
        b2 = ((x1 - x0) * (yy - y0) - (y1 - y0) * (xx - x0)) / denominator
        b0 = 1.0 - b1 - b2
        inside = (b0 >= -1e-9) & (b1 >= -1e-9) & (b2 >= -1e-9)
        zz = b0 * tri[0, 2] + b1 * tri[1, 2] + b2 * tri[2, 2]
        subdepth = depth[ymin:ymax + 1, xmin:xmax + 1]
        visible = inside & (zz > subdepth)
        if not np.any(visible):
            continue
        # Shade only pixels actually reaching the depth buffer.
        ns = (b0[visible, None] * normals[face[0]] +
              b1[visible, None] * normals[face[1]] +
              b2[visible, None] * normals[face[2]])
        ns /= np.maximum(np.linalg.norm(ns, axis=1, keepdims=True), 1e-30)
        diffuse = 0.48 + 0.40 * np.maximum(ns @ key, 0) + 0.12 * np.maximum(ns @ fill, 0)
        specular = 0.085 * np.maximum(ns @ half, 0) ** 35
        shaded = np.clip(diffuse[:, None] * (base if base.ndim==1 else base[fi]) + specular[:, None], 0.0, 1.0)
        subimage = image[ymin:ymax + 1, xmin:xmax + 1]
        subimage[visible] = shaded
        subdepth[visible] = zz[visible]

    # Small anti-aliased red controls, with mesh-depth occlusion, in both views.
    radius = max(2.2, 0.62 * dpi / 72.0)
    ztol = max(float(np.ptp(projected[:, 2])) * 0.002, 1e-12)
    marker_color = color_rgb(HANDLE_COLOR)
    drawn_controls = 0
    for idx in fixed:
        sx, sy, sz = screen[idx]
        xmin, xmax = max(0, int(sx - radius - 1)), min(width - 1, int(sx + radius + 1))
        ymin, ymax = max(0, int(sy - radius - 1)), min(height - 1, int(sy + radius + 1))
        if xmin > xmax or ymin > ymax:
            continue
        xx, yy = np.meshgrid(np.arange(xmin, xmax + 1), np.arange(ymin, ymax + 1))
        distance = np.sqrt((xx - sx) ** 2 + (yy - sy) ** 2)
        coverage = np.clip(radius + 0.5 - distance, 0, 1)
        visible = sz >= depth[ymin:ymax + 1, xmin:xmax + 1] - ztol
        coverage *= visible
        if np.any(coverage):
            drawn_controls += 1
        patch = image[ymin:ymax + 1, xmin:xmax + 1]
        patch[:] = coverage[:, :, None] * marker_color + (1 - coverage[:, :, None]) * patch
    stats = {
        "input_faces": len(faces),
        "projected_zero_area_faces": degenerate,
        "mesh_pixels": int(np.count_nonzero(np.isfinite(depth))),
        "control_count": len(fixed),
        "controls_with_visible_pixels": drawn_controls,
    }
    return np.round(255 * image).astype(np.uint8), stats
