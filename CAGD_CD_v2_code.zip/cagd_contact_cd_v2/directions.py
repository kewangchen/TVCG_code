"""Analytically located first-contact directional tests on all six base charts."""
from pathlib import Path
import numpy as np
from .cases import MAIN,build
from .src.frozen_baseline import ContactSolver
from .src.response import BranchResponseSolver
from .benchmark import dump
ROOT=Path(__file__).resolve().parent

def run():
 rows=[]
 for name in MAIN:
  c=build(name);H,b=c['H'],c['b'];v=c['Y'][:,0];theta=float(np.min(b[v<0]/v[v<0]));y=theta*v
  weak=np.flatnonzero(abs(y-b)<1e-13);y[weak]=b[weak]
  # Exact first onset has lambda=0, so weak inequalities remain one-sided.
  cone=ContactSolver(H,np.zeros(len(b)),indices=weak)
  opening=-v;closing=v
  ro=cone.solve(opening,warm=False);rc=cone.solve(closing,warm=False)
  frozen,_=cone.branch(opening,weak,target=np.zeros(len(b)))
  errors=[];obs=int(weak[0]);s=BranchResponseSolver(H,b,c['Y'],c['mass_lower_bound'])
  for eps in [1e-3,1e-4,1e-5,1e-6]:
   minus=s.solve([theta-eps])['u'];plus=s.solve([theta+eps])['u']
   fd=(minus-y)/eps;central=(minus-plus)/(2*eps)
   errors.append(dict(epsilon=eps,opening_relative_error=float(np.linalg.norm(fd-ro['u'])/max(np.linalg.norm(ro['u']),1e-30)),frozen_relative_error=float(np.linalg.norm(fd-frozen)/max(np.linalg.norm(ro['u']),1e-30)),central_relative_error=float(np.linalg.norm(fd-central)/max(np.linalg.norm(ro['u']),1e-30)),observed_opening=float(fd[obs]),observed_central=float(central[obs])))
  d0=float(ro['u'][obs]);f0=float(frozen[obs]);c0=.5*float(ro['u'][obs]-rc['u'][obs])
  budgets=[];rng=np.random.default_rng(441)
  for amp in [1e-6,1e-5,1e-4,1e-3]:
   p=ro['u']+amp*rng.normal(size=len(b));p[weak]=np.maximum(p[weak],0)
   mu=np.zeros(len(b));mu[weak]=amp*np.abs(rng.normal(size=len(weak)))
   e=H@(p-opening)-mu;upper=.5*float(e@e)/c['mass_lower_bound']+float(mu@p)
   radius=float(np.sqrt(2*upper));diff=p-ro['u'];actual=float(np.sqrt(diff@(H@diff)))
   budgets.append(dict(amplitude=amp,actual_h_error=actual,h_error_bound=radius,observed_error=float(abs(diff[obs])),observed_bound=radius/np.sqrt(c['mass_lower_bound'])))
  rows.append(dict(case=name,dofs=len(b),theta_onset=theta,weak_count=len(weak),observation=obs,opening_slope=d0,frozen_slope=f0,central_slope=c0,closing_slope=float(rc['u'][obs]),cone_kkt=max(ro['kkt'],rc['kkt']),errors=errors,budget_tests=budgets))
 dump(ROOT/'results/directions.json',rows)
 print([(r['case'],r['weak_count'],r['errors'][-1]['opening_relative_error']) for r in rows])
if __name__=='__main__':run()
