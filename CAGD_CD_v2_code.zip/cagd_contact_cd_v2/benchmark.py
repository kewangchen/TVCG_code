"""Isolated-process repeated solver comparison; all online work is timed."""
from pathlib import Path
import argparse,hashlib,json,os,platform,resource,subprocess,sys,time,shutil
import numpy as np
import scipy
from scipy import sparse
from .cases import MAIN,build,path
from .src.response import BranchResponseSolver
from .src.strong_baseline import CondensedSchurSolver
from .src.frozen_baseline import kkt
ROOT=Path(__file__).resolve().parent
METHODS=['response','warm_update','condensed','osqp','proxqp']

def safe(x):
 if isinstance(x,np.ndarray):return x.tolist()
 if isinstance(x,np.generic):return x.item()
 if isinstance(x,dict):return {k:safe(v) for k,v in x.items()}
 if isinstance(x,(list,tuple)):return [safe(v) for v in x]
 return x

def dump(p,x):p.write_text(json.dumps(safe(x),indent=2,allow_nan=False)+'\n')

def worker(folder,name,level,rank,method,repeat,count=41,kind='smooth',prox_eps=1e-10):
 import osqp,proxsuite
 c=build(name,level,rank);H,b,Y=c['H'],c['b'],c['Y'];theta=path(count,rank,kind)
 n=len(b);records=[];states=[];duals=[];start=time.perf_counter()
 if method in ['response','warm_update']:
  solver=BranchResponseSolver(H,b,Y,c['mass_lower_bound'],use_regions=method=='response',predict=method=='response')
 elif method=='condensed':solver=CondensedSchurSolver(H,b)
 elif method=='osqp':
  solver=osqp.OSQP();solver.setup(P=sparse.triu(H).tocsc(),q=-H@(Y@theta[0]),A=sparse.eye(n,format='csc'),l=b,u=np.full(n,np.inf),eps_abs=1e-10,eps_rel=1e-10,max_iter=200000,polishing=True,verbose=False,adaptive_rho=True,warm_starting=True,check_termination=10)
 elif method=='proxqp':
  solver=proxsuite.proxqp.sparse.QP(n,0,n);solver.settings.eps_abs=prox_eps;solver.settings.eps_rel=0.;solver.settings.max_iter=10000
  solver.settings.sparse_backend=proxsuite.proxqp.SparseBackend.SparseCholesky
  solver.settings.initial_guess=proxsuite.proxqp.InitialGuess.WARM_START_WITH_PREVIOUS_RESULT
  solver.init(H=sparse.triu(H).tocsc(),g=-H@(Y@theta[0]),C=sparse.eye(n,format='csc'),l=b,u=np.full(n,np.inf))
 else:raise ValueError(method)
 setup=time.perf_counter()-start
 for j,t in enumerate(theta):
  began=time.perf_counter();y=Y@t;status='solved';hit=False
  if method in ['response','warm_update']:
   r=solver.solve(t);u,lam=r['u'],r['lam'];iters=r['iterations'];hit=r['cache_hit']
  elif method=='condensed':
   r=solver.solve(y);u,lam=r['u'],r['lam'];iters=r['iterations']
  elif method=='osqp':
   solver.update(q=-H@y);r=solver.solve(raise_error=False);u,lam=r.x,-r.y;iters=r.info.iter;status=r.info.status
  else:
   solver.update(g=-H@y);solver.solve();u,lam=solver.results.x.copy(),-solver.results.z.copy();iters=solver.results.info.iter;status=str(solver.results.info.status)
  residual=kkt(H,b,y,u,lam);d=u-y;energy=.5*float(d@(H@d))
  records.append(dict(step=j,theta=t,seconds=time.perf_counter()-began,kkt=residual,energy=energy,iterations=int(iters),status=str(status),cache_hit=hit,active=int(np.sum(u-b<1e-7))))
  states.append(u.copy());duals.append(lam.copy())
 total=time.perf_counter()-start
 rss=resource.getrusage(resource.RUSAGE_SELF).ru_maxrss*(1 if sys.platform=='darwin' else 1024)
 if method in ['response','warm_update']:memory=solver.memory();stats=solver.counters()
 elif method=='condensed':memory=solver.memory_payload();stats=solver.stats.copy()
 else:memory=dict(scope='Internal library payload not exposed; compare isolated process peak RSS.');stats={}
 folder=Path(folder);folder.mkdir(parents=True,exist_ok=True);tag=f'{method}_{repeat}'
 rec=dict(case=name,level=level,rank=rank,dofs=n,vertices=len(c['X']),queries=len(theta),method=method,repeat=repeat,setup_seconds=setup,total_seconds=total,steps=records,all_qualified=all(r['kkt']<=2e-9 for r in records),kkt_max=max(r['kkt'] for r in records),stats=stats,memory=memory,peak_process_rss_bytes=int(rss),rss_scope='Isolated worker process lifetime peak; imports and model construction included, not memory delta.',environment=dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,osqp=osqp.__version__,proxsuite=proxsuite.__version__,platform=platform.platform()))
 dump(folder/f'{tag}.json',rec);np.savez_compressed(folder/f'{tag}.npz',states=states,duals=duals,theta=theta)
 if not (folder/'model.npz').exists():
  sparse.save_npz(folder/'H.npz',H);np.savez_compressed(folder/'model.npz',X=c['X'],normals=c['normals'],faces=c['faces'],fixed=c['fixed'],free=c['free'],b=b,Y=Y,area_mass=c['area_mass'],gap0=c['gap0'],clearance=c['clearance'],mass_lower_bound=c['mass_lower_bound'])
 rec['external_absolute_tolerance']=prox_eps if method=='proxqp' else (1e-10 if method=='osqp' else None)
 dump(folder/f'{tag}.json',rec)
 print(name,level,rank,method,repeat,f'{total:.6f}',f'KKT {rec["kkt_max"]:.2e}',flush=True)

def run(phase='formal_01',repeats=3):
 out=ROOT/'results'/phase
 if out.exists():raise RuntimeError('Results are immutable; choose a new phase.')
 out.mkdir(parents=True)
 configs=[(name,level,1) for name in MAIN for level in ['base','fine']]+[(name,'fine',3) for name in ['strip','torus','nist_ctc_02']]
 sources=[p for p in ROOT.rglob('*.py') if 'results' not in p.parts]
 hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources}
 for p in sources:
  dest=out/'executed_source'/p.relative_to(ROOT);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
 dump(out/'protocol.json',dict(configurations=configs,methods=METHODS,proxqp_scope='All six base meshes; fine meshes use OSQP as external comparator. ProxQP fine-grid pilot retained separately.',repeats=repeats,queries=41,path_rank1=path().tolist(),path_rank3=path(rank=3).tolist(),source_sha256=hashes,timing='Setup+all online QPs, nativeupdates, response construction/membership, terminal KKT, state copies; excludes common geometry assembly, file compression, memory inspection and endpoint collision audits.',cache_policy='4 affine regions,16MiB retained response limit;no future active sets;one sparse factor.',qualification_kkt=2e-9,thread_environment={k:os.getenv(k) for k in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','VECLIB_MAXIMUM_THREADS']}))
 for name,level,rank in configs:
  folder=out/f'{name}_{level}_r{rank}';folder.mkdir()
  for rep in range(repeats):
   selected=METHODS if level=='base' else METHODS[:-1]
   order=selected[rep:]+selected[:rep]
   for method in order:
    subprocess.run([sys.executable,'-m','cagd_contact_cd_v2.benchmark','--worker','--folder',str(folder),'--case',name,'--level',level,'--rank',str(rank),'--method',method,'--repeat',str(rep)],check=True,timeout=300)
 runs=sum((5 if level=='base' else 4)*repeats for _,level,_ in configs)
 dump(out/'completed.json',dict(configurations=len(configs),runs=runs,query_solves=runs*41))

if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--worker',action='store_true');p.add_argument('--folder');p.add_argument('--case');p.add_argument('--level',default='base');p.add_argument('--rank',type=int,default=1);p.add_argument('--method');p.add_argument('--repeat',type=int,default=0);p.add_argument('--phase',default='formal_01');p.add_argument('--count',type=int,default=41);p.add_argument('--kind',default='smooth');p.add_argument('--prox-eps',type=float,default=1e-10);a=p.parse_args()
 if a.worker:worker(a.folder,a.case,a.level,a.rank,a.method,a.repeat,a.count,a.kind,a.prox_eps)
 else:run(a.phase)
