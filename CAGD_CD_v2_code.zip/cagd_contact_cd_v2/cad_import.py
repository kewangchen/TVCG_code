"""Import the bundled, authored NIST STEP BReps through Gmsh/OpenCASCADE.

No geometry is constructed here. The public source STEP files are meshed as
trimmed kernel faces. Coordinates are exported in millimetres, including the
explicit inch-to-mm conversion performed by OpenCASCADE for CTC-03.

Run: python cagd_contact_cd_v2/cad_import.py build --gmsh-path /path/to/gmsh
The meshes can be consumed without Gmsh; only rebuilding needs the kernel.
"""
from __future__ import annotations

import argparse
from collections import defaultdict, deque
import hashlib
import importlib
import json
from pathlib import Path
import re
import sys
import time

import numpy as np

ROOT = Path(__file__).resolve().parent
ASSETS = ROOT / "assets"
SOURCE_PAGE = "https://www.nist.gov/ctl/smart-connected-systems-division/smart-connected-manufacturing-systems-group/mbe-pmi-0"
SOURCE_URL = "https://www.nist.gov/document/nist-ctc-test-case-definitions"
MODELS = {
    "nist_ctc_01": dict(filename="nist_ctc_01_asme1_rd.stp", face_ids=[4],
                        description="Trimmed planar plate face with eleven inner wires",
                        source_units="millimetre", source_to_mm=1.0,
                        sizes=dict(coarse=22.0, medium=13.0, fine=8.0), context_size=22.0),
    "nist_ctc_02": dict(filename="nist_ctc_02_asme1_rc.stp", face_ids=[144],
                        description="Authored bicubic B-spline blend face on the housing",
                        source_units="millimetre", source_to_mm=1.0,
                        sizes=dict(coarse=3.4, medium=1.9, fine=1.2), context_size=24.0),
    "nist_ctc_03": dict(filename="nist_ctc_03_asme1_rc.stp", face_ids=[8, 39, 15],
                        description="Connected sheet face, cylindrical bend, and upright flange",
                        source_units="inch", source_to_mm=25.4,
                        sizes=dict(coarse=13.0, medium=7.8, fine=4.8), context_size=13.0),
}


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def boundary_edges(faces):
    """Undirected boundary edges and edge multiplicities of a triangle mesh."""
    f = np.asarray(faces, dtype=np.int64)
    edges = np.sort(np.vstack((f[:, [0, 1]], f[:, [1, 2]], f[:, [2, 0]])), axis=1)
    unique, counts = np.unique(edges, axis=0, return_counts=True)
    return unique[counts == 1], unique, counts


def _components(n, edges):
    graph = [[] for _ in range(n)]
    for i, j in edges:
        graph[int(i)].append(int(j)); graph[int(j)].append(int(i))
    seen, count = set(), 0
    for start in range(n):
        if start in seen or not graph[start]:
            continue
        count += 1
        queue = [start]; seen.add(start)
        while queue:
            for nb in graph[queue.pop()]:
                if nb not in seen:
                    seen.add(nb); queue.append(nb)
    return count


def mesh_quality(X, faces, normals=None):
    X, faces = np.asarray(X), np.asarray(faces)
    boundary, edges, multiplicity = boundary_edges(faces)
    cross = np.cross(X[faces[:, 1]] - X[faces[:, 0]], X[faces[:, 2]] - X[faces[:, 0]])
    double_area = np.linalg.norm(cross, axis=1)
    edge_length = np.linalg.norm(X[edges[:, 0]] - X[edges[:, 1]], axis=1)
    diagonal = float(np.linalg.norm(np.ptp(X, axis=0)))
    duplicate_coords = len(X) - len(np.unique(np.round(X / max(diagonal, 1.0), 12), axis=0))
    out = dict(nodes=len(X), triangles=len(faces), boundary_nodes=len(np.unique(boundary)),
               boundary_components=_components(len(X), boundary),
               connected_components=_components(len(X), edges),
               nonmanifold_edges=int(np.sum(multiplicity > 2)),
               duplicate_coordinate_nodes=int(duplicate_coords),
               duplicate_triangles=int(len(faces) - len(np.unique(np.sort(faces, axis=1), axis=0))),
               min_triangle_area_mm2=float(double_area.min() / 2),
               mesh_area_mm2=float(double_area.sum() / 2),
               min_edge_mm=float(edge_length.min()), max_edge_mm=float(edge_length.max()),
               bbox_mm=[X.min(axis=0).tolist(), X.max(axis=0).tolist()],
               bbox_diagonal_mm=diagonal)
    if normals is not None:
        lengths = np.linalg.norm(normals, axis=1)
        alignment = np.sum(cross * normals[faces].mean(axis=1), axis=1) / double_area
        out.update(min_normal_length=float(lengths.min()), max_normal_length=float(lengths.max()),
                   min_triangle_normal_alignment=float(alignment.min()))
    if (not np.isfinite(X).all() or double_area.min() <= diagonal ** 2 * 1e-14
            or duplicate_coords or out["duplicate_triangles"] or out["nonmanifold_edges"]):
        raise ValueError("Invalid CAD tessellation: " + json.dumps(out))
    return out


def _orient(faces):
    """Give all connected triangles a common orientation, preserving topology."""
    faces = np.asarray(faces, dtype=np.int64).copy()
    incidence = defaultdict(list)
    for t, tri in enumerate(faces):
        for a, b in zip(tri, np.roll(tri, -1)):
            incidence[tuple(sorted((int(a), int(b))))].append((t, int(a) < int(b)))
    adjacency = defaultdict(list)
    for rows in incidence.values():
        if len(rows) == 2:
            (a, da), (b, db) = rows
            adjacency[a].append((b, da == db)); adjacency[b].append((a, da == db))
    flips = {}
    for start in range(len(faces)):
        if start in flips:
            continue
        flips[start] = False; queue = deque([start])
        while queue:
            a = queue.popleft()
            for b, opposite in adjacency[a]:
                desired = flips[a] ^ opposite
                if b in flips and flips[b] != desired:
                    raise ValueError("Nonorientable mesh")
                if b not in flips:
                    flips[b] = desired; queue.append(b)
    for i, flip in flips.items():
        if flip:
            faces[i, [1, 2]] = faces[i, [2, 1]]
    return faces


def _step_inventory(path):
    """Source entity IDs in CLOSED_SHELL traversal order (one solid here)."""
    text = Path(path).read_text()
    entities = {int(i): v for i, v in re.findall(r"#(\d+)\s*=\s*([^;]*);", text)}
    shells = [v for v in entities.values() if v.startswith("CLOSED_SHELL")]
    if len(shells) != 1:
        raise ValueError("These source models must each contain one CLOSED_SHELL")
    rows = []
    for position, face_id in enumerate(re.findall(r"#(\d+)", shells[0]), 1):
        face_id = int(face_id); face = entities[face_id]
        surface_id = int(re.findall(r"#(\d+)", face)[-1])
        rows.append(dict(source_closed_shell_position=position, step_advanced_face_entity=face_id,
                         step_surface_entity=surface_id, step_face_definition=face,
                         step_surface_definition_prefix=entities[surface_id][:160]))
    return rows


def _load(gmsh, path):
    gmsh.clear()
    gmsh.option.setString("Geometry.OCCTargetUnit", "MM")
    gmsh.model.occ.importShapes(str(path), highestDimOnly=True)
    gmsh.model.occ.synchronize()


def _configure_mesh(gmsh, size, selected=None):
    gmsh.model.setVisibility(gmsh.model.getEntities(), 1, True)
    if selected is not None:
        gmsh.model.setVisibility(gmsh.model.getEntities(), 0, True)
        gmsh.model.setVisibility([(2, t) for t in selected], 1, True)
    # Full-part context includes tiny paired semicircular CAD edges. A global
    # floor equal to the display size can reduce each arc to its endpoints,
    # giving two different arcs the same mesh edge. Permit curvature sizing
    # below the display size for context, so its closed surface stays manifold.
    minimum_size = size if selected is not None else min(size, 0.1)
    for key, value in {"Mesh.MeshOnlyVisible": int(selected is not None),
                       "Mesh.MeshSizeMin": minimum_size, "Mesh.MeshSizeMax": size,
                       "Mesh.MeshSizeFromPoints": 0, "Mesh.MeshSizeFromCurvature": 16,
                       "Mesh.MeshSizeExtendFromBoundary": 0, "Mesh.Algorithm": 6,
                       "Mesh.ElementOrder": 1, "Mesh.RecombineAll": 0,
                       "General.NumThreads": 1, "Mesh.MaxNumThreads1D": 1,
                       "Mesh.MaxNumThreads2D": 1, "Mesh.RandomFactor": 1e-9}.items():
        gmsh.option.setNumber(key, value)
    gmsh.model.mesh.generate(2)


def _extract(gmsh, selected, include_kernel=True):
    node_tags, xyz, _ = gmsh.model.mesh.getNodes()
    all_X = np.asarray(xyz).reshape(-1, 3)
    tag_to_row = {int(t): i for i, t in enumerate(node_tags)}
    triangles, entity_ids = [], []
    for face_id in selected:
        types, _, nodes = gmsh.model.mesh.getElements(2, int(face_id))
        for typ, flat in zip(types, nodes):
            if typ != 2:
                raise ValueError("Expected first-order triangles, got element type " + str(typ))
            tris = np.asarray(flat, dtype=np.int64).reshape(-1, 3)
            triangles.extend(tris); entity_ids.extend([face_id] * len(tris))
    triangles = np.asarray(triangles, dtype=np.int64)
    used_tags = np.unique(triangles)
    X = all_X[[tag_to_row[int(t)] for t in used_tags]]
    faces = np.searchsorted(used_tags, triangles)
    # OCC meshes normally share boundary node tags. Weld only coincident
    # seam nodes, using a documented 1e-12 relative rounding tolerance.
    diag = max(float(np.linalg.norm(np.ptp(X, axis=0))), 1.0)
    _, first, inverse = np.unique(np.round(X / diag, 12), axis=0,
                                 return_index=True, return_inverse=True)
    if len(first) < len(X):
        X = X[first]; faces = inverse[faces]
        used_tags = used_tags[first]
    faces = _orient(faces)
    boundary, _, _ = boundary_edges(faces)
    result = dict(X=X, faces=faces, cad_face_ids=np.asarray(entity_ids, dtype=np.int64),
                  boundary_edges=boundary, boundary_node_ids=np.unique(boundary),
                  gmsh_node_tags=used_tags)
    if include_kernel:
        normal_sum = np.zeros_like(X)
        geometric = np.zeros_like(X)
        cross = np.cross(X[faces[:, 1]] - X[faces[:, 0]], X[faces[:, 2]] - X[faces[:, 0]])
        for corner in range(3):
            np.add.at(geometric, faces[:, corner], cross)
        uv = np.full((len(X), 2), np.nan)
        uv_face = np.zeros(len(X), dtype=np.int64)
        node_face_uv, sampled_curvatures = [], []
        for face_id in selected:
            node_ids = np.unique(faces[np.asarray(entity_ids) == face_id])
            param = np.asarray(gmsh.model.getParametrization(2, int(face_id), X[node_ids].ravel())).reshape(-1, 2)
            normals = np.asarray(gmsh.model.getNormal(int(face_id), param.ravel())).reshape(-1, 3)
            # Underlying parameter directions can differ across CAD faces.
            normals[np.sum(normals * geometric[node_ids], axis=1) < 0] *= -1
            normal_sum[node_ids] += normals
            unset = uv_face[node_ids] == 0
            uv[node_ids[unset]] = param[unset]; uv_face[node_ids[unset]] = face_id
            node_face_uv.append(np.column_stack((node_ids, np.full(len(node_ids), face_id), param)))
            kmax, kmin, _, _ = gmsh.model.getPrincipalCurvatures(int(face_id), param.ravel())
            sampled_curvatures.extend(np.abs(np.r_[kmax, kmin]).tolist())
        normals = normal_sum / np.linalg.norm(normal_sum, axis=1, keepdims=True)
        result.update(normals=normals, uv=uv, uv_face_ids=uv_face,
                      node_face_uv=np.vstack(node_face_uv))
        maximum = max(sampled_curvatures)
        radius = float(1 / maximum) if maximum > 1e-12 else None
    else:
        radius = None
    return result, radius


def build(gmsh_path=None, model_names=None):
    if gmsh_path:
        sys.path.insert(0, str(gmsh_path))
    gmsh = importlib.import_module("gmsh")
    if gmsh.__version__ != "4.15.2":
        raise RuntimeError("Rebuilding the audited face selection requires pinned gmsh==4.15.2")
    gmsh.initialize([], readConfigFiles=False)
    gmsh.option.setNumber("General.Terminal", 0)
    build_info = gmsh.option.getString("General.BuildInfo")
    selected_models = model_names or list(MODELS)
    index = {}
    try:
        for name in selected_models:
            start = time.perf_counter()
            cfg = MODELS[name]; source = ASSETS / "raw" / cfg["filename"]
            out = ASSETS / name; out.mkdir(parents=True, exist_ok=True)
            _load(gmsh, source)
            source_faces = _step_inventory(source)
            kernel_faces = gmsh.model.getEntities(2)
            if len(kernel_faces) != len(source_faces):
                raise ValueError("Kernel changed source face count; reselect and audit faces")
            inventory = []
            for (dim, tag), raw in zip(kernel_faces, source_faces):
                inventory.append(dict(raw, gmsh_face_id=tag, type=gmsh.model.getType(dim, tag),
                                      area_mm2=gmsh.model.occ.getMass(dim, tag),
                                      bbox_mm=list(gmsh.model.getBoundingBox(dim, tag)),
                                      boundary_curve_ids=[t for _, t in gmsh.model.getBoundary([(dim, tag)], oriented=False)]))
            (out / "face_inventory.json").write_text(json.dumps(inventory, indent=2) + "\n")
            metadata = dict(model=name, description=cfg["description"], source_page=SOURCE_PAGE,
                            source_archive_url=SOURCE_URL, source_filename=cfg["filename"],
                            source_license="NIST public domain under 17 USC 105; acknowledgment requested; no NIST endorsement or logo use",
                            source_license_file="assets/raw/README.txt", retrieved_on="2026-10-17",
                            source_sha256=sha256(source), source_archive_sha256=sha256(ASSETS / "raw" / "nist_ctc_definitions.zip"),
                            source_units=cfg["source_units"], source_unit_to_mm=cfg["source_to_mm"],
                            output_units="millimetre", normalization="none", selected_gmsh_face_ids=cfg["face_ids"],
                            face_id_scope="Gmsh/OpenCASCADE 2D entity tags after importing this exact STEP with pinned Gmsh 4.15.2",
                            source_entity_mapping="The pinned importer traverses the single CLOSED_SHELL in source order; source STEP entities are recorded alongside the kernel face inventory.",
                            selected_faces=[r for r in inventory if r["gmsh_face_id"] in cfg["face_ids"]],
                            source_solid_count=len(gmsh.model.getEntities(3)), source_face_count=len(inventory),
                            gmsh_version=gmsh.__version__, kernel_build_info=build_info,
                            mesh_settings=dict(algorithm=6, order=1, threads=1, size_from_points=False,
                                               size_from_curvature=16, extend_from_boundary=False,
                                               context_min_size_mm=0.1,
                                               selected_min_size_equals_max=True,
                                               coincident_seam_weld_relative_rounding=1e-12),
                            normals="Analytic kernel normals, aligned to connected triangle winding and averaged at shared smooth CAD-face seams; no outward-solid interpretation is required.",
                            uv="uv and uv_face_ids use the first incident selected face. node_face_uv rows contain local node ID, CAD face ID, u, v and retain both charts at seams.",
                            derived_layer_scope="Synthetic paired normal-offset clearance layers may be derived from these meshes. These are not supplied industrial assemblies or NURBS control-net optimization.",
                            meshes={})
            _configure_mesh(gmsh, cfg["context_size"])
            arrays, _ = _extract(gmsh, [t for _, t in kernel_faces], include_kernel=False)
            np.savez_compressed(out / "full_part.npz", **arrays)
            metadata["full_part"] = dict(mesh_quality(arrays["X"], arrays["faces"]), mesh_size_mm=cfg["context_size"],
                                         sha256=sha256(out / "full_part.npz"))
            for level, size in cfg["sizes"].items():
                _load(gmsh, source)
                _configure_mesh(gmsh, size, cfg["face_ids"])
                arrays, radius = _extract(gmsh, cfg["face_ids"])
                quality = mesh_quality(arrays["X"], arrays["faces"], arrays["normals"])
                if quality["connected_components"] != 1 or quality["min_triangle_normal_alignment"] <= 0:
                    raise ValueError("Selected face set must be one consistently oriented component")
                path = out / ("selected_face_" + level + ".npz")
                np.savez_compressed(path, **arrays)
                metadata["meshes"][level] = dict(quality, mesh_size_mm=size,
                                                sampled_min_principal_radius_mm=radius,
                                                radius_scope="Minimum reciprocal absolute principal curvature sampled at mesh nodes; not a certified global curvature bound.",
                                                sha256=sha256(path))
            metadata["build_wall_seconds"] = time.perf_counter() - start
            (out / "metadata.json").write_text(json.dumps(metadata, indent=2) + "\n")
            index[name] = metadata
            print(name, {k: (v["nodes"], v["triangles"]) for k, v in metadata["meshes"].items()}, flush=True)
    finally:
        gmsh.finalize()
    return index


def verify_assets():
    summary = {}
    for name, cfg in MODELS.items():
        out = ASSETS / name
        metadata = json.loads((out / "metadata.json").read_text())
        assert metadata["source_sha256"] == sha256(ASSETS / "raw" / cfg["filename"])
        assert metadata["source_archive_sha256"] == sha256(ASSETS / "raw" / "nist_ctc_definitions.zip")
        summary[name] = {}
        for level in ("coarse", "medium", "fine"):
            path = out / ("selected_face_" + level + ".npz")
            assert sha256(path) == metadata["meshes"][level]["sha256"]
            with np.load(path) as a:
                q = mesh_quality(a["X"], a["faces"], a["normals"])
                assert q["connected_components"] == 1
                assert set(a["cad_face_ids"]) == set(cfg["face_ids"])
                assert np.isfinite(a["uv"]).all()
                assert np.array_equal(a["boundary_node_ids"], np.unique(boundary_edges(a["faces"])[0]))
                assert q["min_triangle_normal_alignment"] > 0
                summary[name][level] = q
        path = out / "full_part.npz"
        assert sha256(path) == metadata["full_part"]["sha256"]
        with np.load(path) as a:
            q = mesh_quality(a["X"], a["faces"])
            assert q["boundary_nodes"] == 0
            assert q["connected_components"] == 1
            assert len(np.unique(a["cad_face_ids"])) == metadata["source_face_count"]
    return summary


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["build", "verify"])
    parser.add_argument("--gmsh-path", type=Path)
    parser.add_argument("--model", action="append", choices=list(MODELS))
    args = parser.parse_args()
    if args.action == "build":
        build(args.gmsh_path, args.model)
    else:
        result = verify_assets()
        print(json.dumps({k: {l: q["nodes"] for l, q in rows.items()} for k, rows in result.items()}, indent=2))


if __name__ == "__main__":
    main()
