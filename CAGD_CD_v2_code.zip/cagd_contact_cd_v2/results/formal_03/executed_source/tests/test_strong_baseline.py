"""Independent checks for the optimized, standard cached-Schur comparators."""
import importlib
import importlib.util
from itertools import combinations

import numpy as np
from numpy.testing import assert_allclose
import pytest
from scipy import sparse

from cagd_contact_cd_v2.src.frozen_baseline import ContactSolver, kkt


def classes():
    module = importlib.import_module('cagd_contact_cd_v2.src.strong_baseline')
    return module.CondensedSchurSolver, module.StreamlinedSchurSolver


def problem(n=8):
    rng = np.random.default_rng(9501 + n)
    a = rng.normal(size=(n, n))
    return a.T @ a + 2 * np.eye(n), rng.normal(size=n) * .2


def exhaustive(H, b, y, indices):
    """Enumerate faces and solve the primal reduced equations, without Schur."""
    answers = []
    n = len(b)
    for size in range(len(indices) + 1):
        for active in combinations(indices, size):
            active = np.array(active, int)
            free = np.setdiff1d(np.arange(n), active)
            u = np.empty(n)
            u[active] = b[active]
            u[free] = np.linalg.solve(H[np.ix_(free, free)],
                                     (H @ y)[free] - H[np.ix_(free, active)] @ b[active])
            lam = np.zeros(n)
            lam[active] = (H @ (u - y))[active]
            if kkt(H, b, y, u, lam, indices) < 1e-9:
                answers.append((u, lam))
    assert len(answers) == 1
    return answers[0]


def test_strong_baseline_module_exists():
    assert importlib.util.find_spec('cagd_contact_cd_v2.src.strong_baseline') is not None


@pytest.mark.parametrize('class_index', [0, 1])
def test_repeated_solve_matches_exhaustive_and_frozen(class_index):
    H, b = problem(6)
    indices = np.array([0, 2, 3, 5])
    solver = classes()[class_index](sparse.csc_matrix(H), b, indices=indices)
    frozen = ContactSolver(H, b, indices=indices)
    ys = np.random.default_rng(42).normal(size=(10, len(b)))
    for y in np.r_[ys, ys[::-1]]:
        expected_u, expected_lam = exhaustive(H, b, y, indices)
        actual = solver.solve(y)
        original = frozen.solve(y)
        assert_allclose(actual['u'], expected_u, atol=2e-9)
        assert_allclose(actual['lam'], expected_lam, atol=2e-9)
        assert_allclose(actual['u'], original['u'], atol=2e-9)
        assert np.array_equal(actual['active'], original['active'])
        assert actual['iterations'] == original['iterations']


@pytest.mark.parametrize('class_index', [0, 1])
def test_repeated_solve_agrees_with_real_osqp(class_index):
    osqp = pytest.importorskip('osqp')
    H, b = problem(19)
    solver = classes()[class_index](H, b)
    oracle = osqp.OSQP()
    oracle.setup(P=sparse.csc_matrix(np.triu(H)), q=np.zeros(len(b)),
                 A=sparse.eye(len(b), format='csc'), l=b,
                 u=np.full(len(b), np.inf), eps_abs=1e-11, eps_rel=1e-11,
                 polishing=True, verbose=False, max_iter=100000)
    for y in np.random.default_rng(79).normal(size=(12, len(b))):
        oracle.update(q=-H @ y)
        reference = oracle.solve(raise_error=False)
        actual = solver.solve(y)
        assert reference.info.status == 'solved'
        assert_allclose(actual['u'], reference.x, atol=2e-8)
        assert_allclose(actual['lam'], -reference.y, atol=2e-8)
        assert actual['kkt'] <= 2e-9


def test_condensed_union_cache_grows_with_overlap_and_order_changes():
    H, b = problem()
    solver = classes()[0](H, b, batch_size=2)
    inverse = np.linalg.inv(H)
    union = set()
    y = np.linspace(-.4, .8, len(b))
    for active in [[4, 1], [1, 6, 4], [6], [7, 2, 0], [4, 1], []]:
        active = np.array(active, int)
        union.update(active)
        u, lam = solver.branch(y, active)
        expected = ContactSolver(H, b).branch(y, active)
        assert_allclose(u, expected[0], atol=1e-11)
        assert_allclose(lam, expected[1], atol=1e-11)
        C = solver.contact_indices
        assert set(C) == union
        assert_allclose(solver.gram, inverse[np.ix_(C, C)], atol=1e-12)
        assert solver.stats['column_solves'] == len(union)
        assert solver.stats['max_rhs_columns'] <= 2
        assert not solver.columns


@pytest.mark.parametrize('class_index', [0, 1])
def test_same_ordered_active_set_reuses_factor_and_target_changes(class_index):
    H, b = problem()
    solver = classes()[class_index](H, b)
    A = np.array([5, 0, 3])
    y = np.linspace(-.4, .8, len(b))
    solver.branch(y, A)
    cache = solver.cache
    target = b + .12
    actual = solver.branch(y * .7, A, target=target)
    expected = ContactSolver(H, b).branch(y * .7, A, target=target)
    assert solver.cache is cache
    assert solver.stats['active_factorizations'] == 1
    assert solver.stats['active_reuses'] == 1
    assert solver.stats['column_solves'] == len(A)
    assert_allclose(actual[0], expected[0], atol=1e-12)
    assert_allclose(actual[1], expected[1], atol=1e-12)
    solver.branch(y, A[::-1])
    assert solver.stats['active_factorizations'] == 2
    assert solver.stats['column_solves'] == len(A)


@pytest.mark.parametrize('class_index', [0, 1])
def test_empty_branch_does_not_allocate_contact_cache(class_index):
    H, b = problem()
    solver = classes()[class_index](H, b)
    y = b + 1
    actual = solver.solve(y)
    assert_allclose(actual['u'], y, atol=0)
    assert not len(actual['active'])
    assert solver.stats['column_solves'] == 0
    assert solver.stats['active_factorizations'] == 0
    assert solver.memory_payload()['cache_bytes'] == 0


def test_condensed_retained_payload_counts_gram_cholesky_and_index_arrays():
    H, b = problem(40)
    solver = classes()[0](H, b, batch_size=2)
    A = np.array([3, 11, 7])
    solver.branch(np.linspace(-1, 1, len(b)), A)
    payload = solver.memory_payload()
    assert payload['gram_bytes'] == 3 * 3 * 8
    assert payload['active_factor_bytes'] == 3 * 3 * 8
    assert payload['cache_bytes'] == payload['gram_bytes'] + payload['active_factor_bytes'] + solver.contact_indices.nbytes
    assert payload['cache_bytes'] < 40 * len(A) * 8
    assert payload['global_factor_bytes'] > 0
    assert solver.stats['max_rhs_columns'] == 2
    assert payload['peak_owned_array_bytes'] >= payload['retained_owned_array_bytes']


def test_condensed_rejects_nonpositive_batch_size():
    H, b = problem()
    with pytest.raises(ValueError, match='batch_size'):
        classes()[0](H, b, batch_size=0)


def test_condensed_explicit_inverse_columns_are_transient_and_batched():
    H, b = problem()
    solver = classes()[0](H, b, batch_size=2)
    A = np.array([4, 1, 7])
    W = solver.inverse_columns(A)
    assert_allclose(W, np.linalg.inv(H)[:, A], atol=1e-12)
    assert not solver.columns
    assert solver.stats['max_rhs_columns'] <= 2
    assert solver.memory_payload()['cache_bytes'] == 0
