"""Sparse CHOLMOD updates checked against independently assembled dense faces."""
import importlib
import importlib.util

import numpy as np
import pytest
from numpy.testing import assert_allclose
from scipy import sparse


def implementation():
    return importlib.import_module('cagd_contact_cd_v2.src.chol_update').UpdateFactor


def dense_face(H, active):
    K = H.copy()
    K[active, :] = 0
    K[:, active] = 0
    K[active, active] = 1
    return K


def test_sparse_update_module_exists():
    assert importlib.util.find_spec('cagd_contact_cd_v2.src.chol_update') is not None


@pytest.mark.parametrize('backend', ['rank2', 'rowmod'])
def test_random_activate_release_sequences_match_independent_dense_solve(backend):
    rng = np.random.default_rng(1204)
    n = 17
    D = rng.normal(size=(n, n))
    H = D.T @ D + np.eye(n) * 2
    factor = implementation()(sparse.csc_matrix(H), backend=backend)
    for active in [[], [3], [3, 1, 7], [1, 9], list(range(n)), [],
                   *[np.flatnonzero(rng.random(n) < .45) for _ in range(35)]]:
        active = np.asarray(active, int)
        factor.update(active)
        rhs = rng.normal(size=(n, 3))
        actual = factor.solve(rhs)
        expected = np.linalg.solve(dense_face(H, active), rhs)
        assert_allclose(actual, expected, rtol=2e-10, atol=2e-10)
    assert factor.stats['numeric_factorizations'] == 1
    assert factor.stats['updates'] > 0
    assert factor.stats['downdates'] > 0


@pytest.mark.parametrize('backend', ['rank2', 'rowmod'])
def test_bound_rhs_matches_reduced_primal_equations(backend):
    rng = np.random.default_rng(92)
    n = 11
    D = rng.normal(size=(n, n))
    H = D.T @ D + np.eye(n)
    b = rng.normal(size=n)
    q = rng.normal(size=n)
    factor = implementation()(H, initial_active=np.arange(n), backend=backend)
    for active in [np.arange(n), [2, 5], [], [0, 4, 7]]:
        active = np.asarray(active, int)
        free = np.setdiff1d(np.arange(n), active)
        factor.update(active)
        rhs = q.copy()
        rhs[free] -= H[np.ix_(free, active)] @ b[active]
        rhs[active] = b[active]
        u = factor.solve(rhs)
        expected = b.copy()
        expected[free] = np.linalg.solve(H[np.ix_(free, free)],
                                         q[free] - H[np.ix_(free, active)] @ b[active])
        assert_allclose(u, expected, atol=2e-10, rtol=2e-10)
        assert_allclose(u[active], b[active], atol=2e-10)


@pytest.mark.parametrize('backend', ['rank2', 'rowmod'])
def test_diagonal_toggles_zero_edges_and_repeat_do_not_refactor(backend):
    H = sparse.diags([.1, 1., 7., 2.], format='csc')
    factor = implementation()(H, initial_active=[0, 2], backend=backend)
    for active in [[1], [], [0, 1, 2, 3], [2, 0]]:
        factor.update(active)
        assert_allclose(factor.solve(np.ones(4)),
                        np.linalg.solve(dense_face(H.toarray(), np.array(active, int)), np.ones(4)), atol=1e-12)
    calls = factor.stats['updates'] + factor.stats['downdates']
    factor.update([0, 2])
    assert factor.stats['updates'] + factor.stats['downdates'] == calls
    assert factor.stats['numeric_factorizations'] == 1
    assert factor.stats['active_reuses'] >= 1


@pytest.mark.parametrize('backend', ['rank2', 'rowmod'])
def test_payload_is_explicit_about_native_factor_storage(backend):
    H = sparse.diags([[-1.] * 8, [4.] * 9, [-1.] * 8], [-1, 0, 1], format='csc')
    factor = implementation()(H, backend=backend)
    factor.update([2, 5])
    payload = factor.memory_payload()
    assert payload['inverse_column_bytes'] == 0
    assert payload['factor_numeric_bytes'] > 0
    assert payload['model_bytes'] == H.data.nbytes + H.indices.nbytes + H.indptr.nbytes
    assert 'native' in payload['scope'].lower()
    if backend == 'rowmod':
        assert payload['native_peak_bytes'] >= payload['native_tracked_bytes']
        assert payload['native_tracked_bytes'] >= payload['factor_numeric_bytes']


@pytest.mark.parametrize('backend', ['rank2', 'rowmod'])
def test_sparse_pattern_survives_long_local_contact_releases(backend):
    n = 25
    H = sparse.diags([-np.ones(n-1), 3*np.ones(n), -np.ones(n-1)], [-1, 0, 1], format='csc')
    dense = H.toarray()
    rng = np.random.default_rng(174)
    factor = implementation()(H, backend=backend)
    for _ in range(100):
        active = np.flatnonzero(rng.random(n) < .3)
        factor.update(active)
        rhs = rng.normal(size=n)
        answer = factor.solve(rhs)
        assert_allclose(answer, np.linalg.solve(dense_face(dense, active), rhs), atol=2e-10, rtol=2e-10)
    factor.update([])
    assert_allclose(factor.solve(np.ones(n)), np.linalg.solve(dense, np.ones(n)), atol=2e-10)
