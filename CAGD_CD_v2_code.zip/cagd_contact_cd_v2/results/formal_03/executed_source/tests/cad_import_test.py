"""Offline checks of the actual imported STEP-derived meshes and provenance."""
import importlib.util
import json
from pathlib import Path
import unittest

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("cad_import", ROOT / "cad_import.py")
cad = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cad)


class ImportedCadTests(unittest.TestCase):
    def test_all_source_and_mesh_hashes_and_topology(self):
        summary = cad.verify_assets()
        for model, levels in summary.items():
            self.assertGreaterEqual(levels["coarse"]["nodes"], 500, model)
            self.assertLessEqual(levels["coarse"]["nodes"], 1200, model)
            self.assertGreaterEqual(levels["medium"]["nodes"], 1500, model)
            self.assertGreaterEqual(levels["fine"]["nodes"], 3000, model)
            self.assertLessEqual(levels["fine"]["nodes"], 6500, model)

    def test_plate_holes_are_preserved(self):
        with np.load(cad.ASSETS / "nist_ctc_01/selected_face_fine.npz") as a:
            q = cad.mesh_quality(a["X"], a["faces"], a["normals"])
            self.assertEqual(q["boundary_components"], 12)
            self.assertLess(np.ptp(a["X"][:, 2]), 1e-10)
            self.assertLess(np.max(np.ptp(a["normals"], axis=0)), 1e-10)

    def test_authored_bspline_is_curved_and_not_a_generated_plane(self):
        meta = json.loads((cad.ASSETS / "nist_ctc_02/metadata.json").read_text())
        self.assertEqual(meta["selected_faces"][0]["type"], "BSpline surface")
        self.assertEqual(meta["selected_faces"][0]["step_advanced_face_entity"], 11742)
        self.assertIn("B_SPLINE_SURFACE(3,3", meta["selected_faces"][0]["step_surface_definition_prefix"])
        with np.load(cad.ASSETS / "nist_ctc_02/selected_face_fine.npz") as a:
            self.assertGreater(np.linalg.norm(np.ptp(a["normals"], axis=0)), 0.4)

    def test_bend_charts_share_vertices_and_keep_mm_scale(self):
        meta = json.loads((cad.ASSETS / "nist_ctc_03/metadata.json").read_text())
        self.assertEqual(meta["source_units"], "inch")
        self.assertEqual(meta["source_unit_to_mm"], 25.4)
        self.assertEqual(meta["selected_gmsh_face_ids"], [8, 39, 15])
        with np.load(cad.ASSETS / "nist_ctc_03/selected_face_fine.npz") as a:
            charts = a["node_face_uv"]
            nodes, counts = np.unique(charts[:, 0], return_counts=True)
            seam_nodes = nodes[counts > 1].astype(int)
            self.assertGreater(len(seam_nodes), 20)
            self.assertEqual(cad.mesh_quality(a["X"], a["faces"])["connected_components"], 1)
            self.assertAlmostEqual(a["X"][:, 0].min(), -241.3, places=4)
            self.assertAlmostEqual(a["X"][:, 0].max(), 6.35, places=4)
            self.assertTrue(np.isfinite(a["normals"][seam_nodes]).all())

    def test_degenerate_triangle_is_rejected(self):
        with self.assertRaises(ValueError):
            cad.mesh_quality(np.array([[0., 0., 0.], [1., 0., 0.], [2., 0., 0.]]),
                             np.array([[0, 1, 2]]))


if __name__ == "__main__":
    unittest.main()
