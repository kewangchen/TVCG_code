"""Standard CHOLMOD rank updates for fixed-size contact face matrices.

The matrix is K_A=P_F H P_F+I_A. One contact toggle is a symmetric rank-two
change, represented by sparse positive and negative spectral columns. A single
base factorization fixes the ordering; all positive columns are applied before
all negative columns. This uses SuiteSparse's actual update/downdate algorithm.
"""
from time import perf_counter
import ctypes
import os
from pathlib import Path
import subprocess

import numpy as np
from scipy import sparse


def _bytes(matrix):
    return int(matrix.data.nbytes + matrix.indices.nbytes + matrix.indptr.nbytes)


def _columns(columns, n):
    if not columns:
        return sparse.csc_matrix((n, 0))
    indptr = np.r_[0, np.cumsum([len(row) for row, value in columns])].astype(np.int32)
    rows = np.concatenate([row for row, value in columns]).astype(np.int32)
    values = np.concatenate([value for row, value in columns])
    matrix = sparse.csc_matrix((values, rows, indptr), shape=(n, len(columns)))
    matrix.sort_indices()
    return matrix


class UpdateFactor:
    """One CHOLMOD factor with causal sparse bound activation and release.

    `solve(rhs)` solves K_A x=rhs. To recover the constrained primal minimizer,
    callers supply rhs_F=q_F-H_FA b_A and rhs_A=b_A. There is no penalty parameter.
    The permutation stays fixed, but intermediate updates may add native fill.
    """
    def __init__(self, H, initial_active=None, backend='rank2'):
        self.H = sparse.csc_matrix(H, dtype=float, copy=True)
        self.H.sum_duplicates()
        self.H.sort_indices()
        self.n = self.H.shape[0]
        if self.H.shape != (self.n, self.n):
            raise ValueError('H must be square')
        difference = self.H - self.H.T
        if difference.nnz and np.max(abs(difference.data)) > 1e-12 * max(1., np.max(abs(self.H.data))):
            raise ValueError('H must be symmetric')
        self.diagonal = self.H.diagonal()
        self.mask = np.zeros(self.n, dtype=bool)
        self.active = np.empty(0, dtype=int)
        self.backend = backend
        started = perf_counter()
        if backend == 'rank2':
            from sksparse.cholmod import cholesky
            self.factor = cholesky(self.H, mode='simplicial', ordering_method='amd')
        elif backend == 'rowmod':
            self.factor = _RowModificationFactor(self.H)
        else:
            raise ValueError('backend must be rank2 or rowmod')
        self.permutation = self.factor.P()
        self.stats = dict(symbolic_factorizations=1, numeric_factorizations=1,
                          factor_seconds=perf_counter()-started, updates=0, downdates=0,
                          updated_columns=0, downdated_columns=0, toggles=0,
                          active_reuses=0, update_seconds=0., plan_seconds=0.,
                          solves=0, solve_seconds=0., max_update_payload_bytes=0)
        if initial_active is not None:
            self.update(initial_active)

    def update(self, active):
        active = np.asarray(active, dtype=int).reshape(-1)
        if np.any(active < 0) or np.any(active >= self.n):
            raise ValueError('Active index is outside H')
        target = np.zeros(self.n, dtype=bool)
        target[active] = True
        if np.array_equal(target, self.mask):
            self.stats['active_reuses'] += 1
            return self
        started = perf_counter()
        if self.backend == 'rowmod':
            plan_mask = self.mask.copy()
            releasing = np.flatnonzero(self.mask & ~target)
            activating = np.flatnonzero(~self.mask & target)
            for i in releasing:
                begin, end = self.H.indptr[i:i+2]
                rows = self.H.indices[begin:end]
                values = self.H.data[begin:end]
                keep = (~plan_mask[rows]) | (rows == i)
                self.factor.rowadd(int(i), rows[keep], values[keep])
                plan_mask[i] = False
            for i in activating:
                self.factor.rowdel(int(i))
                plan_mask[i] = True
            self.stats['updates'] += len(releasing)
            self.stats['downdates'] += len(activating)
            self.stats['updated_columns'] += len(releasing)
            self.stats['downdated_columns'] += len(activating)
            self.stats['toggles'] += len(releasing)+len(activating)
            self.stats['update_seconds'] += perf_counter()-started
            self.mask = target
            self.active = np.flatnonzero(target)
            return self
        plan_mask = self.mask.copy()
        positive, negative = [], []
        # Every planned intermediate face is SPD. Batching the positive parts
        # first makes each later downdate bounded below by the final SPD face.
        releasing = np.flatnonzero(self.mask & ~target)
        activating = np.flatnonzero(~self.mask & target)
        for i, sign in [(int(i), 1.) for i in releasing] + [(int(i), -1.) for i in activating]:
            begin, end = self.H.indptr[i:i+2]
            rows = self.H.indices[begin:end]
            data = self.H.data[begin:end]
            keep = (~plan_mask[rows]) & (rows != i) & (data != 0)
            neighbors, w = rows[keep], data[keep]
            magnitude = float(np.linalg.norm(w))
            if magnitude:
                eigenvalues, vectors = np.linalg.eigh(np.array([
                    [sign * (self.diagonal[i]-1.), sign * magnitude],
                    [sign * magnitude, 0.]]))
                support = np.r_[i, neighbors]
                for j, value in enumerate(eigenvalues):
                    if value == 0:
                        continue
                    values = np.r_[vectors[0, j], vectors[1, j] * w / magnitude] * np.sqrt(abs(value))
                    (positive if value > 0 else negative).append((support, values))
            else:
                value = sign * (self.diagonal[i]-1.)
                if value:
                    (positive if value > 0 else negative).append((np.array([i]), np.array([np.sqrt(abs(value))])))
            plan_mask[i] = sign < 0
        plus, minus = _columns(positive, self.n), _columns(negative, self.n)
        self.stats['plan_seconds'] += perf_counter()-started
        self.stats['max_update_payload_bytes'] = max(
            self.stats['max_update_payload_bytes'], _bytes(plus)+_bytes(minus))
        started = perf_counter()
        if plus.shape[1]:
            self.factor.update_inplace(plus)
            self.stats['updates'] += 1
            self.stats['updated_columns'] += plus.shape[1]
        if minus.shape[1]:
            self.factor.update_inplace(minus, subtract=True)
            self.stats['downdates'] += 1
            self.stats['downdated_columns'] += minus.shape[1]
        self.stats['update_seconds'] += perf_counter()-started
        self.stats['toggles'] += len(releasing)+len(activating)
        self.mask = target
        self.active = np.flatnonzero(target)
        return self

    def solve(self, rhs):
        rhs = np.asarray(rhs, dtype=float)
        if rhs.ndim not in (1, 2) or rhs.shape[0] != self.n:
            raise ValueError('Right-hand side dimensions do not match H')
        started = perf_counter()
        result = self.factor.solve_A(rhs)
        self.stats['solves'] += 1
        self.stats['solve_seconds'] += perf_counter()-started
        return result

    def memory_payload(self):
        if self.backend == 'rowmod':
            payload = self.factor.payload()
            model_bytes = _bytes(self.H)
            vectors = sum(array.nbytes for array in [self.diagonal, self.mask, self.active, self.permutation])
            return dict(payload, inverse_column_bytes=0, model_bytes=model_bytes,
                        retained_numeric_payload_bytes=int(model_bytes+payload['native_tracked_bytes']+vectors),
                        scope='Native CHOLMOD Common tracked allocations plus opaque handle/inverse permutation and owned Python numerical arrays; excludes BLAS/Python/allocator overhead. Native peak is reported separately from Python arrays. Not RSS.')
        # LD extraction returns a sparse numeric copy. It exposes used entries,
        # not CHOLMOD capacity/workspace, so this is deliberately not called RSS.
        LD = self.factor.LD()
        factor_bytes = _bytes(LD) + self.permutation.nbytes
        model_bytes = _bytes(self.H)
        vectors = sum(array.nbytes for array in [self.diagonal, self.mask, self.active])
        return dict(inverse_column_bytes=0, model_bytes=model_bytes,
                    factor_numeric_bytes=int(factor_bytes), factor_nnz=int(LD.nnz),
                    retained_numeric_payload_bytes=int(model_bytes+factor_bytes+vectors),
                    max_update_payload_bytes=int(self.stats['max_update_payload_bytes']),
                    scope='Exposed used LDL/permutation and owned model/vector payload; excludes native CHOLMOD capacity/workspaces, extraction copy, Python objects and allocator overhead. Not RSS.')


_NATIVE_SOURCE = r'''
#include <stdlib.h>
#include <string.h>
#include <cholmod.h>
typedef struct {cholmod_common common; cholmod_factor *L; int n; int *inverse;} Handle;
void cagd_free(void *pointer) {
    Handle *h=(Handle*)pointer; if(!h)return;
    if(h->L)cholmod_free_factor(&h->L,&h->common);
    free(h->inverse); cholmod_finish(&h->common); free(h);
}
void *cagd_create(int n,int nnz,const int *p,const int *i,const double *x) {
    Handle *h=(Handle*)calloc(1,sizeof(Handle)); if(!h)return NULL;
    cholmod_start(&h->common); h->n=n; h->common.supernodal=CHOLMOD_SIMPLICIAL;
    h->common.final_ll=0; h->common.nmethods=1; h->common.method[0].ordering=CHOLMOD_AMD;
    cholmod_sparse *A=cholmod_allocate_sparse(n,n,nnz,1,1,-1,CHOLMOD_REAL,&h->common);
    if(!A){cagd_free(h);return NULL;}
    memcpy(A->p,p,(n+1)*sizeof(int)); memcpy(A->i,i,nnz*sizeof(int)); memcpy(A->x,x,nnz*sizeof(double));
    h->L=cholmod_analyze(A,&h->common);
    int ok=h->L && cholmod_factorize(A,h->L,&h->common) && h->L->minor==(size_t)n;
    cholmod_free_sparse(&A,&h->common);
    if(!ok){cagd_free(h);return NULL;}
    h->inverse=(int*)malloc(n*sizeof(int)); if(!h->inverse){cagd_free(h);return NULL;}
    int *perm=(int*)h->L->Perm; for(int k=0;k<n;k++)h->inverse[perm[k]]=k;
    return h;
}
int cagd_perm(void *pointer,int *out) {
    Handle *h=(Handle*)pointer; memcpy(out,h->L->Perm,h->n*sizeof(int)); return 1;
}
int cagd_delete(void *pointer,int original) {
    Handle *h=(Handle*)pointer;
    return cholmod_rowdel(h->inverse[original],NULL,h->L,&h->common);
}
int cagd_add(void *pointer,int original,int count,const int *rows,const double *values) {
    Handle *h=(Handle*)pointer;
    cholmod_sparse *R=cholmod_allocate_sparse(h->n,1,count,0,1,0,CHOLMOD_REAL,&h->common);
    if(!R)return 0; ((int*)R->p)[0]=0; ((int*)R->p)[1]=count;
    for(int j=0;j<count;j++){((int*)R->i)[j]=h->inverse[rows[j]];((double*)R->x)[j]=values[j];}
    int ok=cholmod_rowadd(h->inverse[original],R,h->L,&h->common);
    cholmod_free_sparse(&R,&h->common); return ok;
}
int cagd_solve(void *pointer,int nrhs,const double *rhs,double *out) {
    Handle *h=(Handle*)pointer;
    cholmod_dense *B=cholmod_allocate_dense(h->n,nrhs,h->n,CHOLMOD_REAL,&h->common);
    if(!B)return 0; memcpy(B->x,rhs,h->n*nrhs*sizeof(double));
    cholmod_dense *X=cholmod_solve(CHOLMOD_A,h->L,B,&h->common);
    int ok=X!=NULL; if(ok)memcpy(out,X->x,h->n*nrhs*sizeof(double));
    cholmod_free_dense(&B,&h->common); if(X)cholmod_free_dense(&X,&h->common); return ok;
}
int cagd_payload(void *pointer,long long *out) {
    Handle *h=(Handle*)pointer; long long used=0; int *nz=(int*)h->L->nz;
    for(int j=0;j<h->n;j++)used+=nz[j];
    out[0]=h->common.memory_inuse+sizeof(Handle)+h->n*sizeof(int);
    out[1]=h->common.memory_usage+sizeof(Handle)+h->n*sizeof(int);
    out[2]=used; out[3]=h->L->nzmax; return 1;
}
'''


def build_rowmod_library(include_dir, library_dir, output, compiler='cc'):
    """Compile the bundled opaque-handle C source against real CHOLMOD headers.

    This explicit installer is never run during solver construction. Generated
    C/binaries belong in the external dependency prefix, not the study package.
    """
    output = Path(output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    source = output.with_suffix('.c')
    source.write_text(_NATIVE_SOURCE)
    subprocess.run([compiler, '-O3', '-std=c99', '-dynamiclib', str(source),
                    '-I'+str(include_dir), '-L'+str(library_dir), '-lcholmod',
                    '-Wl,-rpath,'+str(library_dir), '-o', str(output)], check=True)
    return output


class _RowModificationFactor:
    """ctypes transports opaque pointers only; C sees the verified structures."""
    def __init__(self, H):
        path = os.getenv('CAGD_CHOLMOD_ROWMOD_LIB', '/private/tmp/cagd_v2_chol_deps/libcagd_rowmod.dylib')
        self.library = ctypes.CDLL(path)
        pointer = ctypes.c_void_p
        integer = ctypes.c_int
        self.library.cagd_create.argtypes = [integer, integer, pointer, pointer, pointer]
        self.library.cagd_create.restype = pointer
        for name, args in [('cagd_free', [pointer]), ('cagd_perm', [pointer, pointer]),
                           ('cagd_delete', [pointer, integer]),
                           ('cagd_add', [pointer, integer, integer, pointer, pointer]),
                           ('cagd_solve', [pointer, integer, pointer, pointer]),
                           ('cagd_payload', [pointer, pointer])]:
            getattr(self.library, name).argtypes = args
            getattr(self.library, name).restype = None if name == 'cagd_free' else integer
        p = np.ascontiguousarray(H.indptr, dtype=np.int32)
        i = np.ascontiguousarray(H.indices, dtype=np.int32)
        x = np.ascontiguousarray(H.data, dtype=np.float64)
        self.n = H.shape[0]
        self.handle = self.library.cagd_create(self.n, H.nnz, p.ctypes.data, i.ctypes.data, x.ctypes.data)
        if not self.handle:
            raise ValueError('CHOLMOD could not factor the supplied SPD model')

    def __del__(self):
        handle = getattr(self, 'handle', None)
        if handle:
            self.library.cagd_free(handle)
            self.handle = None

    def P(self):
        permutation = np.empty(self.n, dtype=np.int32)
        self.library.cagd_perm(self.handle, permutation.ctypes.data)
        return permutation

    def rowdel(self, i):
        if not self.library.cagd_delete(self.handle, i):
            raise RuntimeError('CHOLMOD row deletion failed')

    def rowadd(self, i, rows, values):
        rows = np.ascontiguousarray(rows, dtype=np.int32)
        values = np.ascontiguousarray(values, dtype=np.float64)
        if not self.library.cagd_add(self.handle, i, len(rows), rows.ctypes.data, values.ctypes.data):
            raise RuntimeError('CHOLMOD row addition failed')

    def solve_A(self, rhs):
        rhs = np.asfortranarray(rhs)
        output = np.empty(rhs.shape, order='F')
        count = 1 if rhs.ndim == 1 else rhs.shape[1]
        if not self.library.cagd_solve(self.handle, count, rhs.ctypes.data, output.ctypes.data):
            raise RuntimeError('CHOLMOD solve failed')
        return output

    def payload(self):
        values = np.empty(4, dtype=np.int64)
        self.library.cagd_payload(self.handle, values.ctypes.data)
        n = self.n
        return dict(native_tracked_bytes=int(values[0]), native_peak_bytes=int(values[1]),
                    factor_nnz=int(values[2]), factor_capacity_nnz=int(values[3]),
                    factor_numeric_bytes=int(12*values[2]+4*(2*n+1)))
