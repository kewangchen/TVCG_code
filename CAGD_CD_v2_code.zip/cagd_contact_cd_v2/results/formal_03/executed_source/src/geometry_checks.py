"""Floating-point geometry diagnostics independent of the optimization solver.

The metric and edge/coplanar tests are retained from the previous study, with
explicit LP witnesses and an all-candidate endpoint audit added here. This
module imports no previous-study package or solver implementation.
"""
from time import perf_counter
import numpy as np
from scipy.optimize import linprog

def triangle_metrics(rest, current, faces):
    rest=np.asarray(rest,dtype=float); current=np.asarray(current,dtype=float)
    if rest.shape!=current.shape or not np.isfinite(current).all():
        raise ValueError('Coordinate arrays must match and be finite.')
    a=rest[faces]; b=current[faces]
    e=a[:,1]-a[:,0]; f=a[:,2]-a[:,0]
    length=np.linalg.norm(e,axis=1); along=np.sum(e*f,axis=1)/length
    height=np.linalg.norm(f-along[:,None]*e/length[:,None],axis=1)
    if np.any(height<=np.finfo(float).eps*length):
        raise ValueError('Degenerate rest triangle.')
    inv=np.zeros((len(faces),2,2))
    inv[:,0,0]=1/length; inv[:,0,1]=-along/(length*height); inv[:,1,1]=1/height
    edges=np.stack((b[:,1]-b[:,0],b[:,2]-b[:,0]),axis=2)
    jacobian=edges@inv
    sv=np.linalg.svd(jacobian,compute_uv=False)
    def angles(t):
        answer=[]
        for i in range(3):
            u=t[:,(i+1)%3]-t[:,i]; v=t[:,(i+2)%3]-t[:,i]
            norm=np.linalg.norm(u,axis=1)*np.linalg.norm(v,axis=1)
            cosine=np.divide(np.sum(u*v,axis=1),norm,out=np.full(len(t),np.nan),where=norm>0)
            answer.append(np.rad2deg(np.arccos(np.clip(cosine,-1,1))))
        return np.column_stack(answer)
    ratio=np.prod(sv,axis=1)
    with np.errstate(divide='ignore',invalid='ignore'):
        k=sv[:,0]/sv[:,1]; loga=np.log(ratio)
    ans=dict(rest_area=.5*length*height,singular_values=sv,area_ratio=ratio,
             conformal_ratio=k,log_area=loga,angle_change_deg=angles(b)-angles(a),
             isometry_density=.5*np.sum((sv-1)**2,axis=1))
    if rest.shape[1]==2:
        cross=lambda x,y:x[:,0]*y[:,1]-x[:,1]*y[:,0]
        ans['signed_area_ratio']=cross(b[:,1]-b[:,0],b[:,2]-b[:,0])/cross(e,f)
    return ans

def weighted_quantile(values,weights,q):
    order=np.argsort(values); v=np.asarray(values)[order]; w=np.asarray(weights)[order]
    return float(v[min(np.searchsorted(np.cumsum(w),q*w.sum()),len(v)-1)])

def summarize(m):
    w=m['rest_area']/m['rest_area'].sum(); sv=m['singular_values']
    mean=lambda x:float(w@x)
    return dict(area_ratio_min=float(m['area_ratio'].min()),area_ratio_max=float(m['area_ratio'].max()),
        log_area_rms=float(np.sqrt(mean(m['log_area']**2))),
        area_change_abs_mean=mean(abs(m['area_ratio']-1)),
        sigma_max=float(sv[:,0].max()),sigma_min=float(sv[:,1].min()),
        stretch_p95=weighted_quantile(sv[:,0],w,.95),
        conformal_mean=mean(m['conformal_ratio']),conformal_p95=weighted_quantile(m['conformal_ratio'],w,.95),
        conformal_max=float(m['conformal_ratio'].max()),
        angle_rms_deg=float(np.sqrt(mean(np.mean(m['angle_change_deg']**2,axis=1)))),
        angle_max_deg=float(abs(m['angle_change_deg']).max()),
        isometry_energy=mean(m['isometry_density']),
        planar_inverted_faces=int(np.sum(m.get('signed_area_ratio',np.ones(len(w)))<=0)))

def _cross2(a, b):
    return a[0]*b[1]-a[1]*b[0]

def _overlap_area(a, b, tol):
    if _cross2(b[1]-b[0], b[2]-b[0]) < 0:
        b = b[::-1]
    polygon = list(a)
    for start, end in zip(b, np.roll(b, -1, axis=0)):
        if not polygon:
            return 0.
        new = []
        previous = polygon[-1]
        dp = _cross2(end-start, previous-start)
        for current in polygon:
            dc = _cross2(end-start, current-start)
            if (dp >= -tol) != (dc >= -tol):
                denominator = dp-dc
                if abs(denominator) > np.finfo(float).tiny:
                    new.append(previous+(current-previous)*(dp/denominator))
            if dc >= -tol:
                new.append(current)
            previous, dp = current, dc
        polygon = new
    if len(polygon) < 3:
        return 0.
    p = np.array(polygon)
    return .5*abs(float(np.sum(p[:, 0]*np.roll(p[:, 1], -1)-p[:, 1]*np.roll(p[:, 0], -1))))

def _edge_face_crossings(a, b, tol):
    e1, e2 = b[:, 1]-b[:, 0], b[:, 2]-b[:, 0]
    result = np.zeros(len(a), dtype=bool)
    for i in range(3):
        origin, direction = a[:, i], a[:, (i+1) % 3]-a[:, i]
        cross = np.cross(direction, e2)
        determinant = np.einsum('ij,ij->i', e1, cross)
        scale = np.linalg.norm(e1, axis=1)*np.linalg.norm(e2, axis=1)*np.linalg.norm(direction, axis=1)
        valid = np.abs(determinant) > tol*scale
        inverse = np.zeros(len(a))
        np.divide(1., determinant, out=inverse, where=valid)
        offset = origin-b[:, 0]
        u = np.einsum('ij,ij->i', offset, cross)*inverse
        q = np.cross(offset, e1)
        v = np.einsum('ij,ij->i', direction, q)*inverse
        t = np.einsum('ij,ij->i', e2, q)*inverse
        result |= valid & (u > tol) & (v > tol) & (u+v < 1-tol) & (t > tol) & (t < 1-tol)
    return result

def triangle_intersections(a, b, tol=1e-10):
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    assert a.shape == b.shape and a.ndim == 3 and a.shape[1] == 3
    if a.shape[2] == 2:
        return np.array([_overlap_area(x, y, tol) > tol*max(1., np.ptp(np.vstack([x, y]), axis=0).max())**2 for x, y in zip(a, b)])
    assert a.shape[2] == 3
    out = _edge_face_crossings(a, b, tol) | _edge_face_crossings(b, a, tol)
    n = np.cross(a[:, 1]-a[:, 0], a[:, 2]-a[:, 0])
    length = np.linalg.norm(n, axis=1)
    n = n/np.maximum(length[:, None], np.finfo(float).tiny)
    scale = np.maximum(1., np.max(np.ptp(np.concatenate([a, b], axis=1), axis=1), axis=1))
    distance = np.abs(np.einsum('ijk,ik->ij', b-a[:, :1], n))
    coplanar = (length > np.finfo(float).tiny) & np.all(distance <= tol*scale[:, None], axis=1)
    for i in np.flatnonzero(coplanar):
        keep = np.delete(np.arange(3), int(np.argmax(np.abs(n[i]))))
        out[i] = _overlap_area(a[i][:, keep], b[i][:, keep], tol*scale[i]**2) > tol*scale[i]**2
    return out

def self_intersections(vertices, faces, tol=1e-10):
    tri = np.asarray(vertices)[faces]
    low, high = tri.min(axis=1), tri.max(axis=1)
    tolerance = tol*max(1., np.ptp(vertices, axis=0).max())
    pairs = []
    for i in range(len(faces)-1):
        candidates = np.flatnonzero(np.all(high[i] >= low[i+1:]-tolerance, axis=1) & np.all(high[i+1:] >= low[i]-tolerance, axis=1))+i+1
        if len(candidates):
            shared = np.any(faces[i][None, :, None] == faces[candidates][:, None, :], axis=(1, 2))
            candidates = candidates[~shared]
        if len(candidates):
            hits = triangle_intersections(np.broadcast_to(tri[i], (len(candidates),)+tri[i].shape), tri[candidates], tol)
            pairs.extend([[i, int(j)] for j in candidates[hits]])
    return pairs


def aabb_candidates(vertices, faces, padding=0., exclude_shared=False):
    """Yield all unordered triangle pairs whose padded axis boxes overlap.

Excluding a shared vertex is appropriate only for closed-distance contacts;
the LP interior-overlap audit deliberately includes neighboring triangles.
"""
    vertices, faces = np.asarray(vertices), np.asarray(faces, dtype=int)
    tri = vertices[faces]; low, high = tri.min(1), tri.max(1)
    for i in range(len(faces)-1):
        ids = np.flatnonzero(np.all(high[i] + padding >= low[i+1:], axis=1)
                             & np.all(high[i+1:] + padding >= low[i], axis=1)) + i+1
        if exclude_shared and len(ids):
            shared = np.any(faces[i][None, :, None] == faces[ids][:, None, :], axis=(1, 2))
            ids = ids[~shared]
        for j in ids:
            yield i, int(j)


def triangle_overlap_lp(a, b, threshold=1e-7):
    """Maximize the minimum of six barycentric coordinates at an intersection.

Positive margin witnesses a common point in both relative triangle interiors.
Zero margin does not exclude edge or vertex contact. All calculations and
HiGHS feasibility tolerances are ordinary floating point, not exact predicates.
"""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if a.shape != (3, 3) or b.shape != (3, 3) or not np.isfinite(np.r_[a, b]).all():
        raise ValueError('LP audit expects two finite 3D triangles.')
    all_points = np.vstack((a, b)); center = all_points.mean(0)
    scale = max(float(np.ptp(all_points, axis=0).max()), 1e-12)
    an, bn = (a-center)/scale, (b-center)/scale
    eq = np.zeros((5, 7)); eq[:3, :3] = an.T; eq[:3, 3:6] = -bn.T
    eq[3, :3] = 1; eq[4, 3:6] = 1
    iq = np.zeros((6, 7)); iq[:, :6] = -np.eye(6); iq[:, -1] = 1
    obj = np.zeros(7); obj[-1] = -1
    result = linprog(obj, A_ub=iq, b_ub=np.zeros(6), A_eq=eq,
                     b_eq=[0, 0, 0, 1, 1], bounds=[(0, 1)]*6 + [(0, 1/3)],
                     method='highs', options={'primal_feasibility_tolerance': 1e-9,
                                               'dual_feasibility_tolerance': 1e-9})
    if result.status == 2:
        return dict(feasible=False, strict_overlap=False, margin=0., threshold=threshold,
                    barycentric_a=None, barycentric_b=None, intersection_point=None,
                    witness_residual=None)
    if not result.success:
        raise RuntimeError('Triangle-overlap LP did not complete: ' + result.message)
    weights_a, weights_b = result.x[:3], result.x[3:6]
    margin = max(0., float(min(result.x[-1], weights_a.min(), weights_b.min())))
    residual = float(np.linalg.norm(weights_a@a-weights_b@b))
    if residual > 1e-7*scale:
        raise RuntimeError('Triangle-overlap LP has an inaccurate equality witness.')
    return dict(feasible=True, strict_overlap=bool(margin > threshold), margin=margin,
                threshold=threshold, barycentric_a=weights_a.tolist(),
                barycentric_b=weights_b.tolist(),
                intersection_point=(.5*(weights_a@a+weights_b@b)).tolist(),
                witness_residual=residual)


def lp_mesh(vertices, faces, threshold=1e-7):
    """Audit every endpoint AABB candidate, including adjacent-face interiors."""
    start = perf_counter(); tri = np.asarray(vertices)[faces]
    count, maximum, hits = 0, 0., []
    for i, j in aabb_candidates(vertices, faces):
        witness = triangle_overlap_lp(tri[i], tri[j], threshold)
        count += 1; maximum = max(maximum, witness['margin'])
        if witness['strict_overlap']:
            hits.append(dict(faces=[i, j], **witness))
    return dict(tested_pairs=count, strict_overlaps=hits, maximum_margin=maximum,
                threshold=threshold, seconds=perf_counter()-start,
                includes_adjacent_triangle_interiors=True,
                scope='All AABB candidates, floating-point barycentric LP; closed edge/vertex contact requires a separate distance check.')


def initial_matching_lp(case, vertices, faces, target_u, threshold=1e-7):
    """Find explicit input crossing witnesses between corresponding faces.

The sign-changing scalar-gap filter only selects candidates. The actual LP on
the 3D triangles establishes each reported intersection. This is a detected
subset of input crossings, not an exhaustive input-intersection count.
"""
    full = np.zeros(len(case['X'])); full[case['free']] = target_u
    gap = case['gap0']+full; fgap = gap[case['faces']]
    candidates = np.flatnonzero((fgap.min(1) < 0) & (fgap.max(1) > 0))
    tri = np.asarray(vertices)[faces]; nf = len(case['faces']); hits = []
    for i in candidates:
        witness = triangle_overlap_lp(tri[i], tri[i+nf], threshold)
        if witness['strict_overlap']:
            hits.append(dict(faces=[int(i), int(i+nf)], **witness))
    return dict(tested_pairs=len(candidates), strict_overlaps=hits, threshold=threshold,
                scope='Sign-changing corresponding-face candidates followed by actual 3D LP witnesses; not an exhaustive count of all input intersections.')

