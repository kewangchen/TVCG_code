"""Strong, standard cached-Schur organizations for the frozen contact QP.

Both subclasses inherit the original active-set iterations, objective, stopping
test and fallback.  The condensed variant retains only a principal submatrix of
the inverse.  It never retains n-by-contact inverse columns; sparse solves
recover the primal displacement.  These are baseline engineering choices, not
new contact or parametric-QP algorithms.

Payload reports count NumPy/SciPy numerical arrays, not allocator capacity, Python
objects, temporary BLAS workspaces or hidden SuperLU work storage.  The sparse
LU count is the exposed L/U/permutation data payload.  It is not process RSS.
"""
from time import perf_counter

import numpy as np
from scipy.linalg import cho_factor, cho_solve

from .frozen_baseline import ContactSolver


def _sparse_bytes(matrix):
    return int(matrix.data.nbytes + matrix.indices.nbytes + matrix.indptr.nbytes)


class _PayloadMixin:
    def _init_payload(self):
        # Count the actual exposed numeric representation once. Accessing L/U
        # may itself materialize SciPy views/copies; do not do that per query.
        self._global_factor_bytes = (
            _sparse_bytes(self.factor.L) + _sparse_bytes(self.factor.U)
            + self.factor.perm_r.nbytes + self.factor.perm_c.nbytes)
        self.stats.update(reconstruction_solves=0, max_rhs_columns=0,
                          peak_owned_array_bytes=0, cache_build_seconds=0.,
                          active_factor_seconds=0., reconstruction_seconds=0.)

    def _base_bytes(self):
        return (_sparse_bytes(self.H) + self._global_factor_bytes
                + sum(a.nbytes for a in (self.b, self.indices, self.mask,
                                          self.scale, self.active)))

    def _cache_parts(self):
        raise NotImplementedError

    def _owned_bytes(self):
        return self._base_bytes() + sum(self._cache_parts().values()) + self._lookup_bytes()

    def _lookup_bytes(self):
        return 0

    def _observe_peak(self, extra=0):
        self.stats['peak_owned_array_bytes'] = max(
            self.stats['peak_owned_array_bytes'], int(self._owned_bytes() + extra))

    def memory_payload(self):
        parts = self._cache_parts()
        retained = self._owned_bytes()
        self._observe_peak()
        return dict(parts, cache_bytes=int(sum(parts.values())),
                    lookup_bytes=self._lookup_bytes(), model_bytes=_sparse_bytes(self.H),
                    global_factor_bytes=int(self._global_factor_bytes),
                    retained_owned_array_bytes=int(retained),
                    peak_owned_array_bytes=int(self.stats['peak_owned_array_bytes']),
                    factor_scope='Exposed sparse LU L/U/permutation payload; hidden SuperLU storage excluded.',
                    peak_scope='Allocation-site owned numerical-array estimate; excludes Python/allocator/BLAS/SuperLU overhead.')


class CondensedSchurSolver(_PayloadMixin, ContactSolver):
    """Cache G[C,C] for encountered contacts, with bounded inverse batches.

    C grows using only current/past branch requests. Each newly encountered
    contact uses one inverse unit-column solve. All old-new entries come from
    symmetry; the old block is retained. Repeated ordered A reuses its Cholesky.
    """
    def __init__(self, H, b, indices=None, batch_size=8):
        if int(batch_size) != batch_size or batch_size <= 0:
            raise ValueError('batch_size must be a positive integer')
        super().__init__(H, b, kind='schur', indices=indices)
        self.batch_size = int(batch_size)
        self.contact_indices = np.empty(0, dtype=int)
        self.lookup = np.full(self.n, -1, dtype=int)
        self.gram = np.empty((0, 0))
        self._init_payload()
        self._observe_peak()

    def _lookup_bytes(self):
        return int(self.lookup.nbytes)

    def _cache_parts(self):
        return dict(gram_bytes=int(self.gram.nbytes),
                    contact_index_bytes=int(self.contact_indices.nbytes),
                    active_factor_bytes=0 if self.cache is None else int(self.cache[0].nbytes))

    def inverse_columns(self, A):
        """Compatibility helper: materialize requested columns only for caller.

        The ordinary branch path never calls this method. Explicit external
        requests cannot silently turn the condensed cache into the full-column
        cache inherited from the frozen implementation.
        """
        A = np.asarray(A, dtype=int)
        W = np.empty((self.n, len(A)), order='F')
        for begin in range(0, len(A), self.batch_size):
            active = A[begin:begin + self.batch_size]
            rhs = np.zeros((self.n, len(active)), order='F')
            rhs[active, np.arange(len(active))] = 1.
            sol = self.factor.solve(rhs)
            W[:, begin:begin + len(active)] = sol
            self.stats['column_solves'] += len(active)
            self.stats['max_rhs_columns'] = max(self.stats['max_rhs_columns'], len(active))
            self._observe_peak(W.nbytes + rhs.nbytes + sol.nbytes)
            del rhs, sol
        return W

    def _extend_contacts(self, A):
        missing = A[self.lookup[A] < 0]
        if not len(missing):
            return
        start = perf_counter()
        old_count = len(self.contact_indices)
        C = np.r_[self.contact_indices, missing]
        G = np.empty((len(C), len(C)))
        G[:old_count, :old_count] = self.gram
        # G and C coexist with the retained old arrays until construction ends.
        base_extra = G.nbytes + C.nbytes + missing.nbytes
        self._observe_peak(base_extra)
        for begin in range(0, len(missing), self.batch_size):
            new = missing[begin:begin + self.batch_size]
            rhs = np.zeros((self.n, len(new)), order='F')
            rhs[new, np.arange(len(new))] = 1.
            sol = self.factor.solve(rhs)
            sampled = sol[C]
            G[:, old_count + begin:old_count + begin + len(new)] = sampled
            self.stats['column_solves'] += len(new)
            self.stats['max_rhs_columns'] = max(self.stats['max_rhs_columns'], len(new))
            self._observe_peak(base_extra + rhs.nbytes + sol.nbytes + sampled.nbytes)
            del rhs, sol, sampled
        G[old_count:, :old_count] = G[:old_count, old_count:].T
        # Average only the new-new block; roundoff asymmetry is not accumulated
        # by re-averaging the previously cached entries.
        D = G[old_count:, old_count:]
        self._observe_peak(base_extra + 2 * D.nbytes)
        D[:] = (D + D.T) * .5
        self.contact_indices = C
        self.lookup[missing] = np.arange(old_count, len(C))
        self.gram = G
        self.stats['cache_build_seconds'] += perf_counter() - start
        self._observe_peak()

    def branch(self, y, A, target=None):
        y = np.asarray(y, dtype=float)
        A = np.asarray(A, dtype=int)
        if not len(A):
            return y.copy(), np.zeros(self.n)
        self._extend_contacts(A)
        key = tuple(A)
        if key != self.key:
            start = perf_counter()
            position = self.lookup[A]
            S = self.gram[np.ix_(position, position)]
            # overwrite_a plus Fortran layout avoids a gratuitous LAPACK copy.
            S = np.asfortranarray(S)
            self._observe_peak(2 * S.nbytes + position.nbytes)
            factor = cho_factor(S, lower=True, overwrite_a=True, check_finite=False)
            self.cache = factor
            self.key = key
            self.stats['active_factorizations'] += 1
            self.stats['active_factor_seconds'] += perf_counter() - start
        else:
            self.stats['active_reuses'] += 1
        values = self.b[A] if target is None else np.asarray(target)[A]
        la = cho_solve(self.cache, values - y[A], check_finite=False)
        lam = np.zeros(self.n)
        lam[A] = la
        start = perf_counter()
        displacement = self.factor.solve(lam)
        u = y + displacement
        self.stats['reconstruction_solves'] += 1
        self.stats['reconstruction_seconds'] += perf_counter() - start
        self._observe_peak(lam.nbytes + displacement.nbytes + u.nbytes + la.nbytes + values.nbytes)
        u[A] = values
        return u, lam


class StreamlinedSchurSolver(_PayloadMixin, ContactSolver):
    """Full inverse-column cache retaining the assembled W for unchanged A.

    This avoids the frozen implementation's column_stack on every branch.  Its
    full-column storage can beat condensed reconstruction when n|A| is small.
    """
    def __init__(self, H, b, indices=None):
        super().__init__(H, b, kind='schur', indices=indices)
        self.W = np.empty((self.n, 0))
        self._init_payload()
        self._observe_peak()

    def _cache_parts(self):
        return dict(inverse_column_bytes=int(sum(v.nbytes for v in self.columns.values())),
                    active_column_bytes=int(self.W.nbytes),
                    active_factor_bytes=0 if self.cache is None else int(self.cache[0].nbytes))

    def inverse_columns(self, A):
        missing = [int(i) for i in A if int(i) not in self.columns]
        if missing:
            rhs = np.zeros((self.n, len(missing)), order='F')
            rhs[missing, np.arange(len(missing))] = 1.
            sol = self.factor.solve(rhs)
            self._observe_peak(rhs.nbytes + sol.nbytes)
            for j, i in enumerate(missing):
                self.columns[i] = sol[:, j].copy()
            self.stats['column_solves'] += len(missing)
            self.stats['max_rhs_columns'] = max(self.stats['max_rhs_columns'], len(missing))
            self._observe_peak(rhs.nbytes + sol.nbytes)
        W = np.column_stack([self.columns[int(i)] for i in A])
        self._observe_peak(W.nbytes)
        return W

    def branch(self, y, A, target=None):
        y = np.asarray(y, dtype=float)
        A = np.asarray(A, dtype=int)
        if not len(A):
            return y.copy(), np.zeros(self.n)
        key = tuple(A)
        if key != self.key:
            start = perf_counter()
            W = self.inverse_columns(A)
            self.stats['cache_build_seconds'] += perf_counter() - start
            start = perf_counter()
            S = W[A]
            S = np.asfortranarray((S + S.T) * .5)
            self._observe_peak(W.nbytes + 2 * S.nbytes)
            self.cache = cho_factor(S, lower=True, overwrite_a=True, check_finite=False)
            self.W = W
            self.key = key
            self.stats['active_factorizations'] += 1
            self.stats['active_factor_seconds'] += perf_counter() - start
        else:
            self.stats['active_reuses'] += 1
        values = self.b[A] if target is None else np.asarray(target)[A]
        la = cho_solve(self.cache, values - y[A], check_finite=False)
        start = perf_counter()
        u = y + self.W @ la
        self.stats['reconstruction_seconds'] += perf_counter() - start
        lam = np.zeros(self.n)
        lam[A] = la
        u[A] = values
        self._observe_peak(u.nbytes + lam.nbytes + la.nbytes + values.nbytes)
        return u, lam
