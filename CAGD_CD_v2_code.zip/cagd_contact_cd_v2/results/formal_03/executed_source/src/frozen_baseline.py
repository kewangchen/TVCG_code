"""Bound contact QPs with independently checked KKT conditions.

Cached Schur complements and reduced-space PDAS use the same active-set rule.
Their differences concern factor construction, not the optimization objective.
"""
from time import perf_counter
import numpy as np
from scipy import sparse
from scipy.linalg import cho_factor,cho_solve
from scipy.sparse.linalg import splu
from scipy.optimize import minimize

class ContactSolver:
    def __init__(self,H,b,kind='schur',indices=None):
        self.H=sparse.csc_matrix(H,copy=True);self.b=np.asarray(b,float).copy()
        self.n=len(b);self.kind=kind
        self.indices=np.arange(self.n) if indices is None else np.asarray(indices,int)
        self.mask=np.zeros(self.n,bool);self.mask[self.indices]=True
        self.scale=np.maximum(self.H.diagonal(),1e-12)
        self.factor=splu(self.H) if kind=='schur' else None
        self.columns={};self.key=None;self.cache=None;self.active=np.array([],int)
        self.stats=dict(global_factorizations=int(kind=='schur'),column_solves=0,
            active_factorizations=0,active_reuses=0,fallbacks=0,qp_solves=0)

    def inverse_columns(self,A):
        missing=[int(i) for i in A if int(i) not in self.columns]
        if missing:
            if self.factor is None:
                self.factor=splu(self.H);self.stats['global_factorizations']+=1
            rhs=np.zeros((self.n,len(missing)));rhs[missing,np.arange(len(missing))]=1
            sol=self.factor.solve(rhs)
            for j,i in enumerate(missing):self.columns[i]=sol[:,j].copy()
            self.stats['column_solves']+=len(missing)
        return np.column_stack([self.columns[int(i)] for i in A]) if len(A) else np.zeros((self.n,0))

    def branch(self,y,A,target=None):
        A=np.asarray(A,int);key=tuple(A);b=self.b[A] if target is None else np.asarray(target)[A]
        if not len(A):return np.array(y,copy=True),np.zeros(self.n)
        if self.kind=='schur':
            W=self.inverse_columns(A)
            if key!=self.key:
                S=W[A];S=(S+S.T)/2
                self.cache=cho_factor(S,lower=True,check_finite=False)
                self.stats['active_factorizations']+=1;self.key=key
            else:self.stats['active_reuses']+=1
            la=cho_solve(self.cache,b-y[A],check_finite=False)
            u=y+W@la
        else:
            free=np.setdiff1d(np.arange(self.n),A,assume_unique=True)
            if key!=self.key:
                self.cache=(free,splu(self.H[free][:,free].tocsc()) if len(free) else None)
                self.stats['active_factorizations']+=1;self.key=key
            else:self.stats['active_reuses']+=1
            free,factor=self.cache;u=np.zeros(self.n);u[A]=b
            if len(free):u[free]=factor.solve((self.H@y)[free]-self.H[free][:,A]@b)
            la=(self.H@(u-y))[A]
        u[A]=b;lam=np.zeros(self.n);lam[A]=la
        return u,lam

    def solve(self,y,warm=True,tol=2e-9,maxiter=200):
        start=perf_counter();y=np.asarray(y,float)
        A=self.active.copy() if warm else self.indices[y[self.indices]<self.b[self.indices]]
        seen=set();log=[]
        for k in range(maxiter):
            u,lam=self.branch(y,A)
            residual=kkt(self.H,self.b,y,u,lam,self.indices)
            log.append(residual)
            if residual<=tol:break
            indicator=lam-self.scale*(u-self.b)
            new=self.indices[indicator[self.indices]>0]
            key=tuple(new)
            if key in seen:
                self.stats['fallbacks']+=1
                def fun(z):
                    d=z-y;return .5*float(d@(self.H@d)),self.H@d
                bounds=[(float(self.b[i]),None) if self.mask[i] else (None,None) for i in range(self.n)]
                z=minimize(fun,np.maximum(u,self.b) if len(self.indices)==self.n else u,
                    jac=True,bounds=bounds,method='L-BFGS-B',options=dict(ftol=1e-15,gtol=1e-11,maxiter=10000,maxls=50)).x
                grad=self.H@(z-y)
                new=self.indices[(z[self.indices]-self.b[self.indices]<1e-7)&(grad[self.indices]>0)]
                seen.clear()
            seen.add(tuple(A));A=new
        else:raise RuntimeError('Contact QP did not meet its KKT threshold.')
        self.active=A.copy();self.stats['qp_solves']+=1
        return dict(u=u,lam=lam,active=A,b=self.b.copy(),kkt=residual,iterations=k+1,
            seconds=perf_counter()-start,log=log,stats=self.stats.copy())

def kkt(H,b,y,u,lam,indices=None):
    idx=np.arange(len(y)) if indices is None else indices
    stationarity=np.linalg.norm(H@(u-y)-lam,np.inf)
    primal=np.max(np.maximum(b[idx]-u[idx],0),initial=0)
    dual=np.max(np.maximum(-lam[idx],0),initial=0)
    comp=np.max(abs(np.minimum(u[idx]-b[idx],lam[idx])),initial=0)
    return float(max(stationarity,primal,dual,comp))

def gap_certificate(solver,y,u,lam):
    u=np.asarray(u).copy();u[solver.indices]=np.maximum(u[solver.indices],solver.b[solver.indices])
    lam=np.maximum(np.asarray(lam),0);lam[~solver.mask]=0
    if solver.factor is None:solver.factor=splu(solver.H)
    inv=solver.factor.solve(lam);d=u-y
    primal=.5*float(d@(solver.H@d))
    dual=float(lam@(solver.b-y)-.5*lam@inv)
    residual=u-y-inv
    gap=max(0.,.5*float(residual@(solver.H@residual))+float(lam@(u-solver.b)))
    return dict(primal=primal,dual=dual,gap=gap,h_error_bound=float(np.sqrt(2*gap)),feasible_u=u,feasible_lam=lam)

def directional(H,state,d,partition=None):
    u,lam,b=state['u'],state['lam'],state['b']
    if partition is None:
        raise ValueError('An independently justified contact partition is required; thresholding is not a certificate.')
    strong=np.asarray(partition['strong'],int);weak=np.asarray(partition['weak'],int)
    inactive=np.asarray(partition['inactive'],int)
    if not np.array_equal(np.sort(np.r_[strong,weak,inactive]),np.arange(len(u))):
        raise ValueError('Contact partition must cover every coordinate exactly once.')
    F=np.setdiff1d(np.arange(len(u)),strong)
    if not len(F):return dict(u=np.zeros_like(u),weak_count=len(weak),gap=0.,h_error_bound=0.)
    h=H[F][:,F].tocsc();factor=splu(h)
    target=factor.solve((H@d)[F]);lookup=np.full(len(u),-1);lookup[F]=np.arange(len(F))
    solver=ContactSolver(h,np.zeros(len(F)),kind='reduced',indices=lookup[weak])
    r=solver.solve(target,warm=False)
    v=np.zeros_like(u);v[F]=r['u']
    cert=gap_certificate(solver,target,r['u'],r['lam'])
    return dict(u=v,weak_count=len(weak),strong_count=len(strong),**cert)

def event_horizon(solver,state,d):
    A=state['active'];du,dl=solver.branch(np.asarray(d),A,target=np.zeros(solver.n))
    inactive=np.setdiff1d(solver.indices,A)
    values=[]
    release=A[dl[A]<0]
    hit=inactive[du[inactive]<0]
    if len(release):values.extend(np.maximum(state['lam'][release],0)/-dl[release])
    if len(hit):values.extend(np.maximum(state['u'][hit]-solver.b[hit],0)/-du[hit])
    return float(min(values)) if values else float('inf')

def certified_horizon(solver,state,y,d,mu):
    """Exact-arithmetic gap enclosure with H >= mu I supplied by the model."""
    if not np.isfinite(mu) or mu<=0:
        raise ValueError('The supplied lower eigenvalue bound must be finite and positive.')
    uh=np.array(state['u'],copy=True);uh[solver.indices]=np.maximum(uh[solver.indices],solver.b[solver.indices])
    lh=np.maximum(state['lam'],0);lh[~solver.mask]=0
    cert=gap_certificate(solver,y,uh,lh);r=cert['h_error_bound']
    if len(solver.indices)!=solver.n:
        raise ValueError('This continuation certificate requires a bound on every free coordinate.')
    slack=uh-solver.b
    a=np.full(solver.n,r/np.sqrt(mu));dual_error=r*np.sqrt(solver.H.diagonal())
    inactive=slack>a;active=lh>dual_error
    classified=bool(np.all(inactive|active))
    if not classified:return dict(classified=False,horizon=0.,**cert)
    A=np.flatnonzero(active);du,dl=solver.branch(d,A,target=np.zeros(solver.n))
    release=A[dl[A]<0];I=np.flatnonzero(inactive);hit=I[du[I]<0]
    values=[]
    if len(release):values.extend((lh[release]-dual_error[release])/-dl[release])
    if len(hit):values.extend((slack[hit]-a[hit])/-du[hit])
    return dict(classified=True,horizon=float(min(values)) if values else float('inf'),du=du,dl=dl,**cert)
