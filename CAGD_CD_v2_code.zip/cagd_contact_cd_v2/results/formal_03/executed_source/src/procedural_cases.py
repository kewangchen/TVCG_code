"""Six frozen paired-chart interference fixtures, selected by geometry."""
import numpy as np
from scipy import sparse
from scipy.interpolate import BSpline

CASES=[dict(id='strip',label='Corrugated strip',nu=40,nv=18),
       dict(id='saddle',label='Saddle panels',nu=28,nv=26),
       dict(id='annulus',label='Graded annular layers',nu=48,nv=16),
       dict(id='cylinder',label='Cylindrical sleeves',nu=48,nv=18),
       dict(id='torus',label='Toroidal layers',nu=40,nv=20),
       dict(id='nurbs',label='Rational spline panels',nu=30,nv=26)]

def grid(nu,nv,pu=False,pv=False):
    f=[]
    for j in range(nv if pv else nv-1):
        for i in range(nu if pu else nu-1):
            a=j*nu+i;b=j*nu+(i+1)%nu;c=((j+1)%nv)*nu+i;d=((j+1)%nv)*nu+(i+1)%nu
            f.extend([[a,b,d],[a,d,c]])
    return np.asarray(f,int)

def stiffness(X,faces):
    t=X[faces];e=t[:,1]-t[:,0];f=t[:,2]-t[:,0]
    length=np.linalg.norm(e,axis=1);a=np.sum(e*f,axis=1)/length
    h=np.linalg.norm(f-a[:,None]*e/length[:,None],axis=1);area=.5*length*h
    inv=np.zeros((len(faces),2,2));inv[:,0,0]=1/length;inv[:,0,1]=-a/(length*h);inv[:,1,1]=1/h
    co=np.stack((-inv.sum(axis=1),inv[:,0],inv[:,1]),axis=1)*np.sqrt(area)[:,None,None]
    rows=np.broadcast_to(np.arange(2*len(faces)).reshape(-1,1,2),co.shape)
    cols=np.broadcast_to(faces[:,:,None],co.shape)
    B=sparse.coo_matrix((co.ravel(),(rows.ravel(),cols.ravel())),shape=(2*len(faces),len(X))).tocsr()
    C=(B.T@B).tocsc();m=np.bincount(faces.ravel(),weights=np.repeat(area/3,3),minlength=len(X))
    return C,m

def build(spec,coarse=False):
    name=spec['id'];nu,nv=(12,9) if coarse else (spec['nu'],spec['nv'])
    periodic_u=name in ['annulus','cylinder','torus'];periodic_v=name=='torus'
    u=np.arange(nu)/nu if periodic_u else np.linspace(0,1,nu)
    v=np.arange(nv)/nv if periodic_v else np.linspace(0,1,nv)
    U,V=np.meshgrid(u,v);u=U.ravel();v=V.ravel()
    n=np.tile([0.,0.,1.],(len(u),1))
    if name=='strip':X=np.column_stack((3*u,v,.10*np.sin(2*np.pi*u)*np.sin(np.pi*v)))
    elif name=='saddle':X=np.column_stack((2*u-1,2*v-1,.42*((2*u-1)**2-(2*v-1)**2)))
    elif name=='annulus':
        r=.65+.85*v**1.6;t=2*np.pi*u;X=np.column_stack((r*np.cos(t),r*np.sin(t),.08*np.sin(3*t)*v))
    elif name=='cylinder':
        t=2*np.pi*u;X=np.column_stack((.8*np.cos(t),.8*np.sin(t),2*v));n=np.column_stack((np.cos(t),np.sin(t),0*u))
    elif name=='torus':
        t=2*np.pi*u;s=2*np.pi*v;rho=1.35+.4*np.cos(s)
        X=np.column_stack((rho*np.cos(t),rho*np.sin(t),.4*np.sin(s)))
        n=np.column_stack((np.cos(s)*np.cos(t),np.cos(s)*np.sin(t),np.sin(s)))
    else:
        knots=np.r_[np.zeros(4),np.ones(4)];bu=BSpline.design_matrix(u,knots,3).toarray();bv=BSpline.design_matrix(v,knots,3).toarray()
        cp=np.array([[[2*i/3,1.5*j/3,.5*np.sin(i*1.2)*np.cos(j*.9)] for i in range(4)] for j in range(4)])
        w=np.array([[1.,1.1,.8,1.],[.9,1.4,1.2,1.],[1.2,.8,1.4,1.],[1.,1.,.9,1.]])
        basis=np.einsum('ni,nj->nji',bu,bv)*w[None]
        X=np.einsum('nji,jik->nk',basis,cp)/basis.sum((1,2))[:,None]
    faces=grid(nu,nv,periodic_u,periodic_v)
    fixed=(v<.001)|(v>.999) if not periodic_v else ((u<.001)&(v<.08))
    if not periodic_u:fixed|=(u<.001)|(u>.999)
    free=np.flatnonzero(~fixed)
    C,m=stiffness(X,faces);mass=m/m.mean()
    bih=(C@sparse.diags(1/m)@C).tocsc()
    H=(sparse.diags(mass)+12*C/max(C.diagonal().mean(),1e-12)+18*bih/max(bih.diagonal().mean(),1e-12)).tocsc()
    H=H[free][:,free].tocsc()
    envelope=np.ones(len(u))
    if not periodic_v:envelope*=np.sin(np.pi*v)**2
    else:envelope*=.5+.5*np.cos(2*np.pi*(v-.48))
    if not periodic_u:envelope*=np.sin(np.pi*u)**2
    else:envelope*=.55+.45*np.cos(2*np.pi*(u-.36))
    envelope[fixed]=0
    wave=envelope*(1+.18*np.cos(4*np.pi*u)+.12*np.sin(3*np.pi*v))
    wave/=wave.max()
    def target(theta):
        # One-parameter repeated edit, then return; no future-state cache.
        return -.15*float(theta)*wave[free]
    return dict(id=name,label=spec['label'],X=X,normals=n,faces=faces,fixed=np.flatnonzero(fixed),
        free=free,H=H,b=np.full(len(free),.018-.08),gap0=.08,clearance=.018,
        mass_lower_bound=float(mass[free].min()),target=target,wave=wave,area_mass=m,
        chart_kind='radial' if name in ['cylinder','torus'] else 'vertical',
        nurbs_weights=w if name=='nurbs' else None)

def surfaces(case,u):
    full=np.zeros(len(case['X']));full[case['free']]=u
    offset=.5*(case['gap0']+full)[:,None]*case['normals']
    return np.vstack((case['X']-offset,case['X']+offset)),np.vstack((case['faces'],case['faces']+len(case['X'])))
