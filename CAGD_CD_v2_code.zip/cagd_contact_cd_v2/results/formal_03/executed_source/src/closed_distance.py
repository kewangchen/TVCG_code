"""Floating-point closed triangle distance, independent of scalar chart gaps.

Expected topological neighbors are excluded from the closed-contact query;
their interior overlaps are checked separately by the all-candidate LP audit.
"""
from time import perf_counter
import numpy as np
from .geometry_checks import aabb_candidates, triangle_intersections


def point_triangle(p, t):
    """Squared point/closed-triangle distances, including degenerate edges."""
    a = t[:, 1]-t[:, 0]; b = t[:, 2]-t[:, 0]; r = p-t[:, 0]
    aa = np.einsum('ij,ij->i', a, a); ab = np.einsum('ij,ij->i', a, b)
    bb = np.einsum('ij,ij->i', b, b)
    ar = np.einsum('ij,ij->i', a, r); br = np.einsum('ij,ij->i', b, r)
    det = aa*bb-ab*ab
    good = det > 1e-14*aa*bb
    x = np.zeros(len(t)); y = np.zeros(len(t))
    np.divide(bb*ar-ab*br, det, out=x, where=good)
    np.divide(aa*br-ab*ar, det, out=y, where=good)
    inside = good & (x >= 0) & (y >= 0) & (x+y <= 1)
    q = r-x[:, None]*a-y[:, None]*b
    dist = np.where(inside, np.einsum('ij,ij->i', q, q), np.inf)
    for i in range(3):
        edge = t[:, (i+1) % 3]-t[:, i]; rel = p-t[:, i]
        denom = np.einsum('ij,ij->i', edge, edge)
        alpha = np.zeros(len(t))
        np.divide(np.einsum('ij,ij->i', rel, edge), denom, out=alpha, where=denom > 0)
        alpha = np.clip(alpha, 0, 1)
        z = rel-alpha[:, None]*edge
        dist = np.minimum(dist, np.einsum('ij,ij->i', z, z))
    return dist


def segments(p0, p1, q0, q1):
    """Squared distance between paired closed line segments."""
    a = p1-p0; b = q1-q0; r = p0-q0
    aa = np.einsum('ij,ij->i', a, a); ab = np.einsum('ij,ij->i', a, b)
    bb = np.einsum('ij,ij->i', b, b)
    ar = np.einsum('ij,ij->i', a, r); br = np.einsum('ij,ij->i', b, r)
    det = aa*bb-ab*ab; good = det > 1e-14*aa*bb
    s = np.zeros(len(a)); t = np.zeros(len(a))
    np.divide(ab*br-bb*ar, det, out=s, where=good)
    np.divide(aa*br-ab*ar, det, out=t, where=good)
    q = r+s[:, None]*a-t[:, None]*b
    dist = np.where(good & (s >= 0) & (s <= 1) & (t >= 0) & (t <= 1),
                    np.einsum('ij,ij->i', q, q), np.inf)
    for x in [0., 1.]:
        z = r+x*a; alpha = np.zeros(len(a))
        np.divide(np.einsum('ij,ij->i', z, b), bb, out=alpha, where=bb > 0)
        d = z-np.clip(alpha, 0, 1)[:, None]*b
        dist = np.minimum(dist, np.einsum('ij,ij->i', d, d))
        z = r-x*b; alpha = np.zeros(len(a))
        np.divide(-np.einsum('ij,ij->i', z, a), aa, out=alpha, where=aa > 0)
        d = z+np.clip(alpha, 0, 1)[:, None]*a
        dist = np.minimum(dist, np.einsum('ij,ij->i', d, d))
    return dist


def distance(a, b):
    """Euclidean distance between paired closed 3D triangles."""
    a, b = np.asarray(a, dtype=float), np.asarray(b, dtype=float)
    if a.shape != b.shape or a.ndim != 3 or a.shape[1:] != (3, 3):
        raise ValueError('Expected paired (n,3,3) triangles.')
    d = np.full(len(a), np.inf)
    for i in range(3):
        d = np.minimum(d, point_triangle(a[:, i], b))
        d = np.minimum(d, point_triangle(b[:, i], a))
        for j in range(3):
            d = np.minimum(d, segments(a[:, i], a[:, (i+1) % 3], b[:, j], b[:, (j+1) % 3]))
    d[triangle_intersections(a, b)] = 0
    return np.sqrt(np.maximum(d, 0))


def closed_mesh_check(vertices, faces, relative_tolerance=1e-8, batch_size=2048):
    """Check every padded-AABB nonadjacent candidate for closed contact.

The reported minimum is among candidate pairs, not the global mesh distance.
Every pair within the threshold has overlapping threshold-padded AABBs.
"""
    start = perf_counter(); vertices = np.asarray(vertices); faces = np.asarray(faces)
    eps = relative_tolerance*max(1., float(np.linalg.norm(np.ptp(vertices, axis=0))))
    tri = vertices[faces]; hits = []; minimum = np.inf; count = 0; batch = []
    def consume(pairs):
        ij = np.asarray(pairs, dtype=int)
        values = distance(tri[ij[:, 0]], tri[ij[:, 1]])
        found = np.flatnonzero(values <= eps)
        return float(values.min()), [dict(faces=ij[k].tolist(), distance=float(values[k])) for k in found]
    for pair in aabb_candidates(vertices, faces, padding=eps, exclude_shared=True):
        batch.append(pair); count += 1
        if len(batch) == batch_size:
            value, found = consume(batch); minimum = min(minimum, value); hits.extend(found); batch = []
    if batch:
        value, found = consume(batch); minimum = min(minimum, value); hits.extend(found)
    return dict(nonadjacent_candidate_pairs=count, threshold=eps,
                touch_or_crossing_pairs=[h['faces'] for h in hits], contacts=hits,
                minimum_candidate_distance=None if not np.isfinite(minimum) else minimum,
                seconds=perf_counter()-start,
                scope='Floating-point closed-distance check of all padded-AABB nonadjacent candidates; shared-vertex pairs are excluded and require the separate LP interior-overlap audit.')
