"""Independent endpoint geometry/shape audit of the saved v2 response runs.

This script never solves or reruns the optimization benchmark. It loads the
saved response_0 endpoint at the largest first (closing) theta parameter,
verifies the saved model against cases.build, and checks actual 3D triangles.
Run after isolated timing jobs have finished:
    python -m cagd_contact_cd_v2.geometry_audit --phase formal_01
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy import sparse

from . import cases as newcases
from .src.geometry_checks import (initial_matching_lp, lp_mesh, self_intersections,
                                  summarize, triangle_metrics)
from .src.closed_distance import closed_mesh_check

ROOT = Path(__file__).resolve().parent


def safe(value):
    if isinstance(value, np.ndarray):
        return safe(value.tolist())
    if isinstance(value, np.generic):
        return safe(value.item())
    if isinstance(value, float) and not np.isfinite(value):
        return None
    if isinstance(value, dict):
        return {k: safe(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [safe(v) for v in value]
    return value


def dump(path, value):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(safe(value), indent=2, allow_nan=False)+'\n')


def paired_surfaces(case, u):
    """Construct both layers independently from the stored chart definition."""
    u = np.asarray(u, dtype=float)
    if u.shape != (len(case['free']),) or not np.isfinite(u).all():
        raise ValueError('Expected one finite gap displacement per free chart node.')
    full = np.zeros(len(case['X'])); full[case['free']] = u
    offset = .5*(case['gap0']+full)[:, None]*case['normals']
    n = len(case['X'])
    return np.vstack((case['X']-offset, case['X']+offset)), np.vstack((case['faces'], case['faces']+n))


def _hash(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def load_endpoint(folder, case):
    """Load immutable benchmark output; reject geometry/metric/basis drift."""
    folder = Path(folder)
    with np.load(folder/'model.npz') as saved:
        for key in ['X', 'normals', 'faces', 'fixed', 'free', 'b', 'Y', 'area_mass']:
            actual, expected = np.asarray(case[key]), np.asarray(saved[key])
            if actual.shape != expected.shape:
                raise ValueError('Saved/rebuilt model shape differs: '+key)
            if np.issubdtype(actual.dtype, np.integer):
                match = np.array_equal(actual, expected)
            else:
                match = np.allclose(actual, expected, atol=2e-13, rtol=2e-13)
            if not match:
                raise ValueError('Saved/rebuilt model values differ: '+key)
        for key in ['gap0', 'clearance', 'mass_lower_bound']:
            if not np.isclose(case[key], float(saved[key]), atol=2e-13, rtol=2e-13):
                raise ValueError('Saved/rebuilt scalar model differs: '+key)
    H = sparse.load_npz(folder/'H.npz').tocsc()
    delta = (H-case['H']).tocoo()
    if H.shape != case['H'].shape or (delta.nnz and np.max(np.abs(delta.data)) > 2e-12*max(1., np.max(np.abs(H.data)))):
        raise ValueError('Saved/rebuilt metric differs.')
    with np.load(folder/'response_0.npz') as saved:
        theta = saved['theta'].copy(); states = saved['states'].copy(); duals = saved['duals'].copy()
    if theta.ndim != 2 or states.shape != (len(theta), len(case['free'])) or duals.shape != states.shape:
        raise ValueError('Malformed response_0 state sequence.')
    if theta.shape[1] != case['Y'].shape[1] or not np.isfinite(np.r_[states.ravel(), duals.ravel(), theta.ravel()]).all():
        raise ValueError('Response sequence contains invalid data or a different edit rank.')
    peak = int(np.argmax(theta[:, 0])); y = case['Y']@theta[peak]
    # Both layers move by |u|/2 along unit normals, with equal nodal masses.
    m = np.asarray(case['area_mass']); free_mass = m[case['free']]
    deformation = .5*np.sqrt(np.sum(states**2*free_mass[None, :], axis=1)/m.sum())
    return dict(u=states[peak], lam=duals[peak], y=y, theta=theta[peak], H=H,
                peak_index=peak, max_deformation_index=int(np.argmax(deformation)),
                max_deformation_rms=float(deformation.max()),
                selected_deformation_rms=float(deformation[peak]),
                saved_model_verified=True,
                saved_files_sha256={name: _hash(folder/name) for name in
                                    ['model.npz', 'H.npz', 'response_0.npz', 'response_0.json']})


def _quality(reference, current, faces):
    metrics = triangle_metrics(reference, current, faces)
    summary = summarize(metrics)
    summary['all_metrics_finite'] = bool(all(np.isfinite(v).all() for v in metrics.values()))
    summary['minimum_current_area'] = float(np.min(metrics['rest_area']*metrics['area_ratio']))
    summary['total_reference_area'] = float(metrics['rest_area'].sum())
    summary['total_current_area'] = float((metrics['rest_area']*metrics['area_ratio']).sum())
    return summary, metrics


def _source(case):
    out = dict(kind='public authored STEP BRep' if case['id'].startswith('nist') else 'procedural comparison chart',
               transform=case.get('transform'), layer_scope='Synthetic paired chart/normal-offset clearance layers')
    if case['id'].startswith('nist'):
        path = ROOT/'assets'/case['id']/'metadata.json'
        meta = json.loads(path.read_text())
        keys = ['source_filename', 'source_sha256', 'source_archive_url', 'source_archive_sha256',
                'source_units', 'source_unit_to_mm', 'output_units', 'source_license',
                'selected_gmsh_face_ids', 'selected_faces', 'gmsh_version', 'kernel_build_info']
        out.update({key: meta[key] for key in keys})
        transform = case.get('transform', {})
        radius_mm, scale = transform.get('sampled_radius_mm'), transform.get('scale_per_mm')
        out['sampled_radius_in_case_units'] = None if radius_mm is None or scale is None else radius_mm*scale
        out['radius_scope'] = 'Sampled CAD principal radius, not a certified global reach or offset-injectivity bound.'
        out['case_coordinate_units'] = 'normalized case length units; source mm transform is explicit'
    return out


def audit_endpoint(case, u, y, lam=None, full_checks=True):
    """Audit one endpoint and a clamp under the identical fixed/bound constraints.

No negative finding raises an assertion: losses are retained in the record.
Setting full_checks=False is only for tiny unit tests or explicit quality-only
fine-grid studies and cannot produce a complete endpoint-validation claim.
"""
    start = perf_counter(); u, y = np.asarray(u), np.asarray(y)
    clamped = np.maximum(y, case['b'])
    reference, faces = paired_surfaces(case, np.zeros_like(u))
    initial, _ = paired_surfaces(case, y)
    solved, _ = paired_surfaces(case, u)
    clamp, _ = paired_surfaces(case, clamped)
    quality, metrics = _quality(reference, solved, faces)
    clamp_quality, clamp_metrics = _quality(reference, clamp, faces)
    initial_quality, _ = _quality(reference, initial, faces)
    target_quality, _ = _quality(initial, solved, faces)
    target_clamp_quality, _ = _quality(initial, clamp, faces)
    n = len(case['X']); fixed = np.r_[case['fixed'], case['fixed']+n]
    mass = np.r_[case['area_mass'], case['area_mass']]
    scale = max(float(np.linalg.norm(np.ptp(reference, axis=0))), np.finfo(float).tiny)
    rms = lambda a, b: float(np.sqrt(np.sum(mass[:, None]*(a-b)**2)/mass.sum())/scale)
    energy = lambda a: .5*float(a@(case['H']@a))
    objective = energy(u-y); clamp_objective = energy(clamped-y)
    full_u = np.zeros(n); full_u[case['free']] = u
    full_y = np.zeros(n); full_y[case['free']] = y
    full_clamp = np.zeros(n); full_clamp[case['free']] = clamped
    hard_error = float(np.max(np.abs(solved[fixed]-reference[fixed]))) if len(fixed) else 0.
    clamp_hard_error = float(np.max(np.abs(clamp[fixed]-reference[fixed]))) if len(fixed) else 0.
    rec = dict(case=case['id'], label=case.get('label', case['id']), level=case.get('level'),
               rank=case.get('rank'), vertices=len(solved), triangles=len(faces), free_dofs=len(u),
               scope=case['chart_kind'], full_endpoint_checks=bool(full_checks),
               geometry_source=_source(case), quality=quality, clamp_quality=clamp_quality,
               initial_quality=initial_quality, repaired_vs_target_quality=target_quality,
               clamp_vs_target_quality=target_clamp_quality,
               repair_rms=rms(solved, initial), clamp_repair_rms=rms(clamp, initial),
               reference_deformation_rms=rms(solved, reference), clamp_reference_deformation_rms=rms(clamp, reference),
               energy=objective, clamp_energy=clamp_objective,
               clamp_energy_ratio=None if objective <= np.finfo(float).tiny else clamp_objective/objective,
               target_metric_energies=dict(repaired=objective, clamp=clamp_objective, input=0.),
               reference_metric_energies=dict(repaired=energy(u), clamp=energy(clamped), input=energy(y)),
               energy_scope='H metric on the identical free scalar-gap variables; target energy is one half (u-y)^T H (u-y), reference energy is one half u^T H u.',
               hard_error=hard_error, clamp_hard_error=clamp_hard_error,
               chart_gap_min=float(np.min(case['gap0']+full_u)),
               clamp_chart_gap_min=float(np.min(case['gap0']+full_clamp)),
               initial_chart_gap_min=float(np.min(case['gap0']+full_y)),
               required_chart_clearance=float(case['clearance']),
               lower_bound_slack_min=float(np.min(u-case['b'])),
               clamp_lower_bound_slack_min=float(np.min(clamped-case['b'])),
               matching_node_clearance_min=float(np.linalg.norm(solved[:n]-solved[n:], axis=1).min()),
               maximum_layer_offset=float(.5*np.abs(case['gap0']+full_u).max()),
               clearance_scope='Signed chart gap and corresponding-node separation; these do not establish global CAD layer nonintersection.')
    if lam is not None:
        lam = np.asarray(lam); stationarity = case['H']@(u-y)-lam
        rec['independent_kkt'] = dict(primal_violation=max(0., -float(np.min(u-case['b']))),
                                      dual_violation=max(0., -float(lam.min())),
                                      stationarity_linf=float(np.abs(stationarity).max()),
                                      complementarity_linf=float(np.abs(lam*(u-case['b'])).max()))
    if full_checks:
        initial_edges = self_intersections(initial, faces)
        matching = initial_matching_lp(case, initial, faces, y)
        pairs = {tuple(p) for p in initial_edges}
        pairs.update(tuple(hit['faces']) for hit in matching['strict_overlaps'])
        rec.update(initial_edge_detector_crossings=len(initial_edges), initial_edge_detector_faces=initial_edges,
                   initial_matching_lp=matching, initial_crossings=len(pairs),
                   initial_crossing_faces=[list(p) for p in sorted(pairs)],
                   initial_count_scope='Detected union of edge/coplanar tests and matching-face LP witnesses; not an exhaustive count of all input intersecting pairs.',
                   final_crossing_faces=self_intersections(solved, faces),
                   clamp_crossing_faces=self_intersections(clamp, faces),
                   independent_lp=lp_mesh(solved, faces), clamp_independent_lp=lp_mesh(clamp, faces),
                   closed_distance_check=closed_mesh_check(solved, faces),
                   clamp_closed_distance_check=closed_mesh_check(clamp, faces))
        rec['final_crossings'] = len(rec['final_crossing_faces'])
        rec['clamp_crossings'] = len(rec['clamp_crossing_faces'])
        if case['chart_kind'] == 'vertical':
            xy = case['X'][:, :2]; tri = xy[case['faces']]
            e, f = tri[:, 1]-tri[:, 0], tri[:, 2]-tri[:, 0]
            signed = e[:, 0]*f[:, 1]-e[:, 1]*f[:, 0]
            rec['projected_graph_check'] = dict(min_absolute_double_area=float(np.abs(signed).min()),
                                                 consistent_orientation=bool(np.all(signed > 0) or np.all(signed < 0)),
                                                 strict_overlaps=len(self_intersections(xy, case['faces'])))
        else:
            rec['projected_graph_check'] = None
        rec['endpoint_checks_pass'] = bool(not rec['final_crossings']
                                           and not rec['independent_lp']['strict_overlaps']
                                           and not rec['closed_distance_check']['touch_or_crossing_pairs']
                                           and quality['sigma_min'] > 0 and quality['all_metrics_finite']
                                           and hard_error <= 1e-13 and rec['lower_bound_slack_min'] >= -2e-9)
        rec['clamp_endpoint_checks_pass'] = bool(not rec['clamp_crossings']
                                                 and not rec['clamp_independent_lp']['strict_overlaps']
                                                 and not rec['clamp_closed_distance_check']['touch_or_crossing_pairs']
                                                 and clamp_quality['sigma_min'] > 0 and clamp_quality['all_metrics_finite']
                                                 and clamp_hard_error <= 1e-13)
    else:
        rec['endpoint_checks_pass'] = None; rec['clamp_endpoint_checks_pass'] = None
    rec['audit_seconds'] = perf_counter()-start
    arrays = dict(reference=reference, initial=initial, solved=solved, clamp=clamp, faces=faces,
                  fixed=fixed, X=case['X'], normals=case['normals'], chart_faces=case['faces'],
                  chart_fixed=case['fixed'], free=case['free'], u=u, y=y, clamp_u=clamped,
                  conformal_ratio=metrics['conformal_ratio'], area_ratio=metrics['area_ratio'],
                  singular_values=metrics['singular_values'], angle_change_deg=metrics['angle_change_deg'],
                  isometry_density=metrics['isometry_density'], rest_area=metrics['rest_area'],
                  clamp_conformal_ratio=clamp_metrics['conformal_ratio'])
    return rec, arrays


def run(phase='formal_01', names=None, level='base', rank=1, quality_only=False, output=None):
    names = list(newcases.MAIN if names is None else names)
    formal = ROOT/'results'/phase
    output = Path(output) if output is not None else ROOT/'results'/('geometry' if level == 'base' else 'geometry_'+level)
    output.mkdir(parents=True, exist_ok=True); records = []
    for name in names:
        case = newcases.build(name, level, rank)
        endpoint = load_endpoint(formal/f'{name}_{level}_r{rank}', case)
        # Use the verified, immutable matrix for independent endpoint energies.
        case['H'] = endpoint['H']
        rec, arrays = audit_endpoint(case, endpoint['u'], endpoint['y'], endpoint['lam'], full_checks=not quality_only)
        rec.update({key: value for key, value in endpoint.items() if key not in ['u', 'lam', 'y', 'H', 'theta']})
        rec.update(peak_theta=endpoint['theta'].tolist(),
                   endpoint_selection='Saved response_0 query with largest first closing theta parameter.',
                   phase=phase, endpoint_method='response_0',
                   audit_source_sha256={str(p.relative_to(ROOT)): _hash(p) for p in
                                       [Path(__file__), ROOT/'src/geometry_checks.py', ROOT/'src/closed_distance.py', ROOT/'cases.py']})
        dest = output/name; dest.mkdir(parents=True, exist_ok=True)
        arrays['theta'] = endpoint['theta']; np.savez_compressed(dest/'states.npz', **arrays)
        rec['states_sha256'] = _hash(dest/'states.npz')
        dump(dest/'audit.json', rec); records.append(rec)
        dump(output/'geometry_audit.json', records)
        print('GEOMETRY', name, level, 'peak', rec['peak_index'], 'input detected', rec.get('initial_crossings'),
              'final pass', rec['endpoint_checks_pass'], 'clamp pass', rec['clamp_endpoint_checks_pass'], flush=True)
    if names == list(newcases.MAIN) and level == 'base' and rank == 1 and not quality_only:
        dump(ROOT/'results/geometry_audit.json', records)
    return records


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--phase', default='formal_01')
    parser.add_argument('--case', action='append', choices=newcases.MAIN)
    parser.add_argument('--level', choices=['base', 'medium', 'fine'], default='base')
    parser.add_argument('--rank', type=int, choices=[1, 3], default=1)
    parser.add_argument('--quality-only', action='store_true', help='Explicitly skip collision checks; no endpoint pass claim is emitted.')
    parser.add_argument('--output', type=Path)
    args = parser.parse_args()
    run(args.phase, args.case, args.level, args.rank, args.quality_only, args.output)


if __name__ == '__main__':
    main()
